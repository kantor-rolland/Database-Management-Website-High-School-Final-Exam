<?php
    //session_start();
   

function szuro()
{
    $conn=mysqli_connect("localhost","root","","sertes");
   // echo $_SESSION['userid'];
    if(isset($_POST['szures']))
    {
        /*$tablanev="sertesek_".$_SESSION['userid'];
        
       
        $rendezes=$_POST['rendezes'];
        $sex=$_POST['sex'];
        echo $tablanev." ".$fajta." ".$tipus." ".$rendezes." ".$sex." <br><br>";*/
        
        $fajta=$_POST['fajta'];
        $tipus=$_POST['tipus'];
        $lekerdezes="";
        //elso nagy eset ha a tipus koca
        if( $tipus=="Koca")
        {   
            $tablanev1="sertesek_".$_SESSION['userid'];
            $tablanev2="fialasok_".$_SESSION['userid'];
            //$fajta=$_POST['fajta'];
            //$tipus=$_POST['tipus'];
            $rendezes=$_POST['rendezes'];
           
            //echo $tablanev1." ".$fajta." ".$tipus." ".$rendezes." "." <br><br>";
            $atlag1=$_POST['atlag'];
            $fialas_szam=$_POST['fialas_darab'];
            
            //echo $tablanev1." ".$tablanev2." ".$fajta." ".$tipus." ".$rendezes." "." ".$atlag1." ".$fialas_szam." <br><br>";

            $lekerdezes="";
            /*
            SELECT zoldsegesek.nev AS Nev, COUNT(vasarlasok.vasarlasazon) AS Eladas FROM vasarlasok,zoldsegesek WHERE vasarlasok.zoldseges=zoldsegesek.zoldsegesazon and zoldsegesek.nev like '$t1'*/

            //ha az atlag es a fialasok szama meg van ada
                
            /*echo "<table border=2> 
            <tr>
                <th> Sorszám </th>
                <th> Sertés azonosító </th>
                <th> Anya azonosító </th>
                <th> Apa azonosító </th>
                <th> Születési dátum </th>
                <th> Fajta </th>
                <th> Nem </th>
                <th> Típus </th>
                <th> Fialások száma </th>
                <th> Fialt malacok átlaga </th>
                <th> Felnevelt malacok átlaga </th>

            </tr>
            </table>";*/
               /* //elso rendezes: Nincs rendezés 
                    if( $rendezes=="Nincs rendezés" )
                    {
                        $lekerdezes="SELECT Sorszam, Azonosito, Anya_azonosito, Apa_azonosito, Szuletesi_datum, Fajta, Nem, Tipus FROM $tablanev WHERE Tipus LIKE '$tipus'";
                        $tabla=mysqli_query( $conn, $lekerdezes);
                        while($sor=mysqli_fetch_array($tabla))
                        {
                            echo "<tr>
                                    <td>";
                            echo $sor['Sorszam'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Azonosito'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Anya_azonosito'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Apa_azonosito'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Szuletesi_datum'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Fajta'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Nem'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Tipus'];
                            echo "  </td>
                                    </tr>";
                        }
                        echo "</table>";

                    }*/
                //masodik rendezes: Életkor szerint növekvő
                //harmadik rendezes: Életkor szerint csökkenő
                //negyedikr rendezes: Malacozások száma szerint növekvő
                //otodik rendezes: Malacozások száma szerint csökkenő
                //hatodik rendezes: A fialt malacok átlaga szerint növekvő
                //hetedik rendezes: A fialt malacok átlaga szerint csökkenő
                //nyolcadik rendezes: A felnevelt malacok átlaga szerint növekvő
                //kilencedik rendezes: A felnevelt malacok átlaga szerint csökkenő

                 /* rendezesek
                    Nincs rendezés 
                    Életkor szerint növekvő
                    Életkor szerint csökkenő
                    Malacozások száma szerint növekvő
                    Malacozások száma szerint csökkenő
                    A fialt malacok átlaga szerint növekvő
                    A fialt malacok átlaga szerint csökkenő
                    A felnevelt malacok átlaga szerint növekvő
                    A felnevelt malacok átlaga szerint csökkenő*/
            
            //ha az atlag meg van adva, de a fialasok nincsenek megadva
            
            //ha az atlag nincs, de a fialasok meg van adva
            
            //ha sem az atlag sem a fialas nincs megadva

            //ha az atlag es a fialasok szama meg van ada
                
            echo "
                    <div style=''>
            <table id='table3'> 
            <tr>
                <th> Sorszám </th>
                <th> Sertés azonosító </th>
                <th> Anya azonosító </th>
                <th> Apa azonosító </th>
                <th> Születési dátum </th>
                <th> Fajta </th>
                <th> Nem </th>
                <th> Típus </th>
                <th> Fialások száma </th>
                <th> Fialt malacok átlaga </th>
                <th> Felnevelt malacok átlaga </th>
                 </tr>";

        if($fialas_szam == null and $atlag1== Null)
        {       
                $fialas_szam=0;
                $atlag1=0;
                echo "<b>Szűrés:</b> Fajta: <b>".$fajta."</b> Típus:<b>".$tipus."</b> Nem:<b> Nőstény</b>"." Rendezés:<b>".$rendezes."</b> Fialt malacok átlaga:<b>".$atlag1."</b> Fialások száma:<b>".$fialas_szam."</b><br><br><br>";
             /*
            SELECT zoldsegesek.nev AS Nev, COUNT(vasarlasok.vasarlasazon) AS Eladas FROM vasarlasok,zoldsegesek WHERE vasarlasok.zoldseges=zoldsegesek.zoldsegesazon and zoldsegesek.nev like '$t1'*/

         //elso rendezes: Nincs rendezés 
            if( $rendezes=="Nincs rendezés" )
            { 
        
                $lekerdezes="SELECT $tablanev1.Sorszam As Sorszam, $tablanev2.Koca_azonosito AS Azonosito, $tablanev1.Anya_azonosito AS Anya_azonosito, $tablanev1.Apa_azonosito AS Apa_azonosito, $tablanev1.Szuletesi_datum AS Szuletesi_datum, $tablanev1.Fajta AS Fajta, $tablanev1.Nem AS Nem, $tablanev1.Tipus AS Tipus, COUNT($tablanev2.Sorszam) AS Fialasok, AVG($tablanev2.Fialt_malacok) AS Atlag1, AVG($tablanev2.Felnevelt_malacok) AS Atlag2 FROM $tablanev1, $tablanev2 WHERE $tablanev2.Koca_azonosito=$tablanev1.Azonosito GROUP BY Koca_azonosito ";                         
           }
                
                    
            //masodik rendezes: Életkor szerint növekvő
            if( $rendezes=="Életkor szerint növekvő" )
            {
                $lekerdezes="SELECT $tablanev1.Sorszam As Sorszam, $tablanev2.Koca_azonosito AS Azonosito, $tablanev1.Anya_azonosito AS Anya_azonosito, $tablanev1.Apa_azonosito AS Apa_azonosito, $tablanev1.Szuletesi_datum AS Szuletesi_datum, $tablanev1.Fajta AS Fajta, $tablanev1.Nem AS Nem, $tablanev1.Tipus AS Tipus, COUNT($tablanev2.Sorszam) AS Fialasok, AVG($tablanev2.Fialt_malacok) AS Atlag1, AVG($tablanev2.Felnevelt_malacok) AS Atlag2 FROM $tablanev1, $tablanev2 WHERE $tablanev2.Koca_azonosito=$tablanev1.Azonosito GROUP BY Koca_azonosito ORDER BY Szuletesi_datum ASC";
               
            } 

            //harmadik rendezes: Életkor szerint csökkenő 
            if( $rendezes=="Életkor szerint csökkenő" )
            {
                $lekerdezes="SELECT $tablanev1.Sorszam As Sorszam, $tablanev2.Koca_azonosito AS Azonosito, $tablanev1.Anya_azonosito AS Anya_azonosito, $tablanev1.Apa_azonosito AS Apa_azonosito, $tablanev1.Szuletesi_datum AS Szuletesi_datum, $tablanev1.Fajta AS Fajta, $tablanev1.Nem AS Nem, $tablanev1.Tipus AS Tipus, COUNT($tablanev2.Sorszam) AS Fialasok, AVG($tablanev2.Fialt_malacok) AS Atlag1, AVG($tablanev2.Felnevelt_malacok) AS Atlag2 FROM $tablanev1, $tablanev2 WHERE $tablanev2.Koca_azonosito=$tablanev1.Azonosito GROUP BY Koca_azonosito ORDER BY Szuletesi_datum DESC";
               
            }

            //negyedik rendezes: Malacozások száma szerint növekvő 
            if( $rendezes=="Malacozások száma szerint növekvő" )
            {
                $lekerdezes="SELECT $tablanev1.Sorszam As Sorszam, $tablanev2.Koca_azonosito AS Azonosito, $tablanev1.Anya_azonosito AS Anya_azonosito, $tablanev1.Apa_azonosito AS Apa_azonosito, $tablanev1.Szuletesi_datum AS Szuletesi_datum, $tablanev1.Fajta AS Fajta, $tablanev1.Nem AS Nem, $tablanev1.Tipus AS Tipus, COUNT($tablanev2.Sorszam) AS Fialasok, AVG($tablanev2.Fialt_malacok) AS Atlag1, AVG($tablanev2.Felnevelt_malacok) AS Atlag2 FROM $tablanev1, $tablanev2 WHERE $tablanev2.Koca_azonosito=$tablanev1.Azonosito GROUP BY Koca_azonosito ORDER BY Fialasok ASC";
                
            }
            //otodik rendezes: Malacozások száma szerint csökkenő 
             if( $rendezes=="Malacozások száma szerint csökkenő" )
             {
                $lekerdezes="SELECT $tablanev1.Sorszam As Sorszam, $tablanev2.Koca_azonosito AS Azonosito, $tablanev1.Anya_azonosito AS Anya_azonosito, $tablanev1.Apa_azonosito AS Apa_azonosito, $tablanev1.Szuletesi_datum AS Szuletesi_datum, $tablanev1.Fajta AS Fajta, $tablanev1.Nem AS Nem, $tablanev1.Tipus AS Tipus, COUNT($tablanev2.Sorszam) AS Fialasok, AVG($tablanev2.Fialt_malacok) AS Atlag1, AVG($tablanev2.Felnevelt_malacok) AS Atlag2 FROM $tablanev1, $tablanev2 WHERE $tablanev2.Koca_azonosito=$tablanev1.Azonosito GROUP BY Koca_azonosito ORDER BY Fialasok DESC";
                
             }
            //hatodik rendezes: A fialt malacok átlaga szerint növekvő
            if( $rendezes=="A fialt malacok átlaga szerint növekvő" )
            {
                $lekerdezes="SELECT $tablanev1.Sorszam As Sorszam, $tablanev2.Koca_azonosito AS Azonosito, $tablanev1.Anya_azonosito AS Anya_azonosito, $tablanev1.Apa_azonosito AS Apa_azonosito, $tablanev1.Szuletesi_datum AS Szuletesi_datum, $tablanev1.Fajta AS Fajta, $tablanev1.Nem AS Nem, $tablanev1.Tipus AS Tipus, COUNT($tablanev2.Sorszam) AS Fialasok, AVG($tablanev2.Fialt_malacok) AS Atlag1, AVG($tablanev2.Felnevelt_malacok) AS Atlag2 FROM $tablanev1, $tablanev2 WHERE $tablanev2.Koca_azonosito=$tablanev1.Azonosito GROUP BY Koca_azonosito ORDER BY Atlag1 ASC";
               
            } 
            //hetedik rendezes: A fialt malacok átlaga szerint csökkenő 
            if( $rendezes=="A fialt malacok átlaga szerint csökkenő" )
            {
                $lekerdezes="SELECT $tablanev1.Sorszam As Sorszam, $tablanev2.Koca_azonosito AS Azonosito, $tablanev1.Anya_azonosito AS Anya_azonosito, $tablanev1.Apa_azonosito AS Apa_azonosito, $tablanev1.Szuletesi_datum AS Szuletesi_datum, $tablanev1.Fajta AS Fajta, $tablanev1.Nem AS Nem, $tablanev1.Tipus AS Tipus, COUNT($tablanev2.Sorszam) AS Fialasok, AVG($tablanev2.Fialt_malacok) AS Atlag1, AVG($tablanev2.Felnevelt_malacok) AS Atlag2 FROM $tablanev1, $tablanev2 WHERE $tablanev2.Koca_azonosito=$tablanev1.Azonosito GROUP BY Koca_azonosito ORDER BY Atlag1 DESC";
               
            }
            //nyolcadik rendezes: A felnevelt malacok átlaga szerint növekvő
            if( $rendezes=="A felnevelt malacok átlaga szerint növekvő" )
            {
                $lekerdezes="SELECT $tablanev1.Sorszam As Sorszam, $tablanev2.Koca_azonosito AS Azonosito, $tablanev1.Anya_azonosito AS Anya_azonosito, $tablanev1.Apa_azonosito AS Apa_azonosito, $tablanev1.Szuletesi_datum AS Szuletesi_datum, $tablanev1.Fajta AS Fajta, $tablanev1.Nem AS Nem, $tablanev1.Tipus AS Tipus, COUNT($tablanev2.Sorszam) AS Fialasok, AVG($tablanev2.Fialt_malacok) AS Atlag1, AVG($tablanev2.Felnevelt_malacok) AS Atlag2 FROM $tablanev1, $tablanev2 WHERE $tablanev2.Koca_azonosito=$tablanev1.Azonosito GROUP BY Koca_azonosito ORDER BY Atlag2 ASC";
               
            }
            //kilencedik rendezes: A felnevelt malacok átlaga szerint csökkenő
            if( $rendezes=="A felnevelt malacok átlaga szerint csökkenő" )
            {
                $lekerdezes="SELECT $tablanev1.Sorszam As Sorszam, $tablanev2.Koca_azonosito AS Azonosito, $tablanev1.Anya_azonosito AS Anya_azonosito, $tablanev1.Apa_azonosito AS Apa_azonosito, $tablanev1.Szuletesi_datum AS Szuletesi_datum, $tablanev1.Fajta AS Fajta, $tablanev1.Nem AS Nem, $tablanev1.Tipus AS Tipus, COUNT($tablanev2.Sorszam) AS Fialasok, AVG($tablanev2.Fialt_malacok) AS Atlag1, AVG($tablanev2.Felnevelt_malacok) AS Atlag2 FROM $tablanev1, $tablanev2 WHERE $tablanev2.Koca_azonosito=$tablanev1.Azonosito GROUP BY Koca_azonosito ORDER BY Atlag2 DESC";
               
            }    
              //masodik rendezes: Életkor szerint növekvő
                //harmadik rendezes: Életkor szerint csökkenő
                //negyedik rendezes: Malacozások száma szerint növekvő
                //otodik rendezes: Malacozások száma szerint csökkenő
                //hatodik rendezes: A fialt malacok átlaga szerint növekvő
                //hetedik rendezes: A fialt malacok átlaga szerint csökkenő
                //nyolcadik rendezes: A felnevelt malacok átlaga szerint növekvő
                //kilencedik rendezes: A felnevelt malacok átlaga szerint csökkenő
           // echo $lekerdezes."<br>";
           //echo $lekerdezes;
            /*$tabla=mysqli_query( $conn, $lekerdezes);
                while($sor=mysqli_fetch_array($tabla))
                    {
                        echo "<tr>
                                <td>";
                        echo $sor['Sorszam'];
                        echo "  </td>
                                <td>";
                        echo $sor['Azonosito'];
                        echo "  </td>
                                <td>";
                        echo $sor['Anya_azonosito'];
                        echo "  </td>
                                <td>";
                        echo $sor['Apa_azonosito'];
                        echo "  </td>
                                <td>";
                        echo $sor['Szuletesi_datum'];
                        echo "  </td>
                                <td>";
                        echo $sor['Fajta'];
                        echo "  </td>
                                <td>";
                        echo $sor['Nem'];
                        echo "  </td>
                                <td>";
                        echo $sor['Tipus'];
                        echo "  </td>
                                <td>";
                        echo $sor['Fialasok'];
                        echo "  </td>
                               <td>";       
                        echo $sor['Atlag1'];
                        echo "  </td>
                                <td>";
                        echo $sor['Atlag2'];
                        
                        echo "  </td>
                                </tr>";
                    }
                    echo "</table>
                      </div>";
                        */

          }

                if($atlag1!=NULL and $fialas_szam==NULL )
                {
                        $fialas_szam=0;
                        echo "<b>Szűrés:</b> Fajta: <b>".$fajta."</b> Típus:<b>".$tipus."</b> Nem:<b> Nőstény</b>"." Rendezés:<b>".$rendezes."</b> Fialt malacok átlaga:<b>".$atlag1."</b> Fialások száma:<b>".$fialas_szam."</b><br><br><br>";
                  if( $rendezes=="Nincs rendezés" )
                        { 
                        
                                $lekerdezes="SELECT $tablanev1.Sorszam As Sorszam, $tablanev2.Koca_azonosito AS Azonosito, $tablanev1.Anya_azonosito AS Anya_azonosito, $tablanev1.Apa_azonosito AS Apa_azonosito, $tablanev1.Szuletesi_datum AS Szuletesi_datum, $tablanev1.Fajta AS Fajta, $tablanev1.Nem AS Nem, $tablanev1.Tipus AS Tipus, COUNT($tablanev2.Sorszam) AS Fialasok, AVG($tablanev2.Fialt_malacok) AS Atlag1, AVG($tablanev2.Felnevelt_malacok) AS Atlag2 FROM $tablanev1, $tablanev2 WHERE $tablanev2.Koca_azonosito=$tablanev1.Azonosito GROUP BY Koca_azonosito HAVING Atlag1 >= $atlag1 ";                         
                        }
                                
                                
                        //masodik rendezes: Életkor szerint növekvő
                        if( $rendezes=="Életkor szerint növekvő" )
                        {
                                $lekerdezes="SELECT $tablanev1.Sorszam As Sorszam, $tablanev2.Koca_azonosito AS Azonosito, $tablanev1.Anya_azonosito AS Anya_azonosito, $tablanev1.Apa_azonosito AS Apa_azonosito, $tablanev1.Szuletesi_datum AS Szuletesi_datum, $tablanev1.Fajta AS Fajta, $tablanev1.Nem AS Nem, $tablanev1.Tipus AS Tipus, COUNT($tablanev2.Sorszam) AS Fialasok, AVG($tablanev2.Fialt_malacok) AS Atlag1, AVG($tablanev2.Felnevelt_malacok) AS Atlag2 FROM $tablanev1, $tablanev2 WHERE $tablanev2.Koca_azonosito=$tablanev1.Azonosito GROUP BY Koca_azonosito HAVING Atlag1 >= $atlag1 ORDER BY Szuletesi_datum ASC";
                        
                        } 

                        //harmadik rendezes: Életkor szerint csökkenő 
                        if( $rendezes=="Életkor szerint csökkenő" )
                        {
                                $lekerdezes="SELECT $tablanev1.Sorszam As Sorszam, $tablanev2.Koca_azonosito AS Azonosito, $tablanev1.Anya_azonosito AS Anya_azonosito, $tablanev1.Apa_azonosito AS Apa_azonosito, $tablanev1.Szuletesi_datum AS Szuletesi_datum, $tablanev1.Fajta AS Fajta, $tablanev1.Nem AS Nem, $tablanev1.Tipus AS Tipus, COUNT($tablanev2.Sorszam) AS Fialasok, AVG($tablanev2.Fialt_malacok) AS Atlag1, AVG($tablanev2.Felnevelt_malacok) AS Atlag2 FROM $tablanev1, $tablanev2 WHERE $tablanev2.Koca_azonosito=$tablanev1.Azonosito GROUP BY Koca_azonosito HAVING Atlag1 >= $atlag1 ORDER BY Szuletesi_datum DESC";
                        
                        }

                        //negyedik rendezes: Malacozások száma szerint növekvő 
                        if( $rendezes=="Malacozások száma szerint növekvő" )
                        {
                                $lekerdezes="SELECT $tablanev1.Sorszam As Sorszam, $tablanev2.Koca_azonosito AS Azonosito, $tablanev1.Anya_azonosito AS Anya_azonosito, $tablanev1.Apa_azonosito AS Apa_azonosito, $tablanev1.Szuletesi_datum AS Szuletesi_datum, $tablanev1.Fajta AS Fajta, $tablanev1.Nem AS Nem, $tablanev1.Tipus AS Tipus, COUNT($tablanev2.Sorszam) AS Fialasok, AVG($tablanev2.Fialt_malacok) AS Atlag1, AVG($tablanev2.Felnevelt_malacok) AS Atlag2 FROM $tablanev1, $tablanev2 WHERE $tablanev2.Koca_azonosito=$tablanev1.Azonosito GROUP BY Koca_azonosito HAVING Atlag1 >= $atlag1 ORDER BY Fialasok ASC";
                                
                        }
                        //otodik rendezes: Malacozások száma szerint csökkenő 
                        if( $rendezes=="Malacozások száma szerint csökkenő" )
                        {
                                $lekerdezes="SELECT $tablanev1.Sorszam As Sorszam, $tablanev2.Koca_azonosito AS Azonosito, $tablanev1.Anya_azonosito AS Anya_azonosito, $tablanev1.Apa_azonosito AS Apa_azonosito, $tablanev1.Szuletesi_datum AS Szuletesi_datum, $tablanev1.Fajta AS Fajta, $tablanev1.Nem AS Nem, $tablanev1.Tipus AS Tipus, COUNT($tablanev2.Sorszam) AS Fialasok, AVG($tablanev2.Fialt_malacok) AS Atlag1, AVG($tablanev2.Felnevelt_malacok) AS Atlag2 FROM $tablanev1, $tablanev2 WHERE $tablanev2.Koca_azonosito=$tablanev1.Azonosito  GROUP BY Koca_azonosito HAVING Atlag1 >= $atlag1 ORDER BY Fialasok DESC";
                                
                        }
                        //hatodik rendezes: A fialt malacok átlaga szerint növekvő
                        if( $rendezes=="A fialt malacok átlaga szerint növekvő" )
                        {
                                $lekerdezes="SELECT $tablanev1.Sorszam As Sorszam, $tablanev2.Koca_azonosito AS Azonosito, $tablanev1.Anya_azonosito AS Anya_azonosito, $tablanev1.Apa_azonosito AS Apa_azonosito, $tablanev1.Szuletesi_datum AS Szuletesi_datum, $tablanev1.Fajta AS Fajta, $tablanev1.Nem AS Nem, $tablanev1.Tipus AS Tipus, COUNT($tablanev2.Sorszam) AS Fialasok, AVG($tablanev2.Fialt_malacok) AS Atlag1, AVG($tablanev2.Felnevelt_malacok) AS Atlag2 FROM $tablanev1, $tablanev2 WHERE $tablanev2.Koca_azonosito=$tablanev1.Azonosito GROUP BY Koca_azonosito HAVING Atlag1 >= $atlag1 ORDER BY Atlag1 ASC";
                        
                        } 
                        //hetedik rendezes: A fialt malacok átlaga szerint csökkenő 
                        if( $rendezes=="A fialt malacok átlaga szerint csökkenő" )
                        {
                                $lekerdezes="SELECT $tablanev1.Sorszam As Sorszam, $tablanev2.Koca_azonosito AS Azonosito, $tablanev1.Anya_azonosito AS Anya_azonosito, $tablanev1.Apa_azonosito AS Apa_azonosito, $tablanev1.Szuletesi_datum AS Szuletesi_datum, $tablanev1.Fajta AS Fajta, $tablanev1.Nem AS Nem, $tablanev1.Tipus AS Tipus, COUNT($tablanev2.Sorszam) AS Fialasok, AVG($tablanev2.Fialt_malacok) AS Atlag1, AVG($tablanev2.Felnevelt_malacok) AS Atlag2 FROM $tablanev1, $tablanev2 WHERE $tablanev2.Koca_azonosito=$tablanev1.Azonosito GROUP BY Koca_azonosito HAVING Atlag1 >= $atlag1 ORDER BY Atlag1 DESC";
                        
                        }
                        //nyolcadik rendezes: A felnevelt malacok átlaga szerint növekvő
                        if( $rendezes=="A felnevelt malacok átlaga szerint növekvő" )
                        {
                                $lekerdezes="SELECT $tablanev1.Sorszam As Sorszam, $tablanev2.Koca_azonosito AS Azonosito, $tablanev1.Anya_azonosito AS Anya_azonosito, $tablanev1.Apa_azonosito AS Apa_azonosito, $tablanev1.Szuletesi_datum AS Szuletesi_datum, $tablanev1.Fajta AS Fajta, $tablanev1.Nem AS Nem, $tablanev1.Tipus AS Tipus, COUNT($tablanev2.Sorszam) AS Fialasok, AVG($tablanev2.Fialt_malacok) AS Atlag1, AVG($tablanev2.Felnevelt_malacok) AS Atlag2 FROM $tablanev1, $tablanev2 WHERE $tablanev2.Koca_azonosito=$tablanev1.Azonosito GROUP BY Koca_azonosito HAVING Atlag1 >= $atlag1 ORDER BY Atlag2 ASC";
                        
                        }
                        //kilencedik rendezes: A felnevelt malacok átlaga szerint csökkenő
                        if( $rendezes=="A felnevelt malacok átlaga szerint csökkenő" )
                        {
                                $lekerdezes="SELECT $tablanev1.Sorszam As Sorszam, $tablanev2.Koca_azonosito AS Azonosito, $tablanev1.Anya_azonosito AS Anya_azonosito, $tablanev1.Apa_azonosito AS Apa_azonosito, $tablanev1.Szuletesi_datum AS Szuletesi_datum, $tablanev1.Fajta AS Fajta, $tablanev1.Nem AS Nem, $tablanev1.Tipus AS Tipus, COUNT($tablanev2.Sorszam) AS Fialasok, AVG($tablanev2.Fialt_malacok) AS Atlag1, AVG($tablanev2.Felnevelt_malacok) AS Atlag2 FROM $tablanev1, $tablanev2 WHERE $tablanev2.Koca_azonosito=$tablanev1.Azonosito GROUP BY Koca_azonosito HAVING Atlag1 >= $atlag1 ORDER BY Atlag2 DESC";
                        
                        }    
                        //masodik rendezes: Életkor szerint növekvő
                                //harmadik rendezes: Életkor szerint csökkenő
                                //negyedik rendezes: Malacozások száma szerint növekvő
                                //otodik rendezes: Malacozások száma szerint csökkenő
                                //hatodik rendezes: A fialt malacok átlaga szerint növekvő
                                //hetedik rendezes: A fialt malacok átlaga szerint csökkenő
                                //nyolcadik rendezes: A felnevelt malacok átlaga szerint növekvő
                                //kilencedik rendezes: A felnevelt malacok átlaga szerint csökkenő
                        // echo $lekerdezes."<br>";
                        //echo $lekerdezes;
                       /* $tabla=mysqli_query( $conn, $lekerdezes);
                                while($sor=mysqli_fetch_array($tabla))
                                {
                                        echo "<tr>
                                                <td>";
                                        echo $sor['Sorszam'];
                                        echo "  </td>
                                                <td>";
                                        echo $sor['Azonosito'];
                                        echo "  </td>
                                                <td>";
                                        echo $sor['Anya_azonosito'];
                                        echo "  </td>
                                                <td>";
                                        echo $sor['Apa_azonosito'];
                                        echo "  </td>
                                                <td>";
                                        echo $sor['Szuletesi_datum'];
                                        echo "  </td>
                                                <td>";
                                        echo $sor['Fajta'];
                                        echo "  </td>
                                                <td>";
                                        echo $sor['Nem'];
                                        echo "  </td>
                                                <td>";
                                        echo $sor['Tipus'];
                                        echo "  </td>
                                                <td>";
                                        echo $sor['Fialasok'];
                                        echo "  </td>
                                        <td>";       
                                        echo $sor['Atlag1'];
                                        echo "  </td>
                                                <td>";
                                        echo $sor['Atlag2'];
                                        
                                        echo "  </td>
                                                </tr>";
                                }
                                echo "</table>
                                </div>";*/
                }

                if($atlag1==NULL and $fialas_szam!=NULL)
                {
                        $atlag1=0;
                        echo "<b>Szűrés:</b> Fajta: <b>".$fajta."</b> Típus:<b>".$tipus."</b> Nem:<b> Nőstény</b>"." Rendezés:<b>".$rendezes."</b> Fialt malacok átlaga:<b>".$atlag1."</b> Fialások száma:<b>".$fialas_szam."</b><br><br><br>";
                       //elso rendezes: Nincs rendezés 
                        if( $rendezes=="Nincs rendezés" )
                        { 
                        
                                $lekerdezes="SELECT $tablanev1.Sorszam As Sorszam, $tablanev2.Koca_azonosito AS Azonosito, $tablanev1.Anya_azonosito AS Anya_azonosito, $tablanev1.Apa_azonosito AS Apa_azonosito, $tablanev1.Szuletesi_datum AS Szuletesi_datum, $tablanev1.Fajta AS Fajta, $tablanev1.Nem AS Nem, $tablanev1.Tipus AS Tipus, COUNT($tablanev2.Sorszam) AS Fialasok, AVG($tablanev2.Fialt_malacok) AS Atlag1, AVG($tablanev2.Felnevelt_malacok) AS Atlag2 FROM $tablanev1, $tablanev2 WHERE $tablanev2.Koca_azonosito=$tablanev1.Azonosito GROUP BY Koca_azonosito  HAVING Fialasok >= $fialas_szam ";                         
                        }
                                
                                
                        //masodik rendezes: Életkor szerint növekvő
                        if( $rendezes=="Életkor szerint növekvő" )
                        {
                                $lekerdezes="SELECT $tablanev1.Sorszam As Sorszam, $tablanev2.Koca_azonosito AS Azonosito, $tablanev1.Anya_azonosito AS Anya_azonosito, $tablanev1.Apa_azonosito AS Apa_azonosito, $tablanev1.Szuletesi_datum AS Szuletesi_datum, $tablanev1.Fajta AS Fajta, $tablanev1.Nem AS Nem, $tablanev1.Tipus AS Tipus, COUNT($tablanev2.Sorszam) AS Fialasok, AVG($tablanev2.Fialt_malacok) AS Atlag1, AVG($tablanev2.Felnevelt_malacok) AS Atlag2 FROM $tablanev1, $tablanev2 WHERE $tablanev2.Koca_azonosito=$tablanev1.Azonosito GROUP BY Koca_azonosito  HAVING Fialasok >= $fialas_szam ORDER BY Szuletesi_datum ASC";
                        
                        } 

                        //harmadik rendezes: Életkor szerint csökkenő 
                        if( $rendezes=="Életkor szerint csökkenő" )
                        {
                                $lekerdezes="SELECT $tablanev1.Sorszam As Sorszam, $tablanev2.Koca_azonosito AS Azonosito, $tablanev1.Anya_azonosito AS Anya_azonosito, $tablanev1.Apa_azonosito AS Apa_azonosito, $tablanev1.Szuletesi_datum AS Szuletesi_datum, $tablanev1.Fajta AS Fajta, $tablanev1.Nem AS Nem, $tablanev1.Tipus AS Tipus, COUNT($tablanev2.Sorszam) AS Fialasok, AVG($tablanev2.Fialt_malacok) AS Atlag1, AVG($tablanev2.Felnevelt_malacok) AS Atlag2 FROM $tablanev1, $tablanev2 WHERE $tablanev2.Koca_azonosito=$tablanev1.Azonosito GROUP BY Koca_azonosito  HAVING Fialasok >= $fialas_szam ORDER BY Szuletesi_datum DESC";
                        
                        }

                        //negyedik rendezes: Malacozások száma szerint növekvő 
                        if( $rendezes=="Malacozások száma szerint növekvő" )
                        {
                                $lekerdezes="SELECT $tablanev1.Sorszam As Sorszam, $tablanev2.Koca_azonosito AS Azonosito, $tablanev1.Anya_azonosito AS Anya_azonosito, $tablanev1.Apa_azonosito AS Apa_azonosito, $tablanev1.Szuletesi_datum AS Szuletesi_datum, $tablanev1.Fajta AS Fajta, $tablanev1.Nem AS Nem, $tablanev1.Tipus AS Tipus, COUNT($tablanev2.Sorszam) AS Fialasok, AVG($tablanev2.Fialt_malacok) AS Atlag1, AVG($tablanev2.Felnevelt_malacok) AS Atlag2 FROM $tablanev1, $tablanev2 WHERE $tablanev2.Koca_azonosito=$tablanev1.Azonosito GROUP BY Koca_azonosito HAVING Fialasok >= $fialas_szam ORDER BY Fialasok ASC";
                                
                        }
                        //otodik rendezes: Malacozások száma szerint csökkenő 
                        if( $rendezes=="Malacozások száma szerint csökkenő" )
                        {
                                $lekerdezes="SELECT $tablanev1.Sorszam As Sorszam, $tablanev2.Koca_azonosito AS Azonosito, $tablanev1.Anya_azonosito AS Anya_azonosito, $tablanev1.Apa_azonosito AS Apa_azonosito, $tablanev1.Szuletesi_datum AS Szuletesi_datum, $tablanev1.Fajta AS Fajta, $tablanev1.Nem AS Nem, $tablanev1.Tipus AS Tipus, COUNT($tablanev2.Sorszam) AS Fialasok, AVG($tablanev2.Fialt_malacok) AS Atlag1, AVG($tablanev2.Felnevelt_malacok) AS Atlag2 FROM $tablanev1, $tablanev2 WHERE $tablanev2.Koca_azonosito=$tablanev1.Azonosito GROUP BY Koca_azonosito HAVING Fialasok >= $fialas_szam ORDER BY Fialasok DESC";
                                
                        }
                        //hatodik rendezes: A fialt malacok átlaga szerint növekvő
                        if( $rendezes=="A fialt malacok átlaga szerint növekvő" )
                        {
                                $lekerdezes="SELECT $tablanev1.Sorszam As Sorszam, $tablanev2.Koca_azonosito AS Azonosito, $tablanev1.Anya_azonosito AS Anya_azonosito, $tablanev1.Apa_azonosito AS Apa_azonosito, $tablanev1.Szuletesi_datum AS Szuletesi_datum, $tablanev1.Fajta AS Fajta, $tablanev1.Nem AS Nem, $tablanev1.Tipus AS Tipus, COUNT($tablanev2.Sorszam) AS Fialasok, AVG($tablanev2.Fialt_malacok) AS Atlag1, AVG($tablanev2.Felnevelt_malacok) AS Atlag2 FROM $tablanev1, $tablanev2 WHERE $tablanev2.Koca_azonosito=$tablanev1.Azonosito GROUP BY Koca_azonosito HAVING Fialasok >= $fialas_szam ORDER BY Atlag1 ASC";
                        
                        } 
                        //hetedik rendezes: A fialt malacok átlaga szerint csökkenő 
                        if( $rendezes=="A fialt malacok átlaga szerint csökkenő" )
                        {
                                $lekerdezes="SELECT $tablanev1.Sorszam As Sorszam, $tablanev2.Koca_azonosito AS Azonosito, $tablanev1.Anya_azonosito AS Anya_azonosito, $tablanev1.Apa_azonosito AS Apa_azonosito, $tablanev1.Szuletesi_datum AS Szuletesi_datum, $tablanev1.Fajta AS Fajta, $tablanev1.Nem AS Nem, $tablanev1.Tipus AS Tipus, COUNT($tablanev2.Sorszam) AS Fialasok, AVG($tablanev2.Fialt_malacok) AS Atlag1, AVG($tablanev2.Felnevelt_malacok) AS Atlag2 FROM $tablanev1, $tablanev2 WHERE $tablanev2.Koca_azonosito=$tablanev1.Azonosito GROUP BY Koca_azonosito HAVING Fialasok >= $fialas_szam ORDER BY Atlag1 DESC";
                        
                        }
                        //nyolcadik rendezes: A felnevelt malacok átlaga szerint növekvő
                        if( $rendezes=="A felnevelt malacok átlaga szerint növekvő" )
                        {
                                $lekerdezes="SELECT $tablanev1.Sorszam As Sorszam, $tablanev2.Koca_azonosito AS Azonosito, $tablanev1.Anya_azonosito AS Anya_azonosito, $tablanev1.Apa_azonosito AS Apa_azonosito, $tablanev1.Szuletesi_datum AS Szuletesi_datum, $tablanev1.Fajta AS Fajta, $tablanev1.Nem AS Nem, $tablanev1.Tipus AS Tipus, COUNT($tablanev2.Sorszam) AS Fialasok, AVG($tablanev2.Fialt_malacok) AS Atlag1, AVG($tablanev2.Felnevelt_malacok) AS Atlag2 FROM $tablanev1, $tablanev2 WHERE $tablanev2.Koca_azonosito=$tablanev1.Azonosito GROUP BY Koca_azonosito  HAVING Fialasok >= $fialas_szam ORDER BY Atlag2 ASC";
                        
                        }
                        //kilencedik rendezes: A felnevelt malacok átlaga szerint csökkenő
                        if( $rendezes=="A felnevelt malacok átlaga szerint csökkenő" )
                        {
                                $lekerdezes="SELECT $tablanev1.Sorszam As Sorszam, $tablanev2.Koca_azonosito AS Azonosito, $tablanev1.Anya_azonosito AS Anya_azonosito, $tablanev1.Apa_azonosito AS Apa_azonosito, $tablanev1.Szuletesi_datum AS Szuletesi_datum, $tablanev1.Fajta AS Fajta, $tablanev1.Nem AS Nem, $tablanev1.Tipus AS Tipus, COUNT($tablanev2.Sorszam) AS Fialasok, AVG($tablanev2.Fialt_malacok) AS Atlag1, AVG($tablanev2.Felnevelt_malacok) AS Atlag2 FROM $tablanev1, $tablanev2 WHERE $tablanev2.Koca_azonosito=$tablanev1.Azonosito GROUP BY Koca_azonosito HAVING Fialasok >= $fialas_szam ORDER BY Atlag2 DESC";
                        
                        }    
                        //masodik rendezes: Életkor szerint növekvő
                                //harmadik rendezes: Életkor szerint csökkenő
                                //negyedik rendezes: Malacozások száma szerint növekvő
                                //otodik rendezes: Malacozások száma szerint csökkenő
                                //hatodik rendezes: A fialt malacok átlaga szerint növekvő
                                //hetedik rendezes: A fialt malacok átlaga szerint csökkenő
                                //nyolcadik rendezes: A felnevelt malacok átlaga szerint növekvő
                                //kilencedik rendezes: A felnevelt malacok átlaga szerint csökkenő
                        // echo $lekerdezes."<br>";
                        //echo $lekerdezes;
                        /*$tabla=mysqli_query( $conn, $lekerdezes);
                                while($sor=mysqli_fetch_array($tabla))
                                {
                                        echo "<tr>
                                                <td>";
                                        echo $sor['Sorszam'];
                                        echo "  </td>
                                                <td>";
                                        echo $sor['Azonosito'];
                                        echo "  </td>
                                                <td>";
                                        echo $sor['Anya_azonosito'];
                                        echo "  </td>
                                                <td>";
                                        echo $sor['Apa_azonosito'];
                                        echo "  </td>
                                                <td>";
                                        echo $sor['Szuletesi_datum'];
                                        echo "  </td>
                                                <td>";
                                        echo $sor['Fajta'];
                                        echo "  </td>
                                                <td>";
                                        echo $sor['Nem'];
                                        echo "  </td>
                                                <td>";
                                        echo $sor['Tipus'];
                                        echo "  </td>
                                                <td>";
                                        echo $sor['Fialasok'];
                                        echo "  </td>
                                        <td>";       
                                        echo $sor['Atlag1'];
                                        echo "  </td>
                                                <td>";
                                        echo $sor['Atlag2'];
                                        
                                        echo "  </td>
                                                </tr>";
                                }
                                echo "</table>
                                </div>";*/
                         } 

                         if ($atlag1!=NULL AND $fialas_szam!=NULL)
                         {
                                 //elso rendezes: Nincs rendezés 
                                echo "<b>Szűrés:</b> Fajta: <b>".$fajta."</b> Típus: <b>".$tipus."</b> Nem:<b> Nőstény</b>"." Rendezés: <b>".$rendezes."</b> Fialt malacok átlaga: <b>".$atlag1."</b> Fialások száma: <b>".$fialas_szam."</b><br><br><br>";
                        if( $rendezes=="Nincs rendezés" )
                        { 
                        
                                $lekerdezes="SELECT $tablanev1.Sorszam As Sorszam, $tablanev2.Koca_azonosito AS Azonosito, $tablanev1.Anya_azonosito AS Anya_azonosito, $tablanev1.Apa_azonosito AS Apa_azonosito, $tablanev1.Szuletesi_datum AS Szuletesi_datum, $tablanev1.Fajta AS Fajta, $tablanev1.Nem AS Nem, $tablanev1.Tipus AS Tipus, COUNT($tablanev2.Sorszam) AS Fialasok, AVG($tablanev2.Fialt_malacok) AS Atlag1, AVG($tablanev2.Felnevelt_malacok) AS Atlag2 FROM $tablanev1, $tablanev2 WHERE $tablanev2.Koca_azonosito=$tablanev1.Azonosito GROUP BY Koca_azonosito HAVING Atlag1 >= $atlag1 AND Fialasok >= $fialas_szam ";                         
                        }
                                
                                
                        //masodik rendezes: Életkor szerint növekvő
                        if( $rendezes=="Életkor szerint növekvő" )
                        {
                                $lekerdezes="SELECT $tablanev1.Sorszam As Sorszam, $tablanev2.Koca_azonosito AS Azonosito, $tablanev1.Anya_azonosito AS Anya_azonosito, $tablanev1.Apa_azonosito AS Apa_azonosito, $tablanev1.Szuletesi_datum AS Szuletesi_datum, $tablanev1.Fajta AS Fajta, $tablanev1.Nem AS Nem, $tablanev1.Tipus AS Tipus, COUNT($tablanev2.Sorszam) AS Fialasok, AVG($tablanev2.Fialt_malacok) AS Atlag1, AVG($tablanev2.Felnevelt_malacok) AS Atlag2 FROM $tablanev1, $tablanev2 WHERE $tablanev2.Koca_azonosito=$tablanev1.Azonosito GROUP BY Koca_azonosito HAVING Atlag1 >= $atlag1 AND Fialasok >= $fialas_szam ORDER BY Szuletesi_datum ASC";
                        
                        } 

                        //harmadik rendezes: Életkor szerint csökkenő 
                        if( $rendezes=="Életkor szerint csökkenő" )
                        {
                                $lekerdezes="SELECT $tablanev1.Sorszam As Sorszam, $tablanev2.Koca_azonosito AS Azonosito, $tablanev1.Anya_azonosito AS Anya_azonosito, $tablanev1.Apa_azonosito AS Apa_azonosito, $tablanev1.Szuletesi_datum AS Szuletesi_datum, $tablanev1.Fajta AS Fajta, $tablanev1.Nem AS Nem, $tablanev1.Tipus AS Tipus, COUNT($tablanev2.Sorszam) AS Fialasok, AVG($tablanev2.Fialt_malacok) AS Atlag1, AVG($tablanev2.Felnevelt_malacok) AS Atlag2 FROM $tablanev1, $tablanev2 WHERE $tablanev2.Koca_azonosito=$tablanev1.Azonosito GROUP BY Koca_azonosito HAVING Atlag1 >= $atlag1 AND Fialasok >= $fialas_szam ORDER BY Szuletesi_datum DESC";
                        
                        }

                        //negyedik rendezes: Malacozások száma szerint növekvő 
                        if( $rendezes=="Malacozások száma szerint növekvő" )
                        {
                                $lekerdezes="SELECT $tablanev1.Sorszam As Sorszam, $tablanev2.Koca_azonosito AS Azonosito, $tablanev1.Anya_azonosito AS Anya_azonosito, $tablanev1.Apa_azonosito AS Apa_azonosito, $tablanev1.Szuletesi_datum AS Szuletesi_datum, $tablanev1.Fajta AS Fajta, $tablanev1.Nem AS Nem, $tablanev1.Tipus AS Tipus, COUNT($tablanev2.Sorszam) AS Fialasok, AVG($tablanev2.Fialt_malacok) AS Atlag1, AVG($tablanev2.Felnevelt_malacok) AS Atlag2 FROM $tablanev1, $tablanev2 WHERE $tablanev2.Koca_azonosito=$tablanev1.Azonosito GROUP BY Koca_azonosito HAVING Atlag1 >= $atlag1 AND Fialasok >= $fialas_szam ORDER BY Fialasok ASC";
                                
                        }
                        //otodik rendezes: Malacozások száma szerint csökkenő 
                        if( $rendezes=="Malacozások száma szerint csökkenő" )
                        {
                                $lekerdezes="SELECT $tablanev1.Sorszam As Sorszam, $tablanev2.Koca_azonosito AS Azonosito, $tablanev1.Anya_azonosito AS Anya_azonosito, $tablanev1.Apa_azonosito AS Apa_azonosito, $tablanev1.Szuletesi_datum AS Szuletesi_datum, $tablanev1.Fajta AS Fajta, $tablanev1.Nem AS Nem, $tablanev1.Tipus AS Tipus, COUNT($tablanev2.Sorszam) AS Fialasok, AVG($tablanev2.Fialt_malacok) AS Atlag1, AVG($tablanev2.Felnevelt_malacok) AS Atlag2 FROM $tablanev1, $tablanev2 WHERE $tablanev2.Koca_azonosito=$tablanev1.Azonosito GROUP BY Koca_azonosito HAVING Atlag1 >= $atlag1 AND Fialasok >= $fialas_szam ORDER BY Fialasok DESC";
                                
                        }
                        //hatodik rendezes: A fialt malacok átlaga szerint növekvő
                        if( $rendezes=="A fialt malacok átlaga szerint növekvő" )
                        {
                                $lekerdezes="SELECT $tablanev1.Sorszam As Sorszam, $tablanev2.Koca_azonosito AS Azonosito, $tablanev1.Anya_azonosito AS Anya_azonosito, $tablanev1.Apa_azonosito AS Apa_azonosito, $tablanev1.Szuletesi_datum AS Szuletesi_datum, $tablanev1.Fajta AS Fajta, $tablanev1.Nem AS Nem, $tablanev1.Tipus AS Tipus, COUNT($tablanev2.Sorszam) AS Fialasok, AVG($tablanev2.Fialt_malacok) AS Atlag1, AVG($tablanev2.Felnevelt_malacok) AS Atlag2 FROM $tablanev1, $tablanev2 WHERE $tablanev2.Koca_azonosito=$tablanev1.Azonosito GROUP BY Koca_azonosito HAVING Atlag1 >= $atlag1 AND Fialasok >= $fialas_szam ORDER BY Atlag1 ASC";
                        
                        } 
                        //hetedik rendezes: A fialt malacok átlaga szerint csökkenő 
                        if( $rendezes=="A fialt malacok átlaga szerint csökkenő" )
                        {
                                $lekerdezes="SELECT $tablanev1.Sorszam As Sorszam, $tablanev2.Koca_azonosito AS Azonosito, $tablanev1.Anya_azonosito AS Anya_azonosito, $tablanev1.Apa_azonosito AS Apa_azonosito, $tablanev1.Szuletesi_datum AS Szuletesi_datum, $tablanev1.Fajta AS Fajta, $tablanev1.Nem AS Nem, $tablanev1.Tipus AS Tipus, COUNT($tablanev2.Sorszam) AS Fialasok, AVG($tablanev2.Fialt_malacok) AS Atlag1, AVG($tablanev2.Felnevelt_malacok) AS Atlag2 FROM $tablanev1, $tablanev2 WHERE $tablanev2.Koca_azonosito=$tablanev1.Azonosito GROUP BY Koca_azonosito HAVING Atlag1 >= $atlag1 AND Fialasok >= $fialas_szam ORDER BY Atlag1 DESC";
                        
                        }
                        //nyolcadik rendezes: A felnevelt malacok átlaga szerint növekvő
                        if( $rendezes=="A felnevelt malacok átlaga szerint növekvő" )
                        {
                                $lekerdezes="SELECT $tablanev1.Sorszam As Sorszam, $tablanev2.Koca_azonosito AS Azonosito, $tablanev1.Anya_azonosito AS Anya_azonosito, $tablanev1.Apa_azonosito AS Apa_azonosito, $tablanev1.Szuletesi_datum AS Szuletesi_datum, $tablanev1.Fajta AS Fajta, $tablanev1.Nem AS Nem, $tablanev1.Tipus AS Tipus, COUNT($tablanev2.Sorszam) AS Fialasok, AVG($tablanev2.Fialt_malacok) AS Atlag1, AVG($tablanev2.Felnevelt_malacok) AS Atlag2 FROM $tablanev1, $tablanev2 WHERE $tablanev2.Koca_azonosito=$tablanev1.Azonosito GROUP BY Koca_azonosito HAVING Atlag1 >= $atlag1 AND Fialasok >= $fialas_szam ORDER BY Atlag2 ASC";
                        
                        }
                        //kilencedik rendezes: A felnevelt malacok átlaga szerint csökkenő
                        if( $rendezes=="A felnevelt malacok átlaga szerint csökkenő" )
                        {
                                $lekerdezes="SELECT $tablanev1.Sorszam As Sorszam, $tablanev2.Koca_azonosito AS Azonosito, $tablanev1.Anya_azonosito AS Anya_azonosito, $tablanev1.Apa_azonosito AS Apa_azonosito, $tablanev1.Szuletesi_datum AS Szuletesi_datum, $tablanev1.Fajta AS Fajta, $tablanev1.Nem AS Nem, $tablanev1.Tipus AS Tipus, COUNT($tablanev2.Sorszam) AS Fialasok, AVG($tablanev2.Fialt_malacok) AS Atlag1, AVG($tablanev2.Felnevelt_malacok) AS Atlag2 FROM $tablanev1, $tablanev2 WHERE $tablanev2.Koca_azonosito=$tablanev1.Azonosito GROUP BY Koca_azonosito HAVING Atlag1 >= $atlag1 AND Fialasok >= $fialas_szam ORDER BY Atlag2 DESC";
                        
                        }    
                        //masodik rendezes: Életkor szerint növekvő
                                //harmadik rendezes: Életkor szerint csökkenő
                                //negyedik rendezes: Malacozások száma szerint növekvő
                                //otodik rendezes: Malacozások száma szerint csökkenő
                                //hatodik rendezes: A fialt malacok átlaga szerint növekvő
                                //hetedik rendezes: A fialt malacok átlaga szerint csökkenő
                                //nyolcadik rendezes: A felnevelt malacok átlaga szerint növekvő
                                //kilencedik rendezes: A felnevelt malacok átlaga szerint csökkenő
                        // echo $lekerdezes."<br>";
                       // echo $lekerdezes;
                        /*$tabla=mysqli_query( $conn, $lekerdezes);
                                while($sor=mysqli_fetch_array($tabla))
                                {
                                        echo "<tr>
                                                <td>";
                                        echo $sor['Sorszam'];
                                        echo "  </td>
                                                <td>";
                                        echo $sor['Azonosito'];
                                        echo "  </td>
                                                <td>";
                                        echo $sor['Anya_azonosito'];
                                        echo "  </td>
                                                <td>";
                                        echo $sor['Apa_azonosito'];
                                        echo "  </td>
                                                <td>";
                                        echo $sor['Szuletesi_datum'];
                                        echo "  </td>
                                                <td>";
                                        echo $sor['Fajta'];
                                        echo "  </td>
                                                <td>";
                                        echo $sor['Nem'];
                                        echo "  </td>
                                                <td>";
                                        echo $sor['Tipus'];
                                        echo "  </td>
                                                <td>";
                                        echo $sor['Fialasok'];
                                        echo "  </td>
                                        <td>";       
                                        echo $sor['Atlag1'];
                                        echo "  </td>
                                                <td>";
                                        echo $sor['Atlag2'];
                                        
                                        echo "  </td>
                                                </tr>";
                                }
                                echo "</table>
                                </div>";*/
                         }
                        
                         $tabla=mysqli_query( $conn, $lekerdezes);
                         $rows=mysqli_affected_rows($conn);
                         if($rows!=0)
                         {
                                while($sor=mysqli_fetch_array($tabla))
                                {
                                        echo "<tr>
                                                <td>";
                                        echo $sor['Sorszam'];
                                        echo "  </td>
                                                <td>";
                                        echo $sor['Azonosito'];
                                        echo "  </td>
                                                <td>";
                                        echo $sor['Anya_azonosito'];
                                        echo "  </td>
                                                <td>";
                                        echo $sor['Apa_azonosito'];
                                        echo "  </td>
                                                <td>";
                                        echo $sor['Szuletesi_datum'];
                                        echo "  </td>
                                                <td>";
                                        echo $sor['Fajta'];
                                        echo "  </td>
                                                <td>";
                                        echo $sor['Nem'];
                                        echo "  </td>
                                                <td>";
                                        echo $sor['Tipus'];
                                        echo "  </td>
                                                <td>";
                                        echo $sor['Fialasok'];
                                        echo "  </td>
                                        <td>";       
                                        echo $sor['Atlag1'];
                                        echo "  </td>
                                                <td>";
                                        echo $sor['Atlag2'];
                                        
                                        echo "  </td>
                                                </tr>";
                                }
                                
                         }
                         else
                                {
                                echo "<tr>
                                        <td colspan=11>
                                         Üres eredmény - nincsenek megfelelő adatok 
                                         </td> 
                                      </tr>";
                                }

                        echo "</table>
                            </div>";
                        }


                
            
        

        //masodik nagy eset ha hizo,suldo,malac,kan
        else 
        {
            $tablanev="sertesek_".$_SESSION['userid'];
            //$fajta=$_POST['fajta'];
            //$tipus=$_POST['tipus'];
            $rendezes=$_POST['rendezes'];
           // $sex = $_POST['sex'];
           // echo $tablanev." ".$fajta." ".$tipus." ".$rendezes." <br><br>";
        
            if ( $tipus=="Kan")
            {   
                echo "<b>Szűrés:</b> Fajta: <b>".$fajta."</b> Típus: <b>".$tipus."</b> Nem:<b> Hím</b>"." Rendezés: <b>".$rendezes."</b><br><br><br>";
               // $sex="Hím";
               // $tipus="Kan";               
                echo "<table border=2 id='table3'> 
                    <tr>
                        <th> Sorszám </th>
                        <th> Sertés azonosító </th>
                        <th> Anya azonosító </th>
                        <th> Apa azonosító </th>
                        <th> Születési dátum </th>
                        <th> Fajta </th>
                        <th> Nem </th>
                        <th> Típus </th>
                    </tr>";
                //elso rendezes: nincs rendezes /kan
                if( $rendezes=="Nincs rendezés")
                {   
                    $lekerdezes="SELECT Sorszam, Azonosito, Anya_azonosito, Apa_azonosito, Szuletesi_datum, Fajta, Nem, Tipus FROM $tablanev WHERE Nem LIKE 'Hím' and Fajta LIKE '$fajta' and Tipus LIKE '$tipus' and Allapot like 1";  
                    /*    
                    $tabla=mysqli_query( $conn, " SELECT Sorszam, Azonosito, Anya_azonosito, Apa_azonosito, Szuletesi_datum, Fajta, Nem, Tipus FROM $tablanev WHERE Nem LIKE 'Hím' and Fajta LIKE '$fajta' and Tipus LIKE '$tipus' ");

                        while($sor=mysqli_fetch_array($tabla))
                        {
                            echo "<tr>
                                    <td>";
                            echo $sor['Sorszam'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Azonosito'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Anya_azonosito'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Apa_azonosito'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Szuletesi_datum'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Fajta'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Nem'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Tipus'];
                            echo "  </td>
                                    </tr>";
                        }
                        //echo "</table>";*/
                }
                //masodik rendezes: Életkor szerint növekvő /kan  //harmadik rendezes:  Életkor szerint csökkenő
                if( $rendezes=="Életkor szerint növekvő")
                {
                        $lekerdezes="SELECT Sorszam, Azonosito, Anya_azonosito, Apa_azonosito, Szuletesi_datum, Fajta, Nem, Tipus FROM sertesek_1 WHERE Nem LIKE 'Hím' and Fajta LIKE 'Vörös mangalica' and Tipus LIKE 'Kan' and Allapot like 1 ORDER BY Szuletesi_datum ASC";
                   // $lekerdezes="SELECT Sorszam, Azonosito, Anya_azonosito, Apa_azonosito, Szuletesi_datum, Fajta, Nem, Tipus FROM $tablanev WHERE Nem LIKE 'Hím' and Fajta LIKE '$fajta' and Tipus LIKE '$tipus' and Allapot like 1 ORDER BY Szuletesi_datum ASC";
                    //SELECT Sorszam, Azonosito, Anya_azonosito, Apa_azonosito, Szuletesi_datum, Fajta, Nem, Tipus FROM sertesek_1 WHERE Nem LIKE 'Hím' and Fajta LIKE 'Vörös mangalica' and Tipus LIKE 'Kan' and Allapot like 1 ORDER BY Szuletesi_datum ASC

                    /*
                    $tabla=mysqli_query( $conn, " SELECT Sorszam, Azonosito, Anya_azonosito, Apa_azonosito, Szuletesi_datum, Fajta, Nem, Tipus FROM $tablanev WHERE Nem LIKE 'Hím' and Fajta LIKE '$fajta' and Tipus LIKE '$tipus' ORDER BY Szuletesi_datum ASC ");
                        while($sor=mysqli_fetch_array($tabla))
                        {
                            echo "<tr>
                                    <td>";
                            echo $sor['Sorszam'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Azonosito'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Anya_azonosito'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Apa_azonosito'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Szuletesi_datum'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Fajta'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Nem'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Tipus'];
                            echo "  </td>
                                    </tr>";
                        }
                       // echo "</table>";*/
                }
                ///harmadik rendezes:  Életkor szerint csökkenő /kan
                if( $rendezes=="Életkor szerint csökkenő")
                {
                    $lekerdezes="SELECT Sorszam, Azonosito, Anya_azonosito, Apa_azonosito, Szuletesi_datum, Fajta, Nem, Tipus FROM $tablanev WHERE Nem LIKE 'Hím' and Fajta LIKE '$fajta' and Tipus LIKE '$tipus' and Allapot like 1 ORDER BY Szuletesi_datum DESC";
                    /*
                    $tabla=mysqli_query( $conn, " SELECT Sorszam, Azonosito, Anya_azonosito, Apa_azonosito, Szuletesi_datum, Fajta, Nem, Tipus FROM $tablanev WHERE Nem LIKE 'Hím' and Fajta LIKE '$fajta' and Tipus LIKE '$tipus' ORDER BY Szuletesi_datum ASC ");
                        while($sor=mysqli_fetch_array($tabla))
                        {
                            echo "<tr>
                                    <td>";
                            echo $sor['Sorszam'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Azonosito'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Anya_azonosito'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Apa_azonosito'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Szuletesi_datum'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Fajta'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Nem'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Tipus'];
                            echo "  </td>
                                    </tr>";
                        }
                        //echo "</table>";*/
                }
                //echo "</table>";
                //echo $lekerdezes;
                $tabla=mysqli_query( $conn, $lekerdezes);
               // $rows=mysqli_affected_rows($conn);
                $rows=mysqli_affected_rows($conn);
                if($rows!=0)
                {
                        while($sor=mysqli_fetch_array($tabla))
                        {
                            echo "<tr>
                                    <td>";
                            echo $sor['Sorszam'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Azonosito'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Anya_azonosito'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Apa_azonosito'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Szuletesi_datum'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Fajta'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Nem'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Tipus'];
                            echo "  </td>
                                    </tr>";
                        }
                        echo "</table>";
                }
                 else  
                        echo "<tr>
                                <td colspan=8>
                                 Üres eredmény - nincsenek megfelelő adatok 
                                 </td> 
                              </tr>
                              </table>";   
                
                        
                      /*  while($sor=mysqli_fetch_array($tabla))
                        {
                            echo "<tr>
                                    <td>";
                            echo $sor['Sorszam'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Azonosito'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Anya_azonosito'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Apa_azonosito'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Szuletesi_datum'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Fajta'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Nem'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Tipus'];
                            echo "  </td>
                                    </tr>";
                        }
                        echo "</table>";*/

              
          }
        
        else 
             {      //malac,suldo
                    $sex=$_POST['sex'];
                    echo "<b>Szűrés:</b> Fajta: <b>".$fajta."</b> Típus: <b>".$tipus."</b> Nem:<b>".$sex."</b>"." Rendezés: <b>".$rendezes."</b><br><br><br>";
                    echo "<table border=2 id='table3'> 
                    <tr>
                        <th> Sorszám </th>
                        <th> Sertés azonosító </th>
                        <th> Anya azonosító </th>
                        <th> Apa azonosító </th>
                        <th> Születési dátum </th>
                        <th> Fajta </th>
                        <th> Nem </th>
                        <th> Típus </th>
                    </tr>";
                   

                    //elso rendezes: nincs rendezes /hizo,suldo,malac
                    if( $rendezes=="Nincs rendezés")
                    {   
                        if ($sex=="Mindkettő")  //him es nosteny
                        {
                           // echo $tablanev." ".$fajta." ".$tipus." ".$rendezes." ".$sex." <br><br>";
                           $lekerdezes="SELECT Sorszam, Azonosito, Anya_azonosito, Apa_azonosito, Szuletesi_datum, Fajta, Nem, Tipus FROM $tablanev WHERE Fajta LIKE '$fajta' AND Tipus LIKE '$tipus' and Allapot like 1";
                           /* $tabla=mysqli_query( $conn, " SELECT Sorszam, Azonosito, Anya_azonosito, Apa_azonosito, Szuletesi_datum, Fajta, Nem, Tipus FROM $tablanev WHERE Fajta LIKE '$fajta' AND Tipus LIKE '$tipus' and Allapot like 1 ") ;
                            while( $sor=mysqli_fetch_array($tabla) )
                            {
                            echo "<tr>
                                    <td>";
                            echo $sor['Sorszam'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Azonosito'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Anya_azonosito'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Apa_azonosito'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Szuletesi_datum'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Fajta'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Nem'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Tipus'];
                            echo "  </td>
                                    </tr>";
                            }
                        //echo "</table>";*/
                        }
                        else //him vagy nosteny
                        {
                          $lekerdezes="SELECT Sorszam, Azonosito, Anya_azonosito, Apa_azonosito, Szuletesi_datum, Fajta, Nem, Tipus FROM $tablanev WHERE Nem LIKE '$sex' AND Fajta LIKE '$fajta' AND Tipus LIKE '$tipus'  and Allapot like 1";
                          /*  $tabla=mysqli_query( $conn, " SELECT Sorszam, Azonosito, Anya_azonosito, Apa_azonosito, Szuletesi_datum, Fajta, Nem, Tipus FROM $tablanev WHERE Nem LIKE '$sex' AND Fajta LIKE '$fajta' AND Tipus LIKE '$tipus'  and Allapot like 1");
                           
                            while($sor=mysqli_fetch_array($tabla))
                            {
                                echo "<tr>
                                        <td>";
                                echo $sor['Sorszam'];
                                echo "  </td>
                                        <td>";
                                echo $sor['Azonosito'];
                                echo "  </td>
                                        <td>";
                                echo $sor['Anya_azonosito'];
                                echo "  </td>
                                        <td>";
                                echo $sor['Apa_azonosito'];
                                echo "  </td>
                                        <td>";
                                echo $sor['Szuletesi_datum'];
                                echo "  </td>
                                        <td>";
                                echo $sor['Fajta'];
                                echo "  </td>
                                        <td>";
                                echo $sor['Nem'];
                                echo "  </td>
                                        <td>";
                                echo $sor['Tipus'];
                                echo "  </td>
                                        </tr>";
                            }
                           // echo "</table>";*/
                          }
                        }
                    //masodik rendezes: Életkor szerint növekvő /hizo,suldo,malac
                    if( $rendezes=="Életkor szerint növekvő")
                    {   
                        if ($sex=="Mindkettő") //him es nosteny
                        {
                            $lekerdezes="SELECT Sorszam, Azonosito, Anya_azonosito, Apa_azonosito, Szuletesi_datum, Fajta, Nem, Tipus FROM $tablanev WHERE Fajta LIKE '$fajta' AND Tipus LIKE '$tipus' and Allapot like 1 ORDER BY Szuletesi_datum ASC";    
                            /*$tabla=mysqli_query( $conn, " SELECT Sorszam, Azonosito, Anya_azonosito, Apa_azonosito, Szuletesi_datum, Fajta, Nem, Tipus FROM $tablanev WHERE Fajta LIKE '$fajta' AND Tipus LIKE '$tipus' and Allapot like 1 ORDER BY Szuletesi_datum ASC ");
                            while($sor=mysqli_fetch_array($tabla))
                            {
                                echo "<tr>
                                        <td>";
                                echo $sor['Sorszam'];
                                echo "  </td>
                                        <td>";
                                echo $sor['Azonosito'];
                                echo "  </td>
                                        <td>";
                                echo $sor['Anya_azonosito'];
                                echo "  </td>
                                        <td>";
                                echo $sor['Apa_azonosito'];
                                echo "  </td>
                                        <td>";
                                echo $sor['Szuletesi_datum'];
                                echo "  </td>
                                        <td>";
                                echo $sor['Fajta'];
                                echo "  </td>
                                        <td>";
                                echo $sor['Nem'];
                                echo "  </td>
                                        <td>";
                                echo $sor['Tipus'];
                                echo "  </td>
                                        </tr>";
                            }
                       // echo "</table>";*/
                        }
                        else //him vagy nosteny
                        {
                             $lekerdezes="SELECT Sorszam, Azonosito, Anya_azonosito, Apa_azonosito, Szuletesi_datum, Fajta, Nem, Tipus FROM $tablanev WHERE Nem LIKE '$sex' and Fajta LIKE '$fajta' AND Tipus Like '$tipus' and Allapot like 1 ORDER BY Szuletesi_datum ASC";   
                            /*$tabla=mysqli_query( $conn, " SELECT Sorszam, Azonosito, Anya_azonosito, Apa_azonosito, Szuletesi_datum, Fajta, Nem, Tipus FROM $tablanev WHERE Nem LIKE '$sex' and Fajta LIKE '$fajta' AND Tipus Like '$tipus' and Allapot like 1 ORDER BY Szuletesi_datum ASC ");
                            while($sor=mysqli_fetch_array($tabla))
                            {
                                echo "<tr>
                                        <td>";
                                echo $sor['Sorszam'];
                                echo "  </td>
                                        <td>";
                                echo $sor['Azonosito'];
                                echo "  </td>
                                        <td>";
                                echo $sor['Anya_azonosito'];
                                echo "  </td>
                                        <td>";
                                echo $sor['Apa_azonosito'];
                                echo "  </td>
                                        <td>";
                                echo $sor['Szuletesi_datum'];
                                echo "  </td>
                                        <td>";
                                echo $sor['Fajta'];
                                echo "  </td>
                                        <td>";
                                echo $sor['Nem'];
                                echo "  </td>
                                        <td>";
                                echo $sor['Tipus'];
                                echo "  </td>
                                        </tr>";
                            }
                            //echo "</table>";*/
                        }
                    }
                    //harmadik rendezes:  Életkor szerint csökkenő /hizo,suldo,malac
                    if( $rendezes == "Életkor szerint csökkenő" )
                    {   
                        if ($sex=="Mindkettő") //him es nosteny
                        {
                           // echo $tablanev." ".$fajta." ".$tipus." ".$rendezes." ".$sex." <br><br>";
                            $lekerdezes="SELECT Sorszam, Azonosito, Anya_azonosito, Apa_azonosito, Szuletesi_datum, Fajta, Nem, Tipus FROM $tablanev WHERE Fajta LIKE '$fajta' AND Tipus LIKE '$tipus' and Allapot like 1 ORDER BY Szuletesi_datum DESC";    
                            /*$tabla=mysqli_query( $conn, " SELECT Sorszam, Azonosito, Anya_azonosito, Apa_azonosito, Szuletesi_datum, Fajta, Nem, Tipus FROM $tablanev WHERE Fajta LIKE '$fajta' AND Tipus LIKE '$tipus' and Allapot like 1 ORDER BY Szuletesi_datum DESC ");
                            while($sor=mysqli_fetch_array($tabla))
                            {
                            echo "<tr>
                                    <td>";
                            echo $sor['Sorszam'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Azonosito'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Anya_azonosito'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Apa_azonosito'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Szuletesi_datum'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Fajta'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Nem'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Tipus'];
                            echo "  </td>
                                    </tr>";
                            }
                        //echo "</table>";*/
                        }
                        else //him vagy nosteny
                        {
                            $lekerdezes="SELECT Sorszam, Azonosito, Anya_azonosito, Apa_azonosito, Szuletesi_datum, Fajta, Nem, Tipus FROM $tablanev WHERE Nem LIKE '$sex' and Fajta LIKE '$fajta' AND Tipus Like '$tipus' and Allapot like 1 ORDER BY Szuletesi_datum DESC";    
                           /* $tabla=mysqli_query( $conn, " SELECT Sorszam, Azonosito, Anya_azonosito, Apa_azonosito, Szuletesi_datum, Fajta, Nem, Tipus FROM $tablanev WHERE Nem LIKE '$sex' and Fajta LIKE '$fajta' AND Tipus Like '$tipus' and Allapot like 1 ORDER BY Szuletesi_datum DESC ");
                            while($sor=mysqli_fetch_array($tabla))
                            {
                                echo "<tr>
                                        <td>";
                                echo $sor['Sorszam'];
                                echo "  </td>
                                        <td>";
                                echo $sor['Azonosito'];
                                echo "  </td>
                                        <td>";
                                echo $sor['Anya_azonosito'];
                                echo "  </td>
                                        <td>";
                                echo $sor['Apa_azonosito'];
                                echo "  </td>
                                        <td>";
                                echo $sor['Szuletesi_datum'];
                                echo "  </td>
                                        <td>";
                                echo $sor['Fajta'];
                                echo "  </td>
                                        <td>";
                                echo $sor['Nem'];
                                echo "  </td>
                                        <td>";
                                echo $sor['Tipus'];
                                echo "  </td>
                                        </tr>";
                            }
                           // echo "</table>";*/
                        }
                    }
                    $tabla=mysqli_query( $conn, $lekerdezes);
                    $rows=mysqli_affected_rows($conn);
                    if($rows!=0)
                    {
                        while($sor=mysqli_fetch_array($tabla))
                        {
                            echo "<tr>
                                    <td>";
                            echo $sor['Sorszam'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Azonosito'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Anya_azonosito'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Apa_azonosito'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Szuletesi_datum'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Fajta'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Nem'];
                            echo "  </td>
                                    <td>";
                            echo $sor['Tipus'];
                            echo "  </td>
                                    </tr>";
                        }
                    }
                    else 
                    {
                        echo "<tr>
                        <td colspan=8>
                         Üres eredmény - nincsenek megfelelő adatok 
                         </td> 
                      </tr>";  
                    }
                    echo "</table>";
                }
            }
                
        }
                    /* rendezesek
                    Nincs rendezés 
                    Életkor szerint növekvő
                    Életkor szerint csökkenő
                    Malacozások száma szerint növekvő
                    Malacozások száma szerint csökkenő
                    A fialt malacok átlaga szerint növekvő
                    A fialt malacok átlaga szerint csökkenő
                    A felnevelt malacok átlaga szerint növekvő
                    A felnevelt malacok átlaga szerint csökkenő*/
        
}
?>
