<?php

   $conn=mysqli_connect("localhost","root","","piac");
   
   $tabla=mysqli_query($conn," SELECT vevoazon, nev FROM vevok");
      
	echo " <html>
            <body bgcolor=#f2f2f2>";
    
	echo "<table align=center border=1 bgcolor=#b3cccc cellpadding=5>
	     <tr>
		   <td align=center>  Vevőazonositó  </td>
		   <td align=center>  Név  </td>
		 </tr>";

	  while($sor=mysqli_fetch_array($tabla))
        {
            echo "
			      <tr>
				      <td align=center>";
					  echo $sor['vevoazon'];
			echo "
			          </td>
					  <td align=center>";
					  echo $sor['nev'];
			echo "
			          </td>
				   </tr>";
		}
		echo "</table>";
		echo "</body>
		      </html>";
			
?>