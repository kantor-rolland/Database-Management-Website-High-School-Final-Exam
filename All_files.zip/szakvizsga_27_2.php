<?php
    
    $conn=mysqli_connect("localhost","root","","szakvizsga_27");

     if(isset($_POST['kiirat']))
     {
       
       $tabla=mysqli_query( $conn, " SELECT  aru_kod , aru_neve, egyseg_ar, mennyiseg FROM raktar ORDER BY aru_kod asc, aru_neve asc") ;

       while($sor=mysqli_fetch_array($tabla))
      {
          echo $sor['aru_kod']."<br>";
          echo $sor['aru_neve']."<br>";
          echo $sor['egyseg_ar']."<br>";
          echo $sor['mennyiseg']."<br><br>";
      }
     }

     if(isset($_POST['modosit']))
     {
        $kod=$_POST['kod'];
        $nev=$_POST['nev'];
        $ar=$_POST['ar'];
        $mennyiseg=$_POST['mennyiseg'];
        $tabla=mysqli_query( $conn, " UPDATE `raktar` SET `aru_neve`='$nev',`egyseg_ar`='$ar',`mennyiseg`='$mennyiseg' WHERE aru_kod like '$kod' ") ;

     }
     if(isset($_POST['szamol']))
     {
       /* $kod=$_POST['kod'];
        $nev=$_POST['nev'];
        $ar=$_POST['ar'];
        $mennyiseg=$_POST['mennyiseg'];*/

        $tabla=mysqli_query( $conn, " SELECT SUM(egyseg_ar*mennyiseg) AS osszeg  From raktar ") ;
        $sor=mysqli_fetch_array($tabla);
        echo $sor['osszeg']."<br>";

     }


?>