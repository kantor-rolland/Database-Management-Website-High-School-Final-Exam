﻿<?php

   $conn=mysqli_connect("localhost","root","","piac");
   
   $tabla=mysqli_query($conn," SELECT vasarlasazon, datum, vevo, aru, mennyiseg, zoldseges FROM vasarlasok");
   
   echo " <html>
            <body bgcolor=#f2f2f2>";
			
   echo "<table align=center border=1 bgcolor=#b3cccc cellpadding=5>
	     <tr>
		   <td align=center>  Vásárlásazonositó  </td>
		   <td align=center>  Dátum  </td>
		   <td align=center>  Vevő  </td>
		   <td align=center>  Áru  </td>
		   <td align=center>  Mennyiség  </td>
		   <td align=center>  Zöldséges  </td>
		 </tr>";
        while($sor=mysqli_fetch_array($tabla))
        {
             
            echo "
			      <tr width=40%>
				      <td align=center>";
					  echo $sor['vasarlasazon'];
			echo "
			          </td>
					  <td align=center>";
					  echo $sor['datum'];
			echo "
			          </td>
					  <td align=center>";
					  echo $sor['vevo'];
			echo "
			          </td>
					  <td align=center>";
					  echo $sor['aru'];
			echo "
			          </td>
					  <td align=center>";
					  echo $sor['mennyiseg'];
			echo "
			          </td>
					  <td align=center>";
					  echo $sor['zoldseges'];
						
			echo "
			          </td>
				   </tr>";
		
        }
		echo "</table>";
		
		echo "</body>
		      </html>";

?>

