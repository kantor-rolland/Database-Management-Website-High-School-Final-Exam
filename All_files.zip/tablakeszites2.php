<?php

    $conn=mysqli_connect("localhost","root","","sertes");

    if (isset($_POST['x']))
{
    $tabla=mysqli_query( $conn, " CREATE table batugasssss
    (
      Azonosito int(10000) not null,
      Koca_azonosito varchar(13) not null,
      Kan_azonosito varchar(13) not null,
      Datum datetime not null
    ) " );
    
    //$tabla=mysqli_query( $conn, " ALTER TABLE bugatasssss CONVERT TO CHARACTER SET utf8 COLLATE utf8_general_ci " );
}
?>