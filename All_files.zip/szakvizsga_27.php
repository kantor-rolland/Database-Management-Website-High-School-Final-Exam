<html>
    <body>
        <form method=post action="szakvizsga_27_2.php">

        Adatok kiiratasa kod es aru szerint
        <input name=kiirat type=submit value="kiirat"> <br><br>
       
        Modosit:<br>

        Aru kod megadasa
        <input name=kod type=text ><br><br>

        Uj nev
        <input name=nev type=text><br><br>

        Uj ar
        <input name=ar type=number><br><br>

        Uj mennyiseg
        <input name=mennyiseg type=number><br><br>

        <input name=modosit type=submit value="modosit"><br><br>

        Osszertek meghatarozasa
        <input name=szamol type=submit value="osszertek"><br><br>

        </form>
    </body>
</html>