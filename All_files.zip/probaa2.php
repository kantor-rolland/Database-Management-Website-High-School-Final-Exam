<?php

session_start(); 

$conn=mysqli_connect("localhost","root","","sertes");
  
if (isset($_POST['x']))
{
    $tabla=mysqli_query( $conn, " CREATE table batugasssss
    (
      Azonosito int(10000) not null,
      Koca_azonosito varchar(13) not null,
      Kan_azonosito varchar(13) not null,
      Datum datetime not null
    ) " );
    
    //$tabla=mysqli_query( $conn, " ALTER TABLE bugatasssss CONVERT TO CHARACTER SET utf8 COLLATE utf8_general_ci " );
  

    //$tabla=mysqli_query( $conn, " ALTER TABLE postssss CONVERT TO CHARACTER SET utf8 COLLATE utf8_general_ci " );
    /*
    $tabla=mysqli_query( $conn, " CREATE table fialasok_
    (
      Azonosito int(10000) not null,
      Koca_azonosito varchar(13) not null,
      Kan_azonosito varchar(13) not null,
      Bugatas_sorszam int(10000) not null,
      Idopont datetime not null,
      Fialt_malacok int(10000) not null,
      Felnevelt_malacok int(10000) not null,
      Fiu int(10000) not null,
      Lany int(10000) not null,
      Elvalasztasi_idopont datetime not null,
      Alom_tomeg varchar(13) not null,
      21napos_tomeg varchar(13) not null
    ); " );
    
    $tabla=mysqli_query( $conn, " ALTER TABLE fialasok__ CONVERT TO CHARACTER SET utf8 COLLATE utf8_general_ci " );
    
    $tabla=mysqli_query( $conn, " CREATE table sertesek__
    (
      Sorszam int(10000) not null,
      Azonosito varchar(13) not null,
      Anya_azonosito varchar(13) not null,
      Apa_azonosito varchar(13) not null,
      Szuletesi_dopont datetime not null,
      Fajta varchar(30) not null,
      Nem varchar(30) not null,
      Tipus varchar(30) not null
    ); " );
    
    $tabla=mysqli_query( $conn, " ALTER TABLE sertesek__ CONVERT TO CHARACTER SET utf8 COLLATE utf8_general_ci " );
    
    $tabla=mysqli_query( $conn, " CREATE table takarmany_tipusok__
    (
      Azonosito int(10000) not null,
      Nev varchar(30) not null
    ); " );
    
    $tabla=mysqli_query( $conn, " ALTER TABLE takarmany_tipusok_ CONVERT TO CHARACTER SET utf8 COLLATE utf8_general_ci " );
  
    $tabla=mysqli_query( $conn, " CREATE table takarmany_
    (
      Azonosito int(10000) not null,
      Nev varchar(30) not null,
      Mennyiseg int(10000) not null,
      Napi_mennyiseg int(10000) not null
    ); " );
    
    $tabla=mysqli_query( $conn, " ALTER TABLE takarmany_ CONVERT TO CHARACTER SET utf8 COLLATE utf8_general_ci " );
    
*/

 }

?>