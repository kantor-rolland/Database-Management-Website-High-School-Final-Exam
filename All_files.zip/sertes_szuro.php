<html style=' overflow-x: hidden;'>
    <head>
        <title> Szűrő </title>
        <link rel="stylesheet" type="text/css" href="style.css">
    </head>
    <body>
  
  <form action="kijelentkezes.php" method="get">
		<button class="btn2" type=submit> Kijelentkezés </button>
    </form>
   <table width=95% align=center border=1 cellpadding=5 cellspacing=0 id='menu_1'>
	       <tr align=center>
			 <?php 
			 //	if($_SESSION['userid'] != 0)
			
					
			 ?>
			    <!-- amit az lat aki be van jelentkezve -->

				<tr>
					<td width=30%> 
						<?php
                            session_start();
                            if($_SESSION['userid'] == 0){
                        ?>
                            <a href=adatbazis_fooldal.php>
                        <?php
                            }
                            else {
                        ?>
                            <a href=felhasznalo_fooldal.php>
                        <?php
                            }
                        ?>
                        Főoldal
			 		</td>
			 		<td width=30%>
					 <a href=sertes_fajtak.php> A sertés fajtákról
			 		</td>
			 		<td width=30%>
				 	<a href=tenyesztok.php>	Tenyésztők
			 		</td>
				</tr>
		  </tr>
	   </table> <br><br>
	   
	
     <table width=95% align=center border=1 cellpadding=5 cellspacing=0 id='menu_2'>
	       <tr align=center>
		     <td width=20%> <a href=sertes.php> Sertés
		     </td>
		     <td width=20%> <a href=fialas.php> Fialás
		     </td>
		     <td width=20%> <a href=megtermekenyites.php> Megtermékenyítés
		     </td>
		     <td width=20%> <a href=gabona.php>Takarmány
			 </td>
			 </td>
		     <td width=20%>  Szűrés
		     </td>
		  </tr>
	   </table>
	   <br><br>
	   <table class="table_adatbazis" align=center>
           <tr>
               <td colspan=4> Adatbázisok </td>
           </tr>
           <tr>
               <td>
                    <!--<a href=adatbazis_sertes.php target=_blank > Sertés adatbázis -->
                    <form action="adatbazis_sertes.php" method="get" target="_blank">
                        <button class="btn" type="submit">Sertés adatbázis</button>
                    </form>
               </td>
               <td>
                    <!--<a href=adatbazis_fialas.php target=_blank > Fialás adatbázis -->
                    <form action="adatbazis_fialas.php" method="get" target="_blank">
                        <button class="btn" type="submit">Fialás adatbázis</button>
                    </form>
               </td>
               <td>
                    <!--<a href=adatbazis_megtermekenyites.php target=_blank > Megtermékenyítés adatbázis-->
                    <form action="adatbazis_megtermekenyites.php" method="get" target="_blank">
                        <button class="btn" type="submit">Megtermékenyítés adatbázis</button>
                    </form>
			   </td>
			   <td>
                    <!--<a href=adatbazis_megtermekenyites.php target=_blank > Megtermékenyítés adatbázis-->
                    <form action="adatbazis_takarmany.php" method="get" target="_blank">
                        <button class="btn" type="submit">Takarmány adatbázis</button>
                    </form>
               </td>
           </tr>
       </table> <br><br><br>

        <table align=center width=95% border=0 style=' border-radius: 12px 12px 12px 12px; table-layout: fixed;'>
            <tr>
                <td style="width: 22%">

               
        <form method=post action="sertes_szuro.php" >

        <h1>Szűrő</h1>
        
        Fajta kiválasztása <br>
        <select id="fajta" class="fajta" name=fajta placeholder="valassza ki" required>
	        <option>
                <option disabled selected> Válassza ki a fajtát</option>
		        <?php
                  //  session_start();
                   // $_SESSION['userid']=1;
                    $tablanev="sertesek_".$_SESSION['userid'];
		            $conn=mysqli_connect("localhost","root","","sertes");
		            $tabla=mysqli_query($conn," SELECT DISTINCT(Fajta) FROM $tablanev ");
                    while($sor=mysqli_fetch_array($tabla))
                     {
	                    echo "<option>";	
                        echo $sor['Fajta'];
                        echo "</option>"; 
                     }
		        ?>
		    </option>
        </select>
        <br><br>
        
        
        Típus kiválasztása<br>
        <select id="tipus" class="tipus" name=tipus required>
        <!--<option disabled selected>Termék neve</option> -->
	        <option>
                <option disabled selected> Válassza ki a típust </option>
		        <?php
                   // at kell irni az user id-t
                    //$_SESSION['userid']=1;
                    $tablanev="sertesek_".$_SESSION['userid'];
		            $conn=mysqli_connect("localhost","root","","sertes");
		            $tabla=mysqli_query($conn," SELECT DISTINCT(Tipus) FROM $tablanev ");
                    while($sor=mysqli_fetch_array($tabla))
                     {
	                    echo "<option>";	
                        echo $sor['Tipus'];
                        echo "</option>"; 
                     }
		        ?>
		    </option>
        </select>
        <br><br>
        
        Nem kiválasztása <!-- lehet checkbox --> <br>
        <select id="sex" class="sex" name=sex disabled required>
                     <option> Hím </option>
                     <option> Nőstény </option>
                     <option> Mindkettő </option>
        </select>     
        <br><br>  
       <!-- Rendezési szempont
            <select id="rendezes_1" class="rendezes_1" name=rendezes_1 disabled required>
                     <option> Életkor szerint növekvő</option>
                     <option> Életkor szerint csökkenő</option>
            </select>
        <br><br> -->
        
        Rendezési szempont <br>
        <select id="rendezes" class="rendezes" name=rendezes disabled required>
                     <option> Nincs rendezés </option> 
                     <option> Életkor szerint növekvő</option>
                     <option> Életkor szerint csökkenő</option>
                     <option> Malacozások száma szerint növekvő</option>
                     <option> Malacozások száma szerint csökkenő</option>
                     <option> A fialt malacok átlaga szerint növekvő</option>
                     <option> A fialt malacok átlaga szerint csökkenő</option>
                     <option> A felnevelt malacok átlaga szerint növekvő</option>
                     <option> A felnevelt malacok átlaga szerint csökkenő</option>
        </select>
        <br><br>

        Malacozási átlag <br>
        (az értéknél nagyobb) <br>
        <input id="atlag" class="atlag" name=atlag type=number min=0  placeholder="Írja be a malacozási átlagot" disabled >
        <br><br>

        Fialások száma <br>
        (az értéknél nagyobb) <br>
        <input id="fialas_darab" class="fialas_darab" name=fialas_darab min=0 type=number placeholder="Írja be a fialások számát" disabled>
        <br><br>
        
        <input class='submit' name=szures type=submit value=Szűrés>

        </form> </td>
            
           
                <td  style='overflow: auto;'  >
                
                    <!-- ide kell a fuggvenyt beirni -->
                    <?php

                        include 'sertes_szuro2.php';
                        szuro();
                    ?>
                
                </td>
            </tr>
        </table>
    </body>

    <script>

        //lekerem a tipus mezo tartalmat
		var tipus = document.querySelector(".tipus") //class nev

         // ezekkel mondtam mit csinaljon mikor egy adott esemeny van
        tipus.addEventListener('change', tipus_esemeny_kezelo)

        function tipus_esemeny_kezelo()
        {
            //lekerem a mezoket
            var sex = document.getElementById("sex") //id
            var rendezes_2 = document.getElementById("rendezes")
            var atlag = document.getElementById("atlag")
            var fialas_darab = document.getElementById("fialas_darab")

            if( tipus.value == "Koca")
            {
                document.getElementById("sex").disabled = true; //inaktiv
                document.getElementById("rendezes").disabled = false; //aktiv
                document.getElementById("atlag").disabled = false;
                document.getElementById("fialas_darab").disabled = false;

                var op = document.getElementById("rendezes").getElementsByTagName("option");
              // az option-et aktivva allitom
                op[3].disabled = false;
                op[4].disabled = false;
                op[5].disabled = false;
                op[6].disabled = false;
                op[7].disabled = false;
                op[8].disabled = false;
                op[9].disabled = false;
            }
            else
            
                if (tipus.value == "Kan")
                {
                    document.getElementById("rendezes").disabled = false;
                    document.getElementById("atlag").disabled = true;
                    document.getElementById("fialas_darab").disabled = true;
                    document.getElementById("sex").disabled = true; //inaktiv
                    var op = document.getElementById("rendezes").getElementsByTagName("option");
                
                    op[3].disabled = true;
                    op[4].disabled = true;
                    op[5].disabled = true;
                    op[6].disabled = true;
                    op[7].disabled = true;
                    op[8].disabled = true;
                    op[9].disabled = true;
                }
                
                else //hizo,suldo,malac
                {
                    document.getElementById("sex").disabled = false;
                //document.getElementById("rendezes_1").disabled = false;
                
                document.getElementById("rendezes").disabled = false;
                document.getElementById("atlag").disabled = true;
                document.getElementById("fialas_darab").disabled = true;
                var op = document.getElementById("rendezes").getElementsByTagName("option");
              
                   op[3].disabled = true;
                   op[4].disabled = true;
                   op[5].disabled = true;
                   op[6].disabled = true;
                   op[7].disabled = true;
                   op[8].disabled = true;
                   op[9].disabled = true;
                }
                

            
       /* // Ezzel lekerem a mezonek az erteket			
        var felnevelt = document.getElementById("felnevelt_malacok") //id

        // Ezzel beallitottam a tulajdonsagot
        felnevelt.setAttribute("max", fialt_malacok.value)
        // felnevelt.setAttribute("value", fialt_malacok.value)*/
}
    </script>
                     
</html>