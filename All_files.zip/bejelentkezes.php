<html>
    <title>
         Bejelentkezés
    </title>
    <link rel="stylesheet" type="text/css" href="style.css">
   
  <body>
    
    <form  method=post class="forms" action=bejelentkezes2.php>

      <h1> Bejelentkezés </h1>

      E-mail cím 

      <input name=email_cim2 type=text value="" pattern=" [\w-\.]+@([\w-]+\.)+[\w-]{2,4} " required oninvalid="this.setCustomValidity('Adja meg a helyes email-címet!')" >  <br><br>

      Jelszó

      <input id='password2' name=password2 type=password value="" required >  <br>
      <input type="checkbox" onclick="myFunction()">Megjelenít <br><br>

        <script>

          function myFunction() {
            var x = document.getElementById("password2");
            if (x.type === "password") {
              x.type = "text";
            } else {
              x.type = "password";
            }
          }
        </script>
        
      <input name=bejelentkezes type=submit value="Bejelentkezés">
      
      <?php

          session_start();
          if( $_SESSION['userid']==-1 )
          {
            echo " <script>
            alert('Hibás email-cím vagy jelszó !')
          </script>";
          }
      ?> 

    </form>
  </body>

</html>