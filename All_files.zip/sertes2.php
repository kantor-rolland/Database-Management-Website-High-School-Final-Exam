﻿ <?php
	   session_start();

	   $conn=mysqli_connect("localhost","root","","sertes");
	  
	   echo "Welcome {$_SESSION['userid']}"."<br>";

	   $tablanev="sertesek_".$_SESSION['userid'];
	  // echo $tablanev;
	   
	   if (isset($_POST['veglegesit']))
	   {
		   $sertes_sorszam=$_POST['sertes_sorsz'];
		   $sertes_azon=$_POST['sertesazon1'];
		   $koca_azon=$_POST['sertesazon2'];
		   $kan_azon=$_POST['sertesazon3'];
		   $datum=$_POST['szuldatum'];
		   $sertes_sex=$_POST['sex'];
		   $sertes_fajta=$_POST['fajta'];
		   $sertes_tipus=$_POST['tipus'];
		   $allapot=1;
		   
		   echo $sertes_azon." ".$koca_azon." ".$kan_azon." ".$datum." ".$sertes_sex." ".$sertes_fajta." ".$sertes_tipus."<br><br>";
		   
		 //  $ok1=0;
		//echo substr($sertes_azon, 4, 1);
		/*if ( strpos ("12345667", "4")==NULL )
		{echo "aaaa";}
		;*/
		//echo $sertes_azon[2];
		 //if ( strpos ($sertes_azon[4], "4")!=NULL ) 
		 //{
			// echo "talalt";
		 //}
		 //else echo  "hiba";
//echo strchr( "0123456789",substr($sertes_azon, 4, 1));		
//sertes-azon		  11
		 /* if(strlen($sertes_azon)!=12)
		   {
			   $ok1=1;
			   if(strlen($sertes_azon)==0)
				   echo "A sertés azonositó mező üres!"."<br>";
			   else echo "Hibás sertés azonositó, nem megfelelő az azonositó hosszúsága!"."<br>";
		   }
		   else if(strcmp( substr($sertes_azon, 0, 2),"RO")!=0)
		   {
			   $ok1=1;
			   echo "Hibás sertés azonositó, az azonositó kötelezően RO - val kell kezdődjön!"."<br>";
		   }
		   else 
		   {
			   
			   for( $i=2; $i<12; $i++)
			   {
				   //if ( strpos ("substr($sertes_azon, $i, 1)", "4")==NULL )
				   if( strchr("0123456789",$sertes_azon[$i])==NULL )
				   {
					   $ok1=1;
				   }
				   echo $sertes_azon[$i]."<br>";
			   }
			   if( $ok1==1)
			   {
				   echo "Hibás sertés azonositó, a 3-12. helyeken kötelezően szám kell szerepeljen!"."<br>";
			   }
		   }
		   
		   //koca_azon
		   $ok2=0;
		    if(strlen($koca_azon)!=12)
		   {
			   $ok2=1;
			   if(strlen($koca_azon)==0)
				   echo "A koca azonositó mező üres!"."<br>";
			   else echo "Hibás koca azonositó, nem megfelelő az azonositó hosszúsága!"."<br>";
		   }
		   else if(strcmp( substr($koca_azon, 0, 2),"RO")!=0)
		   {
			   $ok2=1;
			   echo "Hibás koca azonositó, az azonositó kötelezően RO - val kell kezdődjön!"."<br>";
		   }
		   else 
		   {
			   
			   for( $i=2; $i<12; $i++)
			   {
				  if( strchr("0123456789",$koca_azon[$i])==NULL )
				   {
					   $ok2=1;
				   }
			   }
			   if( $ok2==1)
			   {
				   echo "Hibás koca azonositó, a 3-12. helyeken kötelezően szám kell szerepeljen!"."<br>";
			   }
		   }
		   
		   //kan_azon
		   $ok3=0;
		    if(strlen($kan_azon)!=12)
		   {
			   $ok3=1;
			   if(strlen($kan_azon)==0)
				   echo "A kan azonositó mező üres!"."<br>";
			   else echo "Hibás kan azonositó, nem megfelelő az azonositó hosszúsága!"."<br>";
		   }
		   else if(strcmp( substr($kan_azon, 0, 2),"RO")!=0)
		   {
			   $ok3=1;
			   echo "Hibás kan azonositó, az azonositó kötelezően RO - val kell kezdődjön!"."<br>";
		   }
		   else 
		   {
			   
			   for( $i=2; $i<12; $i++)
			   {
				  if( strchr("0123456789",$kan_azon[$i])==NULL )
				   {
					   $ok3=1;
				   }
			   }
			   if( $ok3==1)
			   {
				   echo "Hibás kan azonositó, a 3-12. helyeken kötelezően szám kell szerepeljen!"."<br>";
			   }
		   }*/
		  
		   //osszesit
		  
		   //echo substr($sertes_azon, 0, 2);
			$conn=mysqli_connect("localhost","root","","sertes");
			
			////////////////////itt kell megnezni
			$tabla=mysqli_query( $conn, " INSERT INTO $tablanev (Sorszam, Azonosito, Anya_azonosito, Apa_azonosito, Szuletesi_datum, Fajta, Nem, Tipus, Allapot) VALUES ('$sertes_sorszam', '$sertes_azon', '$koca_azon', '$kan_azon', '$datum', '$sertes_fajta','$sertes_sex', '$sertes_tipus', '$allapot')" );
			/*Sorszam int(255) not null,
			Azonosito varchar(13) not null,
			Anya_azonosito varchar(13) not null,
			Apa_azonosito varchar(13) not null,
			Szuletesi_dopont datetime not null,
			Fajta varchar(30) not null,
			Nem varchar(30) not null,
			Tipus varchar(30) not null*/
		   
		   echo "<table>
	   <tr>
	      <td> Sorszam</td>
		  <td> Sertes azonosito</td>
		  <td> Anya azonositoja</td>
		  <td> Apa azonosito</td>
		  <td> Szuletesi datum</td>
		  <td> Nem</td>
		  <td> Fajta</td>
		  <td> Tipus</td>
	   </tr>
	      <td>"; echo $sertes_sorszam; echo "</td>
		  <td>"; echo $sertes_azon; echo "</td>
		  <td>"; echo $koca_azon; echo "</td>
		  <td>"; echo $kan_azon; echo "</td>
	   	  <td>"; echo $datum; echo "</td>
	   	  <td>"; echo $sertes_sex; echo "</td>
		  <td>"; echo $sertes_fajta; echo "</td>
		  <td>"; echo $sertes_tipus; echo "</td>
	   <tr>
	   </tr>
	 </table>";
	  header('Location: sertes.php');
	   }

	   if (isset($_POST['torles']))
	   {
		   $sertes_azonosito=$_POST['sertesazon'];
		   $conn=mysqli_connect("localhost","root","","sertes");
		   
		   $tabla=mysqli_query( $conn, " UPDATE $tablanev SET Allapot='0' WHERE Azonosito LIKE '$sertes_azonosito' " );
		   header('Location: sertes.php');
	   }
	   
	 ?>