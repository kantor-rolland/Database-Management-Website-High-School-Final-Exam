<?php

    $conn=mysqli_connect("localhost","root","","szakvizsga_6");

if(isset($_POST['modosit']))
{
  $leltar_szam=$_POST['leltar'];
  $szerzo=$_POST['szerzo'];
  $cim=$_POST['cim'];
  $olvaso=$_POST['olvaso'];
  $datum=$_POST['datum'];
  //$id_akt=0;
  
  $tabla=mysqli_query( $conn, " UPDATE `konyvtar` SET `szerzo`='$szerzo',`cim`='$cim',`olvaso_neve`='$olvaso',`datum_kivette`='$datum' WHERE `leltar_szam`='$leltar_szam'" ) ;
}

if(isset($_POST['kivalaszt']))
{
    $datum2=$_POST['datum2'];
    $tabla=mysqli_query( $conn, " SELECT `olvaso_neve` FROM konyvtar WHERE `datum_kivette` like '$datum2' ");
    while($sor=mysqli_fetch_array($tabla))
      {
          echo $sor['olvaso_neve']."<br>";
      }
}

if(isset($_POST['kivalaszt2']))
{
    $cim2=$_POST['cim2'];
    $tabla=mysqli_query( $conn,  " SELECT `leltar_szam`, `szerzo`, `cim`, `olvaso_neve`, `datum_kivette` FROM `konyvtar` WHERE cim like '$cim2' " );
    while($sor=mysqli_fetch_array($tabla))
      {
          echo $sor['leltar_szam']."<br>";
          echo $sor['szerzo']."<br>";
          echo $sor['cim']."<br>";
          echo $sor['olvaso_neve']."<br>";
          echo $sor['datum_kivette']."<br><br>";
      }
}
  ?>