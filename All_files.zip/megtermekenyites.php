﻿
<html>
  <head>
    <title> Megtermékenyítés</title>
  </head>
  <link rel="stylesheet" type="text/css" href="style.css">
  
  <body>
  <form action="kijelentkezes.php" method="get">
		<button class="btn2" type=submit> Kijelentkezés </button>
  </form>
  <table width=95% align=center border=1 cellpadding=5 cellspacing=0  id='menu_1'>
	       <tr align=center>
			 <?php 
			 //	if($_SESSION['userid'] != 0)
			
					
			 ?>
			    <!-- amit az lat aki be van jelentkezve -->

				<tr>
					<td width=30%>
						<?php
								session_start();
								if($_SESSION['userid'] == 0){
							?>
								<a href=adatbazis_fooldal.php>
							<?php
								}
								else {
							?>
								<a href=felhasznalo_fooldal.php>
							<?php
								}
							?>
							Főoldal
			 		</td>
			 		<td width=30%>
                     <a href=sertes_fajtak.php>  A sertés fajtákról
			 		</td>
			 		<td width=30%>
				 	<a href=tenyesztok.php>	Tenyésztők
			 		</td>
				</tr>
			
		  </tr>
       </table> <br><br>

      <table width=95% align=center border=1 cellpadding=5 cellspacing=0  id='menu_2'>
	       <tr align=center>
		     <td width=20%> <a href=sertes.php> Sertés
		     </td>
		     <td width=20%> <a href=fialas.php> Fialás
		     </td>
		     <td width=20%>  Megtermékenyítés
		     </td>
		     <td width=20%> <a href=gabona.php> Takarmány
			 </td>
			 <td width=20%> <a href=sertes_szuro.php> Szűrés
		     </td>
		  </tr>
	   </table>
	   <br><br>
	   <table class="table_adatbazis" align=center>
           <tr>
               <td colspan=4> Adatbázisok </td>
           </tr>
           <tr>
               <td>
                    <!--<a href=adatbazis_sertes.php target=_blank > Sertés adatbázis -->
                    <form action="adatbazis_sertes.php" method="get" target="_blank">
                        <button class="btn" type="submit">Sertés adatbázis</button>
                    </form>
               </td>
               <td>
                    <!--<a href=adatbazis_fialas.php target=_blank > Fialás adatbázis -->
                    <form action="adatbazis_fialas.php" method="get" target="_blank">
                        <button class="btn" type="submit">Fialás adatbázis</button>
                    </form>
               </td>
               <td>
                    <!--<a href=adatbazis_megtermekenyites.php target=_blank > Megtermékenyítés adatbázis-->
                    <form action="adatbazis_megtermekenyites.php" method="get" target="_blank">
                        <button class="btn" type="submit">Megtermékenyítés adatbázis</button>
                    </form>
			   </td>
			   <td>
                    <!--<a href=adatbazis_megtermekenyites.php target=_blank > Megtermékenyítés adatbázis-->
                    <form action="adatbazis_takarmany.php" method="get" target="_blank">
                        <button class="btn" type="submit">Takarmány adatbázis</button>
                    </form>
               </td>
           </tr>
       </table> <br><br><br>
	 
	
	 
	 <form  method=post class="forms" action=megtermekenyites2.php>
	 <h1> Megtermékenyítés hozzáadása</h1>	 
	 Sorszám:
	 <?php
		 // session_start();
		  $tablanev="megtermekenyites_".$_SESSION['userid'];

          $conn=mysqli_connect("localhost","root","","sertes");
          $tabla=mysqli_query($conn," SELECT MAX(Sorszam) AS maxi FROM $tablanev ");
          $sor=mysqli_fetch_array($tabla);
		  $sorszam_ertek=$sor['maxi']+1;
		  
		 /* $conn=mysqli_connect("localhost","root","","sertes");
          $tabla=mysqli_query($conn," SELECT MAX(Sorszam) AS maxi FROM $tablanev ");
          $sor=mysqli_fetch_array($tabla);
          $sorszam_ertek=$sor['maxi']+1;*/
     ?>
	 <input name=megterm_sorsz type=number value='<?php echo $sorszam_ertek; ?>' min='<?php echo $sorszam_ertek; ?>' max='<?php echo $sorszam_ertek; ?>'>
	 <br><br>
	 
	 Koca azonosítószáma:
	 <input id="sertesazon1" class="sertesazon1" name=sertesazon1 type=text value="" placeholder="pl:RO3568014659"  pattern="RO[0-9]{10}" required oninvalid="this.setCustomValidity('Adja meg a helyes azonosítószámot!')"> <br><br>
	
     Kan azonosítószáma:
	 <input id="sertesazon2" class="sertesazon2" name=sertesazon2 type=text value="" placeholder="pl:RO3568014659"  pattern="RO[0-9]{10}" required oninvalid="this.setCustomValidity('Adja meg a helyes azonosítószámot!')"> <br><br>
	 
	 <?php
	 /*$conn=mysqli_connect("localhost","root","","piac");*/
	 
	 $today = date("Y-m-d"); // 20201227
	 //echo $today;
	 ?>
	 
	 Időpont:
      <input name=mt_datum type=date value='<?php echo $today; ?>' min="2014-01-01" max='<?php echo $today; ?>' > <br><br>
	 
	 <input class='submit' name=veglegesit type=submit value="Véglegesít"> <br><br>
   </form>
  </body>

  	<script>
		//1. ha az anya azonosito mezo valtozik
		//lekerem az azonositot 
		var anya_azonosito = document.querySelector(".sertesazon1") //class nev

		// ezekkel mondtam mit csinaljon mikor egy adott esemeny van
		anya_azonosito.addEventListener('change', azonosito_2_esemeny_kezelo)

		function azonosito_2_esemeny_kezelo(){

		// Ezzel lekerem a mezonek az erteket			
		var apa_azonosito = document.getElementById("sertesazon2") //id
		var semmi="";
		var ok=0;

		if (apa_azonosito.value!=semmi)
			{
				
				if( (anya_azonosito.value != apa_azonosito.value) ) 
				{
					ok=1;
				}
				else 
				{
					ok=0;
				}
			
				if (ok==0) alert("Az azonosítók szigorúan különbözőek kell legyenek! \n Kérjük vizsgálja meg őket mert egyenlőek!") //console.log("egyenloek") 
				else console.log("nem egyenloek")
			}

		}
		//2. ha az apa azonosito mezo valtozik 

		//lekerem az azonositot 
		var apa_azonosito = document.querySelector(".sertesazon2") //class nev

		// ezekkel mondtam mit csinaljon mikor egy adott esemeny van
		apa_azonosito.addEventListener('change', azonosito_3_esemeny_kezelo)

		function azonosito_3_esemeny_kezelo(){

			// Ezzel lekerem a mezonek az erteket			
			var anya_azonosito = document.getElementById("sertesazon1") //id
			var semmi="";
			var ok=0;
			
			if( anya_azonosito.value!=semmi)
				
						
				if( (anya_azonosito.value != apa_azonosito.value) ) 
					{
						ok=1;
					}
					else 
					{
						ok=0;
					}
					
					if (ok==0) alert("Az azonosítók szigorúan különbözőek kell legyenek! \n Kérjük vizsgálja meg őket mert egyenlőek!"); //console.log("egyenloek") 
					else console.log("nem egyenloek");
				
		}

	</script>
</html>