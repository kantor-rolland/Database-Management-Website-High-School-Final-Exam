<html>
    <body>
        <form method=post action=szakvizsga_19_2.php>

        Adatok kiirasa
        <input name=kiirat type=submit value='kiirat'> <br><br>

        Szerzo megadasa
        <input name=szerzo type=text > <br><br>

        <input name=kiirat2 type=submit value='kiirat2'> <br><br>
        
        Modositas:<br>

        Kod megadasa
        <input name=kod  type=text value=""> <br><br>

        Szerzo megadasa
        <input name=szerzo2 type=text value=""> <br><br>

        Uj cim
        <input name=cim type=text value=""> <br><br>

        Kiadasi ev
        <input name=datum type=number value=""> <br><br>

        <input name=modosit type=submit value="Modosit">
        
        </form>
    </body>
</html>