<html>
    <head>
        <title> Sertés fajták</title>
        <link rel="stylesheet" type="text/css" href="style.css">
    </head>
    <body>
        <?php
            session_start();
            if($_SESSION['userid'] == 0){
        ?>
        <!--
        <table width=95% align=center border=1 cellpadding=5 cellspacing=0 >
	       <tr align=center>
				<?php 
				?>
					<td>
					<!--<a href=bejelentkezes.php> Bejelentkezés--> <!--
						<form action="bejelentkezes.php" method="get">
								<button class="btn2" type="submit">Bejelentkezés</button>
						</form>
							
					</td>
					<td>
						<!--<a href=regisztracio.php> regisztrálá1s --> <!--
						<form action="regisztracio.php" method="get">
								<button class="btn2" type="submit">Regisztrálás</button>
						</form>
					</td>
			</tr>
       </table> -->
                    <form action="bejelentkezes.php" method="get">
								<button class="btn2" type="submit">Bejelentkezés</button>
                    </form>
                    <form action="regisztracio.php" method="get">
								<button class="btn2" type="submit">Regisztrálás</button>
					</form>

        <?php
            }
            else {
        ?>
                 <form action="kijelentkezes.php" method="get">
					    <button class="btn2" type=submit> Kijelentkezés </button>
                 </form>
        <?php
            }
        ?>


    <table width=95% align=center border=1 cellpadding=5 cellspacing=0 id='menu_1' >
	       <tr align=center>
			 <?php 
			 //	if($_SESSION['userid'] != 0)
			
					
			 ?>
			    <!-- amit az lat aki be van jelentkezve -->

				<tr>
					<td width=30%>
                        <?php
                                    
                                    if($_SESSION['userid'] == 0){ //melyik legyen a fooldal, ha be van jelentkezve akkor a felhasznalos ha nincs akkor a szimpla
                                ?>
                                    <a href=adatbazis_fooldal.php>
                                <?php
                                    }
                                    else {
                                ?>
                                    <a href=felhasznalo_fooldal.php>
                                <?php
                                    }
                                ?>
                                Főoldal
                        </td>
			 		<td width=30%>
                      A sertés fajtákról
			 		</td>
			 		<td width=30%>
				 		<a href=tenyesztok.php> Tenyésztők
			 		</td>
                </tr>
               
                 <!--<form action="regisztracio.php" method="get">
								<button class="btn2" type="submit">Regisztrálás</button>
					</form>-->
               
                
			
		  </tr>
       </table> <br><br>

             <?php
               
                if($_SESSION['userid'] != 0){
            ?>
                <table width=95% align=center border=1 cellpadding=5 cellspacing=0 id='menu_2'>
                    <tr>
                        <td width=20%> <a href=sertes.php> Sertés
                        </td>
                        <td width=20%> <a href=fialas.php> Fialás
                        </td>
                        <td width=20%> <a href=megtermekenyites.php> Megtermékenyítés
                        </td>
                        <td width=20%> <a href=gabona.php> Takarmány
                        </td>
                        <td width=20%> <a href=sertes_szuro.php> Szűrés
		               </td>
                    </tr>
                </table>
        <br><br>
                
            <?php
                }
            ?>
        <table id="sertes_fajtak" style="border-radius: 12px 12px 12px 12px;">
            <tr>
                <td>
                    <h2>Mangalica</h2>
                    <p>
                    A mangalica sertés a XIX. században, a Kárpát medencében kialakult tipikus zsírsertés. Igénytelensége, jó zsírtermelő-képessége a maga idejében világhírűvé tette.
                    </p>
                    <p>
                        A mangalica szaporasága nem nagy, általában 4–8 csíkos malacot ellik.
                    </p>
                    <p>
                    A mangalica sertések bőre pigmentált szürkés-fekete, a természetes testnyílások és a túrókarima feketék, a csecsek és a körmök ugyancsak feketék. A fültő alsó szélén egy világos (3-5 cm átmérőjű) folt található fokozatos átmenettel a pigmentált bőrön, az úgynevezett „Wellmann folt”, ami a mangalica fajtajellegéhez tartozik.
                    </p>
                    <p>
                    A fej középhosszú az orrhát enyhén megtört, a fülek közép nagyok, előre hajlóak. A szemek barnák, a szemöldök és a szempillák feketék.
                    </p>
                    <p>
                    A faroktő jellegzetesen vastag, a farokbojt mindig fekete.
                    </p>
                    <p>
                    A minimális csecsszám 5-5 szabályos, jól fejlett csecs, mindkét oldalon.
                    </p>
                    <p>
                    A hátvonal enyhén ívelt, az ágyék rövid, vagy középhosszú. A csontozat finom, de nagyon szilárd.
                    </p>
                   
                    <ul align=left>
                        <li>Szőke mangalica</li>
                        <p>A szőke mangalica szőrzete a szürkétől a sárgáig, illetve a sárgásvörösig minden változatban előfordul, a sárgás-vöröses színeződést a tartási és talajviszonyok okozzák.
                        </p>
                        <li>Vörös mangalica</li>
                        <p> vörös mangalica szőrzete sötétebb, vagy világosabb árnyalatú barnásvörös. 
                        </p>
                        <li>Fecskehasú mangalica</li>
                        <p>A fecskehasú mangalica szőrzete az oldalakon és a háton fekete, a test alsó fele, a has és a toka a szájszegletig húzódóan fehér, vagy ezüstszürke. A farok szintén fehér, a farokbojt fekete.
                        </p>
                    </ul>
                    

                </td>
            </tr>
            <tr>
                <td>
                    <h2>Báznai</h2>
                    <p>
                    A báznai sertésfajtát a mangalica kocák és a berk kanok keresztezésével tenyésztették ki 1872-től, az erdélyi Báznán (ma Szeben megye).
                    </p>
                    <p>
                     A mangalicánál jobb hústermelésre képes fajtát hamar megszerették, főként Medgyes, Segesvár, Fogaras környékén lett a gazdaságok kedvence. Erdély elcsatolásával az állomány Romániába került, Magyarországon számottevő létszáma nincs.
                    </p>
                    <p>
                    Megjelenése érdekes, a teste nagyrészét, a test elejét és a fari részét fekete szőr borítja, míg a test közepe fehér, ezért "öves disznónak" is nevezik.
                    </p>
                    <p>
                    A báznai sertés szaporasága közepes, általában 7-11 öves malacot ellik.
                    A produktív hosszú élettartam a kocáknál figyelemre méltó: 8-12 ellés/ élet.
                    </p>
                    
                </td>

            </tr>
                <td> 
                    <h2>Duroc</h2> 
                    <p>
                    Gyors növekedési erélyű, nagy vágási súlyra hizlalható, alacsony fajlagos takarmányértékesítéssel bíró, tömeges hússertés.
                    </p>
                    <p>
                    Húsformái kifejezettek, karaja terjedelmes, sonkája széles és mélyre húzódó, lapockája telt.
                    </p>
                    <p>
                    Erős szervezeti szilárdságú, teste és csontozata robusztus, rámás, háta feszes, a lábai erőteljesek.
                    </p>
                    <p>
                    A nyak rövid, a mellkas hengeres. Feje jellegzetesen kúpos alakú, kissé rövid, széles homlokkal. Az orrhát enyhén homorú. Fülei rövidek, a haránt középvonaltól megtörtek, előre billenők.
                    </p>
                    <p>
                    Bőre rózsaszín, körmei palaszürkék, túrókarimája sötétbarnától a kékes színűig terjedő árnyalatú, pigmentált. Szőre sima és sűrű, színe a sötét cseresznyepirostól a sárgás világos vörösig terjed.
                    </p>
                                    
                </td>
            <tr>
                <td>
                    <h2>Pietrain </h2> 
                    <p>
                    Kiemelkedően jó vágóértékű, alacsony fehérárú %-ú, „szuperizmolt sertés”. A karaj, a combok és a lapockák extrém izmoltságúak.
                    </p>
                    <p>
                    A hát és a far „barázdált”. A bőr és a szalonnaköpeny vékony, az izmok jól látszanak a combok felületén, az erek kidudorodnak.
                    A csontozat finom, szilárd, a hátvonal feszesen egyenes. A fej könnyű, rövid, esetleg középhosszú, a profilvonal enyhén tört, a homlok széles. A fülek rövidek, felállóak, de lehetnek előrehajlóak is.
                        
                    </p>
                    <p>
                    Szabálytalan tarka sertés, szürke, vagy fehér testfelületén pigmentált foltokkal. A szőr színe a fehértől a feketéig foltosan változó, finom, sima lefutású, néha nagyon finom, hiányos növésű. A fehér, halvány foltostól a sötét alapszínű, fedett állatokig minden változat előfordul.
                    </p>
                    <p>
                        
                    </p>
                    <p>
                        
                    </p>
                    <p>
                        
                    </p>
                
                
                </td>
            </tr>
            <tr>
                <td>
                    <h2>Lapály</h2>
                    <p>
                        Kiemelkedő tejtermelő és malacfelnevelő képességű. Az egészséges tőgyrendszeren minimum hét-hét fejlett és egyenletesen elosztott csecsbimbóval termelnek.
                    </p>
                    <p>
                    A kocák a jó tartási és takarmányozási technológiát meghálálják, magas napi takarmány felvételre képesek a szoptatás ideje alatt.
                    Magas a választott malacszám és tömeg, alacsony kiesési % a szoptatás ideje alatt.

                    </p>
                    <p>
                    ó növekedési erélyű, takarmányértékesítő és hústermelő képességű. A vágóérték növelésénél különösen fontos a vékony hátszalonna és a jó húsminőség.
                    </p>
                    <p>
                    Különösen nagy rámájú, hosszú, feszes hátú, szilárd csontozatú. Konstitúciójuk kiváló, így hosszú produktív élettartamúak.
                    </p>
                    <p>
                    Szőrzete fehér színű, finom szálú, sima lefutású. Bőre halvány rózsaszín, pigmentmentes.
                    </p>
                    <p>
                        A körmök viaszsárgák.
                    </p>
                    <p>
                        A fej a törzzsel arányos, középhosszú, könnyű, profilvonala enyhén tört.
                    </p>
                    <p>
                         A fülek tőben megtörtek, előre lógóak és a fejjel arányosak.
                    </p>
                
                </td>
            </tr>
            <tr>
                <td>
                    <h2>Nagyfehér</h2>
                    <p>
                    Jó növekedési erélyű, takarmányértékesítő és hústermelő képességű, a húsminősége jó.
                    </p>
                    <p>
                    Univerzális fajta szaporasági és hízékonysági tulajdonságai miatt. Megbízhatóan termel kis- és nagyüzemi körülmények között is.
                    Kiváló szaporaságú, magas a született élő malacok száma és alomsúlya. A malacok életképessége jó, a kocák reprodukciós ideje rövid.
                    </p>
                    <p>
                        Nagy tejtermelő és malacfelnevelő képességű, ami a minimum hét-hét egészséges, fejlett és egyenletesen elosztott csecsbimbónak is köszönhető. Egészséges tőgyrendszerrel termelnek.
                    </p>
                    <p>
                        Magas napi takarmány felvételre képesek a szoptatás ideje alatt.
                Magas a választott malacszám és tömeg, alacsony kiesési % a szoptatás ideje alatt.
                    </p>
                    <p>
                        Szilárd szervezet, nagy ráma, hosszú törzs, feszes hát, erős csontozat és jó lábszerkezet jellemzi. Konstitúciójuk kiváló, így hosszú produktív élettartamúak.
                    </p>
                    <p>
                        
                    </p>
                    <p>
                        
                    </p>
                <!--Szőrzete kesely fehér színű, fényes, finom, hosszú szálú, testhez simuló és a testfelszínt egyenletesen takarja. Bőre halvány rózsaszínű, pigmentmentes. A körmei viaszsárgák. A feje a törzzsel arányos, középhosszú, könnyű, homloka közepesen széles, profilvonala enyhén tört, a fülei felfelé és előre állóak. -->
                </td>
            </tr>
            <tr>
                <td>
                    <h2>Vietnámi csüngőhasú</h2> 
                    <p>
                         A vietnámi csüngőhasú sertés Ázsiából származik.
                    </p>
                    <p>
                        Színe fekete, egy-két tenyésztett változata foltos (szürke, fekete, fehér) – ezek az állatok nagyobb tömegűek. Homlokán erős ráncok találhatók.
                    </p>
                    <p>
                        Teste rövid, mély, hasa csüngő, lábai rövidek. Feje törzséhez képest nagy, tokásodásra hajlamos. Füle hegyes oldalt szétálló, farka egyenes, bojtban végződő.
                    </p>
                    <p>
                        A kan általában rejtett heréjű, csak két ráncos, sötétebb folt mutatja a herék helyét. 
                    </p>
                    <p>
                        Agyarfoga jól fejlett (főleg a kanoknak).
                    </p>
                    <p>
                        14-16 csecsbimbója van szimmetrikusan elhelyeződve. Hibás csecsbimbó ritkán fordul elő.
                    </p>
                    <p>
                         Kifejlett kori testtömege 60 és 100 kg közé tehető, ez az állat átlag egy év alatt éri el ezt a vágótömeget.
                    </p>
                    <p>
                        A koca általában 2-14 malacot ellik.
                    </p>   
                </td>
            </tr>
            <tr>
                <td>
                  <h2>Landrace</h2>
                    <p>
                    A Landrace könnyen különbözik a többi fajtától.
                    </p>
                    <p>
                    Hosszú testük 185 cm-ig terjed, a mellkas átmérője 150-165 cm, 6 hónapig az állat súlya 100 kg. Egy felnőtt állat súlya 250-300 kg.
                    </p>
                    <p>
                    A lábak kerekek, de nem vastagok, zömök, elég erősek. A nyak hosszú, vastag. A fej kicsi, a fül közepes méretű, félig lógott, ritkán a sertés megtartja őket, a szem kicsi, sötét. Bőre világos rózsaszín, néha halvány, szinte fehér, ritka, rövid szőrszálakkal.
                    </p>
                    <p>
                    A sertések nem hajlamosak az agresszióra, ők mozgathatók. Az állatok, nagy súlyuk ellenére, könnyen mozoghatnak rövid, egyenes lábakkal.
                    </p>
                    <p>
                     Egy felnőtt disznó átlagos tömege 300 kg, koca esetében - 250 kg.
                    </p>
                    <p>
                    Fontos megjegyezni, hogy a fajtatiszta egyedek gyenge csontjai vannak, ezért számos tenyésztéshez ajánlatos a helyi fajtákon keresztelni. Ennek a keresztnek köszönhetően a sertések nemcsak erősebbé válnak, hanem jobb immunitásuk is van, és nagy különbségeket mutatnak a különböző éghajlati övezetekben fennálló túlélés, a fogva tartás körülményei.
                    </p>

                </td>   

            </tr>
            <tr>
                <td>
                    <h2>Hampshire</h2>
                    <p>
                    Rámás, tömeges, nagy növekedési erélyű hússertés.
                    </p>
                    <p>
                    A csontozat szilárd, robusztus, a lábvégek tiszták, kemények. A háta és ágyéka középhosszú, enyhén ívelt, mellkasa hengeres. Az orrhát egyenes, a fülek kicsik és fölfelé állóak, a toka száraz.
                    </p>
                    <p>
                    Alapszíne fekete, a maron és a lapockán lehúzódó fehér öv jellemzi. Előfordul, hogy a hátsó végtag csánk alatti része is fehér.
                    </p>
                    <p>
                    A körmök feketék, a pigmentmentes végtagokon viaszsárgák.
                    </p>
                    
                   
                     
                    
                </td>
            </tr>
        </table>
    </body>
</html>
<!--
Szőke mangalica 
Vörös mangalica 
Fecskehasú mangalica 
Báznai 
Duroc
Pietrain 
Lapály 
Nagyfehér
Vietnámi 
Landrace 
Hampshire-->