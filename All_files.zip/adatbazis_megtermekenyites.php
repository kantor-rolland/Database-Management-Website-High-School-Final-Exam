<?php

    session_start();
   $conn=mysqli_connect("localhost","root","","sertes");

   $tablanev="megtermekenyites_".$_SESSION['userid'];
   $tabla=mysqli_query($conn," SELECT Sorszam, Koca_azonosito, Kan_azonosito, Datum FROM $tablanev");
   
   echo " <html>
            <head>
                <title>Megtermékenyítés adatbázis </title>
            </head>
            <body bgcolor=#f2f2f2>
            <link rel='stylesheet' type='text/css' href='style.css' >";
			
   echo "<table id='table2' align=center border=1 bgcolor=#b3cccc cellpadding=5>
	     <tr>
           <th align=center>  Megtermékenyítés sorszáma </th> 
           <th align=center>  Koca azonosító </th>
           <th align=center>  Kan azonosító </th>
           <th align=center>  Megtermékenyítés időpontja </th>
         </tr>";
         
        $rows=mysqli_affected_rows($conn);
        if($rows!=0)
        {
            while($sor=mysqli_fetch_array($tabla))
            {
                echo "
                    <tr>
                        <td align=center>";
                        echo $sor['Sorszam'];
                echo "
                        </td>
                        <td align=center>";
                        echo $sor['Koca_azonosito'];
                echo "
                        </td>
                        <td align=center>";
                        echo $sor['Kan_azonosito'];
                echo " 
                            </td>
                            <td align=center>";
                            echo $sor['Datum'];
            
                echo "
                        </td>
                    </tr>";
            }
        }
        else
        {
            echo "<tr>
                    <td colspan=4>
                        Üres tábla - nincs feltöltött adat
                    </td>
                  </tr>";
        }
        
		echo "</table>";
		echo "</body>
		      </html>";

?>