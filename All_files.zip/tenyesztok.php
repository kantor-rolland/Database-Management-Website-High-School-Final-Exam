<html>
    <head>
        <title> Tenyésztők </title>
        <link rel="stylesheet" type="text/css" href="style.css">
    </head>
    
    <?php
            session_start();
            if($_SESSION['userid'] == 0){
        ?>
				<?php 
				?>
					<td>
				
                    <form action="bejelentkezes.php" method="get">
								<button class="btn2" type="submit">Bejelentkezés</button>
                    </form>
                    <form action="regisztracio.php" method="get">
								<button class="btn2" type="submit">Regisztrálás</button>
					</form>

            <?php
                }
                else {
            ?>
                 <form action="kijelentkezes.php" method="get">
					    <button class="btn2" type=submit> Kijelentkezés </button>
                 </form>
            <?php
                }
            ?>

     <body >
         <table width=95% align=center border=1 cellpadding=5 cellspacing=0 id='menu_1'>
	       <tr align=center>
			 <?php 
			 //	if($_SESSION['userid'] != 0)
			
					
			 ?>
			    <!-- amit az lat aki be van jelentkezve -->

				<tr>
					<td width=30%>  
                        <?php
                          //  session_start();
                            if($_SESSION['userid'] == 0){
                        ?>
                            <a href=adatbazis_fooldal.php>
                        <?php
                            }
                            else {
                        ?>
                            <a href=felhasznalo_fooldal.php>
                        <?php
                            }
                        ?>
                        Főoldal
			 		</td>
			 		<td width=30%>
                     <a href=sertes_fajtak.php> A sertés fajtákról
			 		</td>
			 		<td width=30%>
				 		Tenyésztők
			 		</td>
                </tr>
                    <?php
                       // session_start();
                        if($_SESSION['userid'] != 0){
                    ?>
			<!--	<form action="kijelentkezes.php" method="post">
					<input name=kijelentkezes type=submit value="Exit">
                </form>-->
                    <?php
                        }
                    ?>
                
			
		  </tr>
       </table> <br><br>

             <?php
               
                if($_SESSION['userid'] != 0){
            ?>
                <table width=95% align=center border=1 cellpadding=5 cellspacing=0 id='menu_2'> 
                    <tr>
                        <td width=20%> <a href=sertes.php> Sertés
                        </td>
                        <td width=20%> <a href=fialas.php> Fialás
                        </td>
                        <td width=20%> <a href=megtermekenyites.php> Megtermékenyítés
                        </td>
                        <td width=20%> <a href=gabona.php> Takarmány
                        </td>
                        <td width=20%> <a href=sertes_szuro.php> Szűrés
		                 </td>
                    </tr>
                </table>
        <br><br>
                
            <?php
                }
            ?>
        <table>
        </table>
        <br><br>
        <table id='table_tenyesztok' width=95% align=center cellspacing=20 cellpadding=5 bordercolor=#A9DFBF border=1 bgcolor=#eeeeee>

            <?php
                
                $conn=mysqli_connect("localhost","root","","sertes");
                $tabla=mysqli_query( $conn, " SELECT Azonosito FROM felhasznalok ");
                $i=0;
                while ( $sor=mysqli_fetch_array( $tabla ))
                {
                    $tenyesztok_tomb[$i]=$sor['Azonosito'];
                    $i++;
                }
                $tenyesztok_szama=$i;
                $sorok=$tenyesztok_szama/3;
                settype($sorok, "int"); //atallit int tipusra

                if($tenyesztok_szama%3 !=0 ) $sorok++;

                $aktualis_tenyeszto=1;

                for($i=1; $i<=$sorok and $aktualis_tenyeszto <= $tenyesztok_szama; $i++)
                {
                    $aktualis_oszlop=1;

                    echo "<tr>";
                    while( $aktualis_oszlop <=3 and $aktualis_tenyeszto <= $tenyesztok_szama)
                    {
                        $tabla2=mysqli_query($conn," SELECT Azonosito, Email_cim, Vezeteknev, Keresztnev, Farm_neve, Telefonszam, Megye, Telepules, Cim FROM felhasznalok WHERE Azonosito like '$aktualis_tenyeszto' ");
                        $sor=mysqli_fetch_array($tabla2);
                        //KIECHOZNI A HTMLT
                        /*echo "<td align=center  width=300px >"; 
                        echo "<table width=300px border=1> 
                                <tr>";
                        echo "<td>".$sor['Azonosito']."</td></tr>";
                        echo "<tr><td>".$sor['Vezeteknev']."</td></tr>";
                        echo "<tr><td>".$sor['Keresztnev']."</td></tr>";
                        echo "<tr><td>".$sor['Farm_neve']."</td></tr>";
                        echo "<tr><td>".$sor['Telefonszam']."</td></tr>";
                        echo "<tr><td>".$sor['Megye']."</td></tr>";
                        echo "
                             </table>";
                             echo "</td>";*/
                        echo"<td width=30%>";
                           // echo "<ul align=left>";
                                echo "<p> ";
                               // echo $sor['Azonosito'];
                               // echo "<br>";
                                echo " Vezetéknév: <b>";
                                echo $sor['Vezeteknev'];
                                echo "</b> <br>";
                                echo " Keresztnév: <b>";
                                echo $sor['Keresztnev'];
                                echo "</b> <br>";
                                echo " Farm neve: <b>";
                                echo $sor['Farm_neve'];
                                echo "</b> <br>";
                                echo " Telefonszám: <b>";
                                echo $sor['Telefonszam'];
                                echo "</b> <br>";
                                echo " Megye: <b>";
                                echo $sor['Megye'];
                                echo "</b> <br>";
                                echo " Település: <b>";
                                echo $sor['Telepules'];
                                echo "</b> <br>";
                                echo " Cím: <b>";
                                echo $sor['Cim'];
                                echo "</b> <br>";
                                echo "</p>";
                          //  echo "</ul>";
                        echo "</td>";

                        $aktualis_oszlop++;
                        $aktualis_tenyeszto++;
                    }
                    echo "</tr>";
                }
                echo "</table>";

            ?>
        </table>
    </body>
</html>