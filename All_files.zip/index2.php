<?php

$txt1="hello vilag";
$txt2="xii.g";
echo $txt1." ".$txt2;
echo "<br>";
echo"<br>"; //sortores
echo "csa";
echo "<br>";
echo 'varom a kajat';
echo "varom a kajat";

echo "<br>";
echo "<br>";
$a="Nagyon";
echo "$a Varom a vakaciot";
echo "<br>";
echo '$a Varom a vakaciot';

echo "<br>";
echo "<br>";

$d=date("D");
 if($d=="Fri") echo "Have a nice weekend";
 else echo "have a nice day";
 
echo "<br>";
echo "<br>";

$t1=array("piros", "lila" , "feher");
$t2[0]="barna";
$t2[1]="fekete";
$t2[2]="narancs";
echo $t1[0]." ".$t2[0]." ".$t2[1]." ".$t2[2];

echo "<br>";
echo "<br>";

$adatok1= array ("Peter"=>32, "Pista"=>30, "Imre"=>34);
echo $adatok1['Pista'];

echo "<br>";
echo "<br>";

$adatok2= array ("nev"=>"Jani", "osztaly"=>"XII.G", "media"=>10);
echo $adatok2['nev']." ".$adatok2['osztaly']." ".$adatok2['media'];

echo "<br>";
echo "<br>";

$i=1;
while($i<=10)
{
	echo $i," ";
	$i=$i+1;
}

echo "<br>";
echo "<br>";

$i=1;
do {
	echo $i." ";
	$i=$i+1;
}while ($i<=10);

echo "<br>";
echo "<br>";

for($i=1;$i<=10;$i=$i+1)
	echo $i." ";





?>