<html>
    <title>
        Regisztráció
    </title>
    <link rel="stylesheet" type="text/css" href="style.css">
   
  <body>
    <form  method=post class="forms" action=regisztracio2.php>
      <h1>Regisztráció </h1>


       E-mail cím 

       <input name=email_cim type=text value="" pattern="[\w-\.]+@([\w-]+\.)+[\w-]{2,4}" required oninvalid="this.setCustomValidity('Adja meg a helyes email-címet!')" >  <br><br>

       Jelszó

       <input name=password type=text value="" required >  <br><br>

       <!-- <hr style="width:50%;height:5;background-color:#737373"> -->
    
       Sorszám
       <?php
             $conn=mysqli_connect("localhost","root","","sertes");
             $tabla=mysqli_query($conn," SELECT MAX(Azonosito) AS maxi FROM felhasznalok");
             $sor=mysqli_fetch_array($tabla);
            $sorszam_ertek=$sor['maxi']+1;
       ?>
       <input  name=sorszam type=number value='<?php echo $sorszam_ertek; ?>' min='<?php echo $sorszam_ertek; ?>' max='<?php echo $sorszam_ertek; ?>'>
       <br><br>

       Vezetéknév

       <input name=v_nev type=text required>  <br><br>

       Keresztnév

       <input name=k_nev type=text  required>  <br><br>

       Farm neve

       <input name=farm_nev type=text required> <br><br>

       Telefonszám

       <input name=telefon type=text value="" required pattern="^[0-9]{10}$" oninvalid="this.setCustomValidity('Adja meg a helyes telefonszámot!')" >  <br><br>

       Megye 

       <input name=megye type=text value="" required >  <br><br>

       Település

       <input name=telepules type=text value="" required > <br><br>

       Lakcím/farm címe

       <input name=cim type=text value="" required >  <br><br>


       <input name=regisztralas type=submit value="Regisztrálás"> <br><br> 
    </form>
<!--
    <form  method=post action=regisztracio2.php>

      <h1> Bejelentkezés </h1>

      Email-cím 

      <input name=email_cim2 type=text value="" pattern=" [\w-\.]+@([\w-]+\.)+[\w-]{2,4} " required oninvalid="this.setCustomValidity('Adja meg a helyes email-címet!')" >  <br><br>

      Jelszó

      <input name=password2 type=text value="" required >  <br><br>

      <input name=bejelentkezes type=submit value="Bejelentkezés">

    </form> -->
  </body>

</html>