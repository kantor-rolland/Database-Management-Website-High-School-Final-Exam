<?php

    session_start();
   $conn=mysqli_connect("localhost","root","","sertes");

   $tablanev="fialasok_".$_SESSION['userid'];
   $tabla=mysqli_query($conn," SELECT Sorszam, Koca_azonosito, Kan_azonosito, Megtermekenyites_sorszam, Idopont, Fialt_malacok, Felnevelt_malacok, Fiu, Lany, Elvalasztasi_idopont FROM $tablanev " );
   
   echo " <html>
            <head>
                <title> Fialás adatbázis </title>
            </head>
            <body bgcolor=#f2f2f2>
            <link rel='stylesheet' type='text/css' href='style.css' >";
			
   echo "<table id='table2' align=center border=1 bgcolor=#b3cccc cellpadding=5>
	     <tr>
           <th align=center>  Fialás sorszáma </th> 
           <th align=center>  Anya azonosító </th>
           <th align=center>  Apa azonosító </th>
           <th align=center>  Megtermékenyítés sorszáma </th>
           <th align=center>  Időpont </th>
           <th align=center>  Fialt malacok száma </th>
           <th align=center>  Felnevelt malacok száma </th>
           <th align=center>  Fiú malacok száma </th>
		   <th align=center>  Lány malacok száma </th>
		   <th align=center>  Elválasztási időpont </th>
         </tr>";
        $rows=mysqli_affected_rows($conn);
        if($rows!=0)
        {
            while( $sor=mysqli_fetch_array ($tabla) )
            {
                echo "
                      <tr>
                          <td align=center>";
                          echo $sor['Sorszam'];
                echo "
                          </td>
                          <td align=center>";
                          echo $sor['Koca_azonosito'];
                echo "
                          </td>
                          <td align=center>";
                          echo $sor['Kan_azonosito'];
                echo " 
                            </td>
                            <td align=center>";
                            echo $sor['Megtermekenyites_sorszam'];
                echo " 
                            </td>
                            <td align=center>";
                            echo $sor['Idopont'];
                echo " 
                            </td>
                            <td align=center>";
                            echo $sor['Fialt_malacok'];
                echo " 
                            </td>
                            <td align=center>";
                            echo $sor['Felnevelt_malacok'];
                echo " 
                            </td>
                            <td align=center>";
                            echo $sor['Fiu'];
                echo " 
                            </td>
                            <td align=center>";
                            echo $sor['Lany'];
                echo " 
                            </td>
                            <td align=center>";
                            echo $sor['Elvalasztasi_idopont'];
                echo "
                          </td>
                       </tr>";
            }
            echo "</table>";
        }
        else
        {
            echo "<tr>
                    <td colspan=10>
                        Üres tábla - nincs feltöltött adat
                    </td>
                  </tr>";
        }
       
		echo "</body>
		      </html>";

?>