<?php

    session_start();

    $conn=mysqli_connect("localhost","root","","sertes");

    if(isset($_POST['bejelentkezes']))
    {
      $email_akt=$_POST['email_cim2'];
      $jelszo_akt=$_POST['password2'];
      $id_akt=0;
      //echo $email_akt."<br>".$jelszo_akt;
      $ok=0;
      $tabla=mysqli_query( $conn, " SELECT Azonosito, Email_cim, Jelszo FROM felhasznalok ") ;
      
      while($sor=mysqli_fetch_array($tabla))
      {
          if( (strcmp(trim($sor['Email_cim']), trim($email_akt)) == 0) && ( strcmp(trim($sor['Jelszo']), trim($jelszo_akt)) == 0))  //trim-> leveszi a feher karaktereket az adott muveletben
          { 
              $ok=1; 
              $id_akt=trim($sor['Azonosito']);
           } 
         // $a = (string)($sor['Email_cim'] == (string)$email_akt);
   
         //$b=strcmp( trim($sor['Email_cim']),trim( $email_akt));
         
       //    if ($a == true) echo "jo" ;
      } 
      if( $ok==1) 
      {
          
       echo "Sikeres bejelentkezés";
   
       $_SESSION['userid']=$id_akt;
       echo "Welcome {$_SESSION['userid']}";
       
   /*
       if (!$_SESSION['userid']){
           echo "Please login";
           exit;
       }
   */ 
       header('Location: adatbazis_fooldal.php');
      }
      else {
        $_SESSION['userid']=-1;
        header('Location: bejelentkezes.php');
     
      }
      
    }
 
?>