﻿<?php

session_start();

  $conn=mysqli_connect("localhost","root","","sertes");
  
  if(isset($_POST['veglegesit']))
  {
	  $takarmanynev=$_POST['takarmany_nev'];
	  $takarmanymennyiseg=$_POST['takarmany_mennyiseg'];
	  $takarmanynapi=$_POST['napi_mennyiseg'];
	  
	  //azonosito lekerese
	   $conn=mysqli_connect("localhost","root","","sertes");
       $tabla=mysqli_query($conn," SELECT Azonosito FROM takarmany_tipusok WHERE Nev like '$takarmanynev' ");
       $sor=mysqli_fetch_array($tabla);
	   $azonosito_ertek=$sor['Azonosito'];
	   
	   $tablanev="takarmany_".$_SESSION['userid'];
	  
	 // echo $azonosito_ertek." ".$takarmanynev." ".$takarmanymennyiseg." ".$takarmanynapi;
	  
	   //van-e mar ilyen tipusu takarmany az adatbazisban
	   $tabla=mysqli_query($conn," SELECT DISTINCT(Azonosito) FROM $tablanev ");
	   $sor=mysqli_fetch_array($tabla);
	   $ok=0;
	   while(  $sor=mysqli_fetch_array($tabla) )
	   {
		 if ( $sor['Azonosito']==$azonosito_ertek ) $ok=1;	   
	   }
	   
	   //ha van mar -> hozzaadja az eddigihez
	   if ( $ok==1 )
	   {
		   $tabla=mysqli_query($conn, " SELECT Mennyiseg FROM $tablanev WHERE Azonosito like '$azonosito_ertek' ");
		   $sor=mysqli_fetch_array($tabla);
		   $meglevo_mennyiseg=$sor['Mennyiseg'];
		   echo $meglevo_mennyiseg."<br>";
		   $teljes_mennyiseg=$meglevo_mennyiseg+$takarmanymennyiseg;

		   //modositas hosszaadja az eddigi ertekhez
		   $tabla=mysqli_query($conn, " UPDATE $tablanev SET Mennyiseg=$teljes_mennyiseg , Napi_mennyiseg=$takarmanynapi WHERE Azonosito like '$azonosito_ertek' ");
		}
		//ha nincs benne
		else
		{
			 $tabla=mysqli_query($conn," INSERT INTO $tablanev(Azonosito, Nev, Mennyiseg, Napi_mennyiseg) VALUES ('$azonosito_ertek','$takarmanynev','$takarmanymennyiseg','$takarmanynapi') ");
		}
  }
	   
	   
	  /*
	  //INSERT INTO takarmany(Azonosito, Nev, Mennyiseg, Napi_mennyiseg) VALUES ('$azonosito_ertek','$takarmanynev','$takarmanymennyiseg','$takarmanynapi')
	  $tabla=mysqli_query($conn," INSERT INTO takarmany(Azonosito, Nev, Mennyiseg, Napi_mennyiseg) VALUES ('$azonosito_ertek','$takarmanynev','$takarmanymennyiseg','$takarmanynapi') ");*/
	  
	  if(isset($_POST['veglegesit2']))
	  {
		  $tablanev="takarmany_".$_SESSION['userid'];
		  $takarmanynev_torol=$_POST['nev_torol'];
		  echo $takarmanynev_torol." "."<br>";
		  $tabla=mysqli_query($conn, " DELETE FROM $tablanev WHERE Nev like '$takarmanynev_torol' ");
		  echo "Sikeresen törlés, a hambárban már nincs ilyen nevű takarmány!";
		  
	  }
	  
	  if(isset($_POST['veglegesit3']))
	  {
		  $azonosito_uj=$_POST['sorszam_uj'];
		  $uj_takarmanynev=$_POST['ujtakarmany'];
		  
		  //nagybetusse alakitas
          $uj_takarmanynev = strtoupper($uj_takarmanynev);
		 
		  /*
		  $ok1=0;
		  if( strlen($uj_takarmanynev)!=0 ) //hossz
		  {
			  if ( ctype_upper($uj_takarmanynev[0])/*($uj_takarmanynev[1]>=65) and ($uj_takarmanynev[1]<=90) or strchr("ÁÉÍÓÖŐÚÜŰ",$uj_takarmanynev[0])!=NULL ) //hogy szigoruan nagybetu az elso karakter
			  {
					$ok1=0;	
			  }
			  else 
			  {
				  $ok1=1;
                echo "Hibás takarmány név, a név kötelezően nagy betűvel kell kezdődjön!"."<br>";
			  }
			  //ha a kezdobetu jo, nezi a tobbit
			  if($ok1==0)
			  {
				  //$ok1=0;
			  $h=strlen($uj_takarmanynev);
			  /*
			   for( $i=1; $i<$h ; $i++) //a tobbi resz kotelezoen kicsi betu
			   {
				   if( ctype_upper($uj_takarmanynev.substr(1)) /*!($uj_takarmanynev[$i]>=97 and $uj_takarmanynev[$i]<=122)  or strchr("áéíóöőúüű",$uj_takarmanynev[$i])==NULL )
				   {
					   
					   $ok1=1; 	
				   }
			   }
               */	
			  /*	
			   //$kisbetus=substr($uj_takarmanynev,1); //ha nem ekezettel kezdodik
			   $kisbetus=substr($uj_takarmanynev,2); //ha ekezettel kezdodik a szo
			   //a masodiktol a vegeig kicsik-e
               if(ctype_lower($kisbetus))
			   {
				   $ok1=0;
			   }			
               else $ok1=1;			   
			   if ($ok1==1) echo "Hibás takarmány név, az első karakter kivételével az összes többi kötelezően kis betűvel kell legyen!"."<br>";
			  }
			  
			  
		  }
		  else echo "A mező üres, adja meg az új takarmány nevét!";
		  */

           //van-e mar ilyen tipusu takarmany az adatbazisban
	      $tabla=mysqli_query($conn," SELECT Nev FROM takarmany_tipusok ");
	      $sor=mysqli_fetch_array($tabla);
	      $ok1=0;
	      while(  $sor=mysqli_fetch_array($tabla) )
	       {
		       if (strcmp($uj_takarmanynev, $sor['Nev']) == 0)  $ok1=1;	   
	       }
		  if ($ok1==0)
		  {
			  $tabla=mysqli_query($conn, " INSERT INTO takarmany_tipusok(Azonosito, Nev) VALUES ('$azonosito_uj','$uj_takarmanynev') ");
			  echo "Sikeresen hozzáadta a '$uj_takarmanynev'-t a takarmány típus listához";
		  }
		  else echo "Mar van ilyen";
		  echo $azonosito_uj." ".$uj_takarmanynev;
		  
		// $tabla=mysqli_query($conn, " INSERT INTO takarmany_tipusok(Azonosito, Nev) VALUES ('$azonosito_uj','$uj_takarmanynev') ");
		 // INSERT INTO takarmany_tipusok(Azonosito, Nev) VALUES ([value-1],[value-2])

		 
	  }
	  header('Location: gabona.php');
/*&aacute;= á

&Aacute;= Á

&ouml;= ö

&Ouml;= Ö

&eacute;= é

&Eacute;= É

&uuml;= ü

&Uuml;= Ü

&iacute;= í

&Iacute;= Í

&otilde;= ő

&Otilde;= Ő

&oacute;= ó

&Oacute;= Ó

&ucirc;= ű

&Ucirc;= Ű

&uacute;= ú

&Uacute;= Ú

*/
	  
  
?>