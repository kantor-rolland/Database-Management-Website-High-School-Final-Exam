<?php

    $conn=mysqli_connect("localhost","root","","szakvizsga_13");

if(isset($_POST['kiiratas']))
{
  $tabla=mysqli_query( $conn, " SELECT `kod`, `vezetek_nev`, `kereszt_nev`, `lakcim`, `szuletesi_datum`, `gyerek_szam`, `vegzettseg`, `alkalmazas_datuma` FROM `szemelyzet` ORDER BY vezetek_nev ASC , kereszt_nev ASC ") ;
  while($sor=mysqli_fetch_array($tabla))
      {
          echo $sor['kod']."<br>";
          echo $sor['vezetek_nev']."<br>";
          echo $sor['kereszt_nev']."<br>";
          echo $sor['lakcim']."<br>";
          echo $sor['szuletesi_datum']."<br>";
          echo $sor['gyerek_szam']."<br>";
          echo $sor['vegzettseg']."<br>";
          echo $sor['alkalmazas_datuma']."<br>";
      }
}

if(isset($_POST['beszur']))
{
    $vezeteknev=$_POST['vnev'];
    $keresztknev=$_POST['knev'];
    $kod=$_POST['kod'];
    $lakcim=$_POST['cim'];
    $szuletes=$_POST['sz_datum'];
    $gyerek=$_POST['gyerekszam'];
    $vegzettseg=$_POST['vegzettseg1'];
    $alkalmazas=$_POST['alk_datum'];

   
    $tabla=mysqli_query( $conn, " INSERT INTO `szemelyzet`(`kod`, `vezetek_nev`, `kereszt_nev`, `lakcim`, `szuletesi_datum`, `gyerek_szam`, `vegzettseg`, `alkalmazas_datuma`) VALUES ('$kod','$vezeteknev','$keresztknev','$lakcim','$szuletes','$gyerek','$vegzettseg','$alkalmazas')");
  
}

if(isset($_POST['kivalaszt']))
{
    $gyerek2=$_POST['gyerekszam2'];
    $vegzettseg2=$_POST['vegzettseg2'];
  $tabla=mysqli_query( $conn, " SELECT  `vezetek_nev`, `kereszt_nev`, `gyerek_szam`, `vegzettseg`, `alkalmazas_datuma` FROM `szemelyzet` WHERE gyerek_szam > '$gyerek2' and vegzettseg like '$vegzettseg2' ") ;
  while($sor=mysqli_fetch_array($tabla))
      {
    
          echo $sor['vezetek_nev']."<br>";
          echo $sor['kereszt_nev']."<br>";
          echo $sor['gyerek_szam']."<br>";
          echo $sor['vegzettseg']."<br><br>";
     
      }
}


  ?>