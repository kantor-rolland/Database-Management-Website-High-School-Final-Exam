<html>
    <body>
        <form method=post action=tablakeszites2.php>
            <input name=x type="submit" value="uj">
        </form>
    </body>
</html>