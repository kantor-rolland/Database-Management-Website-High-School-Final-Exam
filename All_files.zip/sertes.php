﻿
<html>
  <head>
	<title> Sertés</title>
	<link rel="stylesheet" type="text/css" href="style.css">
  </head>
  	<?php
		session_start();
		$tablanev="sertesek_".$_SESSION['userid'];
  	?>
  <body> 

    <form action="kijelentkezes.php" method="get">
		<button class="btn2" type=submit> Kijelentkezés </button>
     </form>
  	<table width=95% align=center border=1 cellpadding=5 cellspacing=0 id='menu_1' >
	       <tr align=center>
			 <?php 
			 //	if($_SESSION['userid'] != 0)
			
					
			 ?>
			    <!-- amit az lat aki be van jelentkezve -->

				<tr>
					<td width=30%>
						<?php
								//session_start();
								if($_SESSION['userid'] == 0){
							?>
								<a href=adatbazis_fooldal.php>
							<?php
								}
								else {
							?>
								<a href=felhasznalo_fooldal.php>
							<?php
								}
							?>
							Főoldal
			 		</td>
			 		<td width=30%>
					 <a href=sertes_fajtak.php> A sertés fajtákról
			 		</td>
			 		<td width=30%>
				 	<a href=tenyesztok.php>	Tenyésztők
			 		</td>
				</tr>
			
		  </tr>
       </table> <br><br>
    

	<table width=95% align=center border=1 cellpadding=5 cellspacing=0 id='menu_2'>
	       <tr align=center>
		     <td width=20%>  Sertés
		     </td>
		     <td width=20%> <a href=fialas.php> Fialás
		     </td>
		     <td width=20%> <a href=megtermekenyites.php> Megtermékenyítés
		     </td>
		     <td width=20%> <a href=gabona.php> Takarmány
			 </td>
			 <td width=20%> <a href=sertes_szuro.php> Szűrés
		     </td>
		  </tr>
		  <tr>
			 <!-- <td>
			  <form action="kijelentkezes.php" method="post">
					<input name=kijelentkezes type=submit value="Exit">
				</form>
			  </td> -->
		  </tr>
	   </table>
	   <br><br>
	   <table class="table_adatbazis" align=center>
           <tr>
               <td colspan=4> Adatbázisok </td>
           </tr>
           <tr>
               <td>
                    <!--<a href=adatbazis_sertes.php target=_blank > Sertés adatbázis -->
                    <form action="adatbazis_sertes.php" method="get" target="_blank">
                        <button class="btn" type="submit">Sertés adatbázis</button>
                    </form>
               </td>
               <td>
                    <!--<a href=adatbazis_fialas.php target=_blank > Fialás adatbázis -->
                    <form action="adatbazis_fialas.php" method="get" target="_blank">
                        <button class="btn" type="submit">Fialás adatbázis</button>
                    </form>
               </td>
               <td>
                    <!--<a href=adatbazis_megtermekenyites.php target=_blank > Megtermékenyítés adatbázis-->
                    <form action="adatbazis_megtermekenyites.php" method="get" target="_blank">
                        <button class="btn" type="submit">Megtermékenyítés adatbázis</button>
                    </form>
			   </td>
			   <td>
                    <!--<a href=adatbazis_megtermekenyites.php target=_blank > Megtermékenyítés adatbázis-->
                    <form action="adatbazis_takarmany.php" method="get" target="_blank">
                        <button class="btn" type="submit">Takarmány adatbázis</button>
                    </form>
               </td>
           </tr>
       </table> <br><br><br>
     
	   
	 <form name=sertes_form class="forms" method=post action=sertes2.php>
		 
		 <h1>Sertés hozzáadása</h1>
		 
	 Sorszám:
	 <?php
          $conn=mysqli_connect("localhost","root","","sertes");
          $tabla=mysqli_query($conn," SELECT MAX(Sorszam) AS maxi FROM $tablanev ");
          $sor=mysqli_fetch_array($tabla);
          $sorszam_ertek=$sor['maxi']+1;
	 ?> 
	 <input name=sertes_sorsz type=number value='<?php echo $sorszam_ertek; ?>' min='<?php echo $sorszam_ertek; ?>' max='<?php echo $sorszam_ertek; ?>'> <br><br>
	 
	 Sertés azonosítószáma:
	 <input id="sertesazon1" class="sertesazon1" name=sertesazon1 type=text value="" placeholder="pl:RO3568014659" pattern="RO[0-9]{10}" required oninvalid="this.setCustomValidity('Adja meg a helyes azonosítószámot!')"> <br><br>
	
	 Anya azonosítószáma:
	 <input id="sertesazon2"  class="sertesazon2" name=sertesazon2 type=text value="" placeholder="pl:RO3568014659" pattern="RO[0-9]{10}" required oninvalid="this.setCustomValidity('Adja meg a helyes azonosítószámot!')"> <br><br>
	
     Apa azonosítószáma:
	 <input id="sertesazon3" class="sertesazon3" name=sertesazon3 type=text value="" placeholder="pl:RO3568014659" pattern="RO[0-9]{10}" required oninvalid="this.setCustomValidity('Adja meg a helyes azonosítószámot!')"> <br><br>

     <!--<label for="start">Start date:</label> -->

     <?php
	 /*$conn=mysqli_connect("localhost","root","","piac");*/
	 
	 $today = date("Y-m-d"); // 20201227
	 //echo $today;
	 ?>
	 Születési dátum:
      <input name=szuldatum type=date  
       value='<?php echo $today; ?>'
       min="2014-01-01" max='<?php echo $today; ?>' > <br><br>
     Nem:
     <input id="him" name=sex type=radio value="Hím" checked > Hím
     <input id="nosteny" name=sex type=radio value="Nőstény" > Nőstény
	 <br><br>
	 
	 Fajta:
	 <select name=fajta>
	   <option value="Szőke mangalica">Szőke mangalica </option>
	   <option value="Vörös mangalica">Vörös mangalica </option>
	   <option value="Fecskehasú mangalica">Fecskehasú mangalica </option>
	   <option value="Báznai">Báznai </option>
	   <option value="Duroc">Duroc </option> 
	   <option value="Pietrain">Pietrain </option>
	   <option value="Lapály">Lapály </option>
	   <option value="Nagyfehér">Nagyfehér </option>
	   <option value="Vietnámi">Vietnámi </option>
	   <option value="Landrace">Landrace </option>
	   <option value="Hampshire">Hampshire </option>
	  <!-- <option value="fekete">fekete -->
	 </select>
	 <br><br>
	 
	 Típus:
	 <select id="name" class="tipus" name=tipus>
	   <option value="Malac" > Malac </option>
 	   <option value="Süldő" > Süldő </option>
	   <option value="Hízó" > Hízó	</option>
	   <option value="Kan" > Kan </option>
	   <option value="Koca" > Koca </option>
	 </select>
	 <br><br>
	 
	 <input class='submit' name=veglegesit type=submit value="Véglegesít"> <br>
	 	 
  </form>
  <form method="post" class="forms" action="sertes2.php" > 

	  <h1>Sertés törlése</h1>
	  Azonosítószám
	  <select id="sertesazon" class="sertesazon" name=sertesazon required>
        <!--<option disabled selected>Termék neve</option> -->
	        <option>
                <option disabled selected> Válassza ki az azonosítot</option>
		        <?php
                   // at kell irni az user id-t
                   // $_SESSION['userid']=1;
                    $tablanev="sertesek_".$_SESSION['userid'];
		            $conn=mysqli_connect("localhost","root","","sertes");
		            $tabla=mysqli_query($conn," SELECT DISTINCT(Azonosito) FROM $tablanev ");
                    while($sor=mysqli_fetch_array($tabla))
                     {
	                    echo "<option>";	
                        echo $sor['Azonosito'];
                        echo "</option>"; 
                     }
		        ?>
		    </option>
		</select>
		
	  <input class='submit' name=torles type=submit value="Törlés">

  </form>
	</body>

	<script>
		
		//1. ha az azonosito mezo valtozik

		//lekerem az azonositot 
		var azonosito = document.querySelector(".sertesazon1") //class nev

		// ezekkel mondtam mit csinaljon mikor egy adott esemeny van
		azonosito.addEventListener('change', azonosito_1_esemeny_kezelo)

		function azonosito_1_esemeny_kezelo(){

			// Ezzel lekerem a mezonek az erteket			
			var anya_azonosito = document.getElementById("sertesazon2") //id
			var apa_azonosito = document.getElementById("sertesazon3") //id
			var semmi="";
			var ok=0;
			
			if( anya_azonosito.value!=semmi)
				 if (apa_azonosito.value!=semmi)
				{
					
					if( (azonosito.value != anya_azonosito.value)  && (azonosito.value != apa_azonosito.value) && (anya_azonosito.value != apa_azonosito.value) ) 
					{
						ok=1;
					}
					else 
					{
						ok=0;
					}//*/
					
					if (ok==0) alert("Az azonosítók szigorúan különbözőek kell legyenek! \nKérjük vizsgálja meg őket, mert legalább két azonosító nem különbözik egymástól!") //console.log("egyenloek") 
					else console.log("nem egyenloek")
				}
			}
		
		//2. ha az anya azonosito mezo valtozik
				//lekerem az azonositot 
		var anya_azonosito = document.querySelector(".sertesazon2") //class nev

		// ezekkel mondtam mit csinaljon mikor egy adott esemeny van
		anya_azonosito.addEventListener('change', azonosito_2_esemeny_kezelo)

		function azonosito_2_esemeny_kezelo(){

		// Ezzel lekerem a mezonek az erteket			
		var azonosito = document.getElementById("sertesazon1") //id
		var apa_azonosito = document.getElementById("sertesazon3") //id
		var semmi="";
		var ok=0;
	
		if( azonosito.value!=semmi)
			 if (apa_azonosito.value!=semmi)
			{
				
				if( (azonosito.value != anya_azonosito.value)  && (azonosito.value != apa_azonosito.value) && (anya_azonosito.value != apa_azonosito.value) ) 
				{
					ok=1;
				}
				else 
				{
					ok=0;
				}
			
				if (ok==0) alert("Az azonosítók szigorúan különbözőek kell legyenek! \nKérjük vizsgálja meg őket, mert legalább két azonosító nem különbözik egymástól!") //console.log("egyenloek") 
				else console.log("nem egyenloek")
			}
		}

		//3. ha az apa azonosito mezo valtozik 

		//lekerem az azonositot 
		var apa_azonosito = document.querySelector(".sertesazon3") //class nev

		// ezekkel mondtam mit csinaljon mikor egy adott esemeny van
		apa_azonosito.addEventListener('change', azonosito_3_esemeny_kezelo)

		function azonosito_3_esemeny_kezelo(){

			// Ezzel lekerem a mezonek az erteket			
			var anya_azonosito = document.getElementById("sertesazon2") //id
			var azonosito = document.getElementById("sertesazon1") //id
			var semmi="";
			var ok=0;
			
			if( anya_azonosito.value!=semmi)
				 if (azonosito.value!=semmi)
				{		
					if( (azonosito.value != anya_azonosito.value)  && (azonosito.value != apa_azonosito.value) && (anya_azonosito.value != apa_azonosito.value) ) 
					{
						ok=1;
					}
					else 
					{
						ok=0;
					}
					
					if (ok==0) alert("Az azonosítók szigorúan különbözőek kell legyenek! \nKérjük vizsgálja meg őket, mert legalább két azonosító nem különbözik egymástól!"); //console.log("egyenloek") 
					else console.log("nem egyenloek");
				}
		}

		//ha a tipus kan/koca

		var tipus = document.querySelector(".tipus") //class nev
		
		tipus.addEventListener('change', tipus_ertek_atallitas_esemeny_kezelo)

		console.log(tipus.value);
		function tipus_ertek_atallitas_esemeny_kezelo(){

			if( tipus.value=="Kan" )
			{
				var sex = document.getElementById("sex") //id
				document.getElementById("him").checked = true;
				document.getElementById("nosteny").checked = false;
				//sex.setAttribute("value", "Hím" ) 
				
			}
			if( tipus.value=="Koca" )
			{
				var sex = document.getElementById("sex") //id
				document.getElementById("him").checked = false;
				document.getElementById("nosteny").checked = true;
			
			}

		}

	</script>

</html>

<!--
	
	   /* 
	   $conn=mysqli_connect("localhost","root","","sertes");
	   
	   if (isset($_POST['veglegesit']))
	   {
		   $sertes_sorszam=$_POST['sertes_sorsz'];
		   $sertes_azon=$_POST['sertesazon1'];
		   $koca_azon=$_POST['sertesazon2'];
		   $kan_azon=$_POST['sertesazon3'];
		   $datum=$_POST['szuldatum'];
		   $sertes_sex=$_POST['sex'];
		   $sertes_fajta=$_POST['fajta'];
		   $sertes_tipus=$_POST['tipus'];
		   
		   echo $sertes_azon." ".$koca_azon." ".$kan_azon." ".$datum." ".$sertes_sex." ".$sertes_fajta." ".$sertes_tipus."<br><br>";
		   
		   $ok1=0;
		//echo substr($sertes_azon, 4, 1);
		/*if ( strpos ("12345667", "4")==NULL )
		{echo "aaaa";}
		;*/
		//echo $sertes_azon[2];
		 //if ( strpos ($sertes_azon[4], "4")!=NULL ) 
		 //{
			// echo "talalt";
		 //}
		 //else echo  "hiba";
//echo strchr( "0123456789",substr($sertes_azon, 4, 1));		
//sertes-azon		  11
/*
		  if(strlen($sertes_azon)!=12)
		   {
			   $ok1=1;
			   if(strlen($sertes_azon)==0)
				   echo "A sertés azonositó mező üres!"."<br>";
			   else echo "Hibás sertés azonositó, nem megfelelő az azonositó hosszúsága!"."<br>";
		   }
		   else if(strcmp( substr($sertes_azon, 0, 2),"RO")!=0)
		   {
			   $ok1=1;
			   echo "Hibás sertés azonositó, az azonositó kötelezően RO - val kell kezdődjön!"."<br>";
		   }
		   else 
		   {
			   
			   for( $i=2; $i<12; $i++)
			   {
				   //if ( strpos ("substr($sertes_azon, $i, 1)", "4")==NULL )
				   if( strchr("0123456789",$sertes_azon[$i])==NULL )
				   {
					   $ok1=1;
				   }
				   echo $sertes_azon[$i]."<br>";
			   }
			   if( $ok1==1)
			   {
				   echo "Hibás sertés azonositó, a 3-12. helyeken kötelezően szám kell szerepeljen!"."<br>";
			   }
		   }
		   
		   //koca_azon
		   $ok2=0;
		    if(strlen($koca_azon)!=12)
		   {
			   $ok2=1;
			   if(strlen($sertes_azon)==0)
				   echo "A koca azonositó mező üres!"."<br>";
			   else echo "Hibás koca azonositó, nem megfelelő az azonositó hosszúsága!"."<br>";
		   }
		   else if(strcmp( substr($koca_azon, 0, 2),"RO")!=0)
		   {
			   $ok2=1;
			   echo "Hibás koca azonositó, az azonositó kötelezően RO - val kell kezdődjön!"."<br>";
		   }
		   else 
		   {
			   
			   for( $i=2; $i<12; $i++)
			   {
				  if( strchr("0123456789",$koca_azon[$i])==NULL )
				   {
					   $ok2=1;
				   }
			   }
			   if( $ok2==1)
			   {
				   echo "Hibás koca azonositó, a 3-12. helyeken kötelezően szám kell szerepeljen!"."<br>";
			   }
		   }
		   
		   //kan_azon
		   $ok3=0;
		    if(strlen($kan_azon)!=12)
		   {
			   $ok3=1;
			   if(strlen($sertes_azon)==0)
				   echo "A kan azonositó mező üres!"."<br>";
			   else echo "Hibás kan azonositó, nem megfelelő az azonositó hosszúsága!"."<br>";
		   }
		   else if(strcmp( substr($kan_azon, 0, 2),"RO")!=0)
		   {
			   $ok3=1;
			   echo "Hibás kan azonositó, az azonositó kötelezően RO - val kell kezdődjön!"."<br>";
		   }
		   else 
		   {
			   
			   for( $i=2; $i<12; $i++)
			   {
				  if( strchr("0123456789",$kan_azon[$i])==NULL )
				   {
					   $ok3=1;
				   }
			   }
			   if( $ok3==1)
			   {
				   echo "Hibás kan azonositó, a 3-12. helyeken kötelezően szám kell szerepeljen!"."<br>";
			   }
		   }
		   
		   //osszesit
		   if($ok1==0 and $ok2==0 and $ok3==0)
		   {
		   //echo substr($sertes_azon, 0, 2);
		   $conn=mysqli_connect("localhost","root","","sertes");
		    $tabla=mysqli_query( $conn, " INSERT INTO sertesek(Sorszam, Azonositoszam, Koca azonositoszam, Kan azonositoszam, Szuletesi datum, Nem, Fajta, Tipus) VALUES ('$sertes_sorszam', '$sertes_azon', '$koca_azon', '$kan_azon', '$datum', '$sertes_sex', '$sertes_fajta', '$sertes_tipus')" );
		   
		   echo "<table>
	   <tr>
	      <td> Sorszam</td>
		  <td> Sertes azonosito</td>
		  <td> Anya azonositoja</td>
		  <td> Apa azonosito</td>
		  <td> Szuletesi datum</td>
		  <td> Nem</td>
		  <td> Fajta</td>
		  <td> Tipus</td>
	   </tr>
	      <td>"; echo $sertes_sorszam; echo "</td>
		  <td>"; echo $sertes_azon; echo "</td>
		  <td>"; echo $koca_azon; echo "</td>
		  <td>"; echo $kan_azon; echo "</td>
	   	  <td>"; echo $datum; echo "</td>
	   	  <td>"; echo $sertes_sex; echo "</td>
		  <td>"; echo $sertes_fajta; echo "</td>
		  <td>"; echo $sertes_tipus; echo "</td>
	   <tr>
	   </tr>
	 </table>";
	   }
	   }*/
	 ?>
	 -->