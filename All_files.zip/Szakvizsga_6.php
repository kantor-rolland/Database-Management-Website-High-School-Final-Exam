<html>
    <title>

    </title>
    <body>
        <form  method=post action=szakvizsga_6_2.php>

            Leltar szam
            <input name=leltar type=text value=""> <br><br>

            Uj szerzo
            <input name=szerzo type=text value=""> <br><br>

            Uj cim
            <input name=cim type=text value=""> <br><br>

            Olvaso
            <input name=olvaso type=text value=""> <br><br>

            Uj datum
            <input name=datum type=date value=""> <br><br>

            <input name=modosit type=submit value="Modosit"><br><br><br><br>

            Datum megadasa
            <input name=datum2 type=date ><br><br>

            <input name=kivalaszt type=submit value="Kivalaszt"><br><br><br><br>

            Cim megadasa
            <input name=cim2 type=text ><br><br>

            <input name=kivalaszt2 type=submit value="Kivalaszt"><br><br>

        </form>
    </body>
</html>