<?php

    session_start();
   $conn=mysqli_connect("localhost","root","","sertes");

   $tablanev="sertesek_".$_SESSION['userid'];
   $tabla=mysqli_query($conn," SELECT Sorszam, Azonosito, Anya_azonosito, Apa_azonosito, Szuletesi_datum, Fajta, Nem, Tipus, Allapot  FROM $tablanev ");
   
   echo " <html>
            <head>
                <title>Sertés adatbázis </title>
            </head>
            <body bgcolor=#f2f2f2>
            <link rel='stylesheet' type='text/css' href='style.css' >";
			
   echo "<table id='table2' align=center border=1 bgcolor=#b3cccc cellpadding=5>
	     <tr>
           <th align=center>  Sorszám </th>
           <th align=center>  Azonosító </th>
           <th align=center>  Anya azonosító </th>
           <th align=center>  Apa azonosító </th>
           <th align=center>  Születési dátum </th>
		   <th align=center>  Fajta </th>
		   <th align=center>  Nem </th>
           <th align=center>  Típus </th>
           <th align=center>  Állapot </th>
         </tr>";
        
        $rows=mysqli_affected_rows($conn);
        if($rows!=0)
        {
            while( $sor=mysqli_fetch_array($tabla) )
            {
                echo "
                    <tr>
                        <td align=center>";
                        echo $sor['Sorszam'];
                echo "
                        </td>
                        <td align=center>";
                        echo $sor['Azonosito'];
                echo "
                        </td>
                        <td align=center>";
                        echo $sor['Anya_azonosito'];
                echo "
                        </td>
                        <td align=center>";
                        echo $sor['Apa_azonosito'];
                echo " 
                            </td>
                            <td align=center>";
                            echo $sor['Szuletesi_datum'];
                echo " 
                            </td>
                            <td align=center>";
                            echo $sor['Fajta'];
                echo " 
                            </td>
                            <td align=center>";
                            echo $sor['Nem'];
                echo " 
                            </td>
                            <td align=center>";
                            echo $sor['Tipus'];
                echo " 
                        </td>
                        <td align=center>";
                        echo $sor['Allapot'];
                echo "
                        </td>
                    </tr>";
            }
        }
        else
        {
            echo "<tr>
                    <td colspan=9>
                        Üres tábla - nincs feltöltött adat
                    </td>
                  </tr>";
        }
        
        
		echo "</table>";
		echo "</body>
		      </html>";

?>