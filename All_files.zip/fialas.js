// const mysql = require("mysql")

// const db_connection = mysql.createPool({
//     host: 'localhost',
//     user: 'root',
//     database: 'sertes',
//     password:''
// });

// db_connection.promise()
// .execute("SELECT * FROM `sertesek2`")
// .then(([rows]) => {
//     // show the first user name
//     console.log(rows[0]);
//     // show the all users name
//     // rows.forEach(user => {
//     //     console.log(user.name);
//     // });
// }).catch(err => {
//     console.log(err);
// });
