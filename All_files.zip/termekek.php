﻿<html>
  <head>
     <title> Piac </title>
  </head>
  
  <body bgcolor=#f2f2f2>
  <form method=post action=proba.php>
     <table width=95% align=center border=1 cellpadding=5 cellspacing=0 >
	    <tr align=center>
		  <td width=25%> <a href=piac.html>Főoldal
		  </td>
		  <td width=25%>  Termékek
		  </td>
		  <td width=25%> <a href=termelok.html> Termelők
		  </td>
		  <td width=25%> <a href=urlap.php> Lekérdezések
		  </td>
		</tr>
      </table>
	  <br>
	  
	  <hr style="width:50%;height:5;background-color:#737373">
	  
	  <br>
 <?php
  $conn=mysqli_connect("localhost","root","","piac");
  
  $tabla=mysqli_query($conn," SELECT nev FROM zoldsegek");
  
  $i=0;
  while($sor=mysqli_fetch_array($tabla))
  {
	  $termekek_t[$i]=($sor['nev']);
	  $i++;
  }
  $termekek_szama=$i;
  
  $sorok=$termekek_szama/5;
  settype($sorok, "int");
  if( $termekek_szama%5 !=0) $sorok++;
  
  $aktualis_termek=0;
  
  for( $i=1; $i<=$sorok && $aktualis_termek < $termekek_szama; $i++) 
  {
	  //echo "<tr>";
	  $aktualis_oszlop=1;
	  while( $aktualis_oszlop<=5 and $aktualis_termek< $termekek_szama)
	  {
		  $termek=$termekek_t[$aktualis_termek];
		  $kep=$termek.".jpg";
		//  echo "<td align=center width=400px";
		//echo $termek;
		//  echo "<img src='$kep' width=300px";
		//  echo "<td>";
		  
		  $aktualis_oszlop++;
		  $aktualis_termek++;
	  }
	 // echo "<tr>";
  }
  ?>
	  
	  <table width=95% align=center cellspacing=20 cellpadding=5 border=1 bgcolor=#b3cccc>
		
		<tr>
		  <td rowspan='<?php echo $sorok; ?>' width=200> 
		 
		     <table border=2 valign=top bgcolor=#f2f2f2 >
			    <tr valign=top>
				   <td> 
				     Tipus: <br>
	 Zöldség <input name=t1 type=checkbox value="zöldség" > <br>
	 Gyümölcs <input name=t2 type=checkbox value="gyümölcs" > <br> <br>
	 
	 <?php
         // $conn=mysqli_connect("localhost","root","","piac");
          $tabla=mysqli_query($conn," SELECT MAX(egysegar) AS maxi FROM zoldsegek ");
          $sor=mysqli_fetch_array($tabla);
          $maxertek=$sor['maxi'];
     ?>

	 
	 Ár: <br>
	 Kezdőár <input name=min_ar type=number value=0 min=0 max='<?php echo $maxertek;?>' > <br> 
	 Végsőár <input name=max_ar type=number value='<?php echo $maxertek;?>' min=0 max='<?php echo $maxertek;?>' > <br> <br>
	 
	 Rendezés: <br>
	 <select name=rendez>
	    <option value=1> Ár szerint növekvő
		<option value=2> Ár szerint csökkenő
		<option value=3> Ábécé szerint növekvő
		<option value=4> Ábécé szerint csökkenő
		<option value=5> Legnépszerűbb(eladás szerint)
	 </select>
	 <br>
	 <br>
	 <input name=veglegesit type=submit value="Véglegesit">
	 
				   </td>
				</tr>
			 </table>
			</td>
			
	  
  <?php
  $conn=mysqli_connect("localhost","root","","piac");
  
  $tabla=mysqli_query($conn," SELECT nev FROM zoldsegek");
  
  $i=0;
  while($sor=mysqli_fetch_array($tabla))
  {
	  $termekek_tomb[$i]=($sor['nev']);
	  $i++;
  }
  $termekek_szama=$i;
  
  $sorok=$termekek_szama/5;
  settype($sorok, "int");
  if( $termekek_szama%5 !=0) $sorok++;
  
  $aktualis_termek=0;
  
  //echo "<tr>";
  for( $i=1; $i<=$sorok && $aktualis_termek < $termekek_szama; $i++) 
  {
	  //echo "<tr>";
	  $aktualis_oszlop=1;
	  while( $aktualis_oszlop<=5 and $aktualis_termek< $termekek_szama)
	  {
		  $termek=$termekek_tomb[$aktualis_termek];
		  $kep=$termek.".png";
		  echo "<td align=center width=20% bgcolor=#f2f2f2>";
		  
		  echo "<img src='termekek/$kep' width=200px>";
		  echo "<br>";
		  echo $termek;
		  echo "</td>";
		  
		  $aktualis_oszlop++;
		  $aktualis_termek++;
	  }
	  echo "</tr>";
  }
  ?>
	  </table>
	  <br>
	  <hr style="width:50%;height:5px;background-color:#737373">
	  <br>
	  </form>
  </body>
</html>