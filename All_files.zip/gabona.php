﻿<html>
  <head>
	<title> Takarmány</title>
	<link rel="stylesheet" type="text/css" href="style.css">
  </head>

  <body> 
  <form action="kijelentkezes.php" method="get">
		<button class="btn2" type=submit> Kijelentkezés </button>
    </form>
   <table width=95% align=center border=1 cellpadding=5 cellspacing=0 id='menu_1'>
	       <tr align=center>
			 <?php 
			 //	if($_SESSION['userid'] != 0)
			
					
			 ?>
			    <!-- amit az lat aki be van jelentkezve -->

				<tr>
					<td width=30%> 
						<?php
                            session_start();
                            if($_SESSION['userid'] == 0){
                        ?>
                            <a href=adatbazis_fooldal.php>
                        <?php
                            }
                            else {
                        ?>
                            <a href=felhasznalo_fooldal.php>
                        <?php
                            }
                        ?>
                        Főoldal
			 		</td>
			 		<td width=30%>
					 <a href=sertes_fajtak.php> A sertés fajtákról
			 		</td>
			 		<td width=30%>
				 	<a href=tenyesztok.php>	Tenyésztők
			 		</td>
				</tr>
		  </tr>
	   </table> <br><br>
	   
	
     <table width=95% align=center border=1 cellpadding=5 cellspacing=0 id='menu_2' >
	       <tr align=center>
		     <td width=20%> <a href=sertes.php> Sertés
		     </td>
		     <td width=20%> <a href=fialas.php> Fialás
		     </td>
		     <td width=20%> <a href=megtermekenyites.php> Megtermékenyítés
		     </td>
		     <td width=20%> Takarmány
			 </td>
		     <td width=20%> <a href=sertes_szuro.php> Szűrés
		     </td>
		  </tr>
	   </table>
	   <br><br>
	   <table class="table_adatbazis" align=center>
           <tr>
               <td colspan=4> Adatbázisok </td>
           </tr>
           <tr>
               <td>
                    <!--<a href=adatbazis_sertes.php target=_blank > Sertés adatbázis -->
                    <form action="adatbazis_sertes.php" method="get" target="_blank">
                        <button class="btn" type="submit">Sertés adatbázis</button>
                    </form>
               </td>
               <td>
                    <!--<a href=adatbazis_fialas.php target=_blank > Fialás adatbázis -->
                    <form action="adatbazis_fialas.php" method="get" target="_blank">
                        <button class="btn" type="submit">Fialás adatbázis</button>
                    </form>
               </td>
               <td>
                    <!--<a href=adatbazis_megtermekenyites.php target=_blank > Megtermékenyítés adatbázis-->
                    <form action="adatbazis_megtermekenyites.php" method="get" target="_blank">
                        <button class="btn" type="submit">Megtermékenyítés adatbázis</button>
                    </form>
			   </td>
			   <td>
                    <!--<a href=adatbazis_megtermekenyites.php target=_blank > Megtermékenyítés adatbázis-->
                    <form action="adatbazis_takarmany.php" method="get" target="_blank">
                        <button class="btn" type="submit">Takarmány adatbázis</button>
                    </form>
               </td>
           </tr>
       </table> <br><br><br>
	   
	   <form method=post class="forms" action=gabona2.php>
     
	   <h1>Takarmányok hozzáadása</h1>
	 
	 Takarmány neve
	 
	  <select name=takarmany_nev placeholder="Válassza ki a nevet">
	    <option>
		<?php
		
			//session_start();
			//$tablanev="takarmany_tipusok_".$_SESSION['userid'];

		   $conn=mysqli_connect("localhost","root","","sertes");
		   $tabla=mysqli_query($conn," SELECT DISTINCT(Nev) FROM takarmany_tipusok ");
		   
           while($sor=mysqli_fetch_array($tabla))
        	{
	        	echo "<option>";	
            	echo $sor['Nev'];
            	echo "</option>"; 
       	 }
		?>
		</option>
	 </select>
	<!-- <select name=takarmany_nev>
	   <option name=Buza> Buza
	   <option name=Kukorica> Kukorica
	   <option name=Lucerna> Lucerna
	 </select>  
	 -->
	 <br><br>
	 
	 Mennyiség (KG)
	 <input name=takarmany_mennyiseg type=number value=0 min=0>
	 
	 <br><br>
	 
	 Napi mennyiség (KG)
	 <input name=napi_mennyiseg type=number value=0 min=0>
	 
	 <br><br>
	 
	 <input class='submit' name=veglegesit type=submit value="Véglegesit">
	 <br>
   </form>

   <form method=post class="forms" action=gabona2.php>
	 <h1>Takarmány törlése a hombárból</h1>
	 <br>
	 
	 Takarmány neve
	  <select name=nev_torol>
	    <option>
			<option disabled selected> Válassza ki az takarmányt</option>
		<?php
			$tablanev2="takarmany_".$_SESSION['userid'];
		
		   $conn=mysqli_connect("localhost","root","","sertes");
		   $tabla=mysqli_query($conn," SELECT DISTINCT(Nev) FROM $tablanev2 ");
        while($sor=mysqli_fetch_array($tabla))
        {
	        echo "<option>";	
            echo $sor['Nev'];
            echo "</option>"; 
        }
		?>
		</option>
	 </select>
	 
	 <br><br>
	 
	 <input class='submit' name=veglegesit2 type=submit value="Törlés">
	 <br><br>
   </form>

   <!--
   <form method=post class="forms" action=gabona2.php>
	 <br><br>
	 <h1>Új takarmány típus hozzáadása </h1>
	 <br>
	 
	 Sorszám:
	 <?php
          $conn=mysqli_connect("localhost","root","","sertes");
          $tabla=mysqli_query($conn," SELECT MAX(Azonosito) AS maxi FROM takarmany_tipusok");
          $sor=mysqli_fetch_array($tabla);
          $sorszam_ertek=$sor['maxi']+1;
     ?>
	 <input name=sorszam_uj type=number value='<?php echo $sorszam_ertek; ?>' min='<?php echo $sorszam_ertek; ?>' max='<?php echo $sorszam_ertek; ?>'>
	 
	 
	 Új takarmány neve
	 <input name=ujtakarmany type=text value="" placeholder="Írja be a nevet" required> <br><br>
	 
	 <input name=veglegesit3 type=submit value="Véglegesít">
	 <br><br>
	-->
  </form>
  </body>
  
</html>