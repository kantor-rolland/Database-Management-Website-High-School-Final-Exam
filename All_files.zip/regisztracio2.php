<?php

 session_start();
 $conn=mysqli_connect("localhost","root","","sertes");

 if(isset($_POST['regisztralas']))
 {
     $sorszam=$_POST['sorszam'];
     $emailcim=$_POST['email_cim'];
     $jelszo=$_POST['password'];
     $vezeteknev=$_POST['v_nev'];
     $keresztnev=$_POST['k_nev'];
     $farm_name=$_POST['farm_nev'];
     $telefonszam=$_POST['telefon'];
     $megye=$_POST['megye'];
     $telepules=$_POST['telepules'];
     $lakcim=$_POST['cim'];

     $tabla=mysqli_query( $conn, " INSERT INTO felhasznalok( Azonosito, Email_cim, Jelszo, Vezeteknev, Keresztnev, Farm_neve, Telefonszam, Megye, Telepules, Cim) VALUES ('$sorszam', '$emailcim', '$jelszo', '$vezeteknev', '$keresztnev', '$farm_name', '$telefonszam', '$megye', '$telepules', '$lakcim' ) " ) ;

       
     //adattablak letrehozasa a felhasznalonak
     $id=$sorszam;
//if (isset($_POST['x']))
    $tablanev="megtermekenyites_".$id;
    echo $tablanev."<br>";
    $tabla=mysqli_query( $conn, " CREATE table $tablanev
    (
      Sorszam int(255) not null,
      Koca_azonosito varchar(13) not null,
      Kan_azonosito varchar(13) not null,
      Datum date not null
    ); " );
    
    $tabla=mysqli_query( $conn, " ALTER TABLE $tablanev CONVERT TO CHARACTER SET utf8 COLLATE utf8_general_ci " );
  
   
    //$tabla=mysqli_query( $conn, " ALTER TABLE postssss CONVERT TO CHARACTER SET utf8 COLLATE utf8_general_ci " );
   
    $tablanev="fialasok_".$id;
    $tabla=mysqli_query( $conn, " CREATE table $tablanev
    (
      Sorszam int(255) not null,
      Koca_azonosito varchar(13) not null,
      Kan_azonosito varchar(13) not null,
      Megtermekenyites_sorszam int(255) not null,
      Idopont date not null,
      Fialt_malacok int(255) not null,
      Felnevelt_malacok int(255) not null,
      Fiu int(255) not null,
      Lany int(255) not null,
      Elvalasztasi_idopont date not null
    ); " );
    
    $tabla=mysqli_query( $conn, " ALTER TABLE $tablanev CONVERT TO CHARACTER SET utf8 COLLATE utf8_general_ci " );
    
    $tablanev="sertesek_".$id;
    $tabla=mysqli_query( $conn, " CREATE table $tablanev
    (
      Sorszam int(255) not null,
      Azonosito varchar(13) not null,
      Anya_azonosito varchar(13) not null,
      Apa_azonosito varchar(13) not null,
      Szuletesi_datum date not null,
      Fajta varchar(30) not null,
      Nem varchar(30) not null,
      Tipus varchar(30) not null,
      Allapot tinyint(1) not null
    ); " );
    
    $tabla=mysqli_query( $conn, " ALTER TABLE $tablanev CONVERT TO CHARACTER SET utf8 COLLATE utf8_general_ci " );

    $tablanev="takarmany_tipusok_".$id;
    $tabla=mysqli_query( $conn, " CREATE table $tablanev
    (
      Azonosito int(255) not null,
      Nev varchar(30) not null
    ); " );
    
    $tabla=mysqli_query( $conn, " ALTER TABLE $tablanev CONVERT TO CHARACTER SET utf8 COLLATE utf8_general_ci " );
  
    $tablanev="takarmany_".$id;
    $tabla=mysqli_query( $conn, " CREATE table $tablanev
    (
      Azonosito int(255) not null,
      Nev varchar(30) not null,
      Mennyiseg int(255) not null,
      Napi_mennyiseg int(255) not null
    ); " );
    
    $tabla=mysqli_query( $conn, " ALTER TABLE $tablanev CONVERT TO CHARACTER SET utf8 COLLATE utf8_general_ci " );

     echo "Sikeres regisztrálás"."<br>"."Kérjük jelentkezzen be!";
    
 }

 header('Location: adatbazis_fooldal.php');
/*
 if(isset($_POST['bejelentkezes']))
 {
   $email_akt=$_POST['email_cim2'];
   $jelszo_akt=$_POST['password2'];
   $id_akt=0;
echo $email_akt."<br>".$jelszo_akt;
   $ok=0;
   $tabla=mysqli_query( $conn, " SELECT Azonosito, Email_cim, Jelszo FROM felhasznalok ") ;
   
   while($sor=mysqli_fetch_array($tabla))
   {
       if( (strcmp(trim($sor['Email_cim']), trim($email_akt)) == 0) && ( strcmp(trim($sor['Jelszo']), trim($jelszo_akt)) == 0)) 
       { 
           $ok=1; 
           $id_akt=trim($sor['Azonosito']);
        } 
       $a = (string)($sor['Email_cim'] == (string)$email_akt);

       $b=strcmp( trim($sor['Email_cim']),trim( $email_akt));
      
    //    if ($a == true) echo "jo" ;
   } 
   if( $ok==1) 
   {
       
    echo "Sikeres bejelentkezés";

    $_SESSION['userid']=$id_akt;
    echo "Welcome {$_SESSION['userid']}";
    

    if (!$_SESSION['userid']){
        echo "Please login";
        exit;
    }

    header('Location: adatbazis_fooldal.php');
   }
   */
 


?>