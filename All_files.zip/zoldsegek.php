﻿<?php

   $conn=mysqli_connect("localhost","root","","piac");
   
   $tabla=mysqli_query($conn," SELECT zoldsegazon, nev, egysegar, tipus FROM zoldsegek");
   
   echo " <html>
            <body bgcolor=#f2f2f2>";
			
   echo "<table align=center border=1 bgcolor=#b3cccc cellpadding=5>
	     <tr>
		   <td align=center>  Zöldségzonositó  </td>
		   <td align=center>  Név  </td>
		   <td align=center>  Egységár   </td>
		   <td align=center>  Tipus  </td>
		 </tr>";
        while($sor=mysqli_fetch_array($tabla))
        {
            echo "
			      <tr>
				      <td align=center>";
					  echo $sor['zoldsegazon'];
			echo "
			          </td>
					  <td align=center>";
					  echo $sor['nev'];
			echo "
			          </td>
					  <td align=center>";
					  echo $sor['egysegar'];
			echo "
			          </td>
					  <td align=center>";
					  echo $sor['tipus'];
			echo "
			          </td>
				   </tr>";
        }
		echo "</table>";
		echo "</body>
		      </html>";

?>

