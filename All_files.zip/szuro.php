﻿<?php

if (isset ($_POST['t1']) and isset($_POST['t2']))
	 
 {
		 //ar szerint novekvo 
	if($rendezes==1)
	{
		$tabla=mysqli_query($conn," SELECT nev, egysegar FROM zoldsegek WHERE   egysegar>='$kezdoar' and egysegar<='$vegsoar' ORDER BY egysegar ASC");
		while($sor=mysqli_fetch_array($tabla))
		{
			echo $sor['nev']." ".$sor['egysegar']."<br>";
		}
	}
	
	//ar szerint csokkeno
	if($rendezes==2)
	{
		$tabla=mysqli_query($conn," SELECT nev, egysegar FROM zoldsegek WHERE ( egysegar>='$kezdoar' and egysegar<='$vegsoar') ORDER BY egysegar DESC");
		while($sor=mysqli_fetch_array($tabla))
		{
			echo $sor['nev']." ".$sor['egysegar']."<br>";
		}
	}
	
	//nev szerint novekvo
	if($rendezes==3)
	{
		$tabla=mysqli_query($conn," SELECT nev, egysegar FROM zoldsegek WHERE  ( egysegar>='$kezdoar' and egysegar<='$vegsoar') ORDER BY nev ASC");
		while($sor=mysqli_fetch_array($tabla))
		{
			echo $sor['nev']." ".$sor['egysegar']."<br>";
		}
	}
	
	//nev szerint csokkeno
	if($rendezes==4)
	{
		$tabla=mysqli_query($conn," SELECT nev, egysegar FROM zoldsegek WHERE  ( egysegar>='$kezdoar' and egysegar<='$vegsoar') ORDER BY nev DESC");
		while($sor=mysqli_fetch_array($tabla))
		{
			echo $sor['nev']." ".$sor['egysegar']."<br>";
		}
	}
	
	if($rendezes==5)
	{
		$tabla=mysqli_query($conn," SELECT zoldsegek.nev AS nev, zoldsegek.egysegar AS ar, zoldsegek.tipus, SUM(vasarlasok.mennyiseg) AS Mennyiseg FROM zoldsegek, vasarlasok WHERE zoldsegek.zoldsegazon LIKE vasarlasok.aru and (egysegar>='$kezdoar' and egysegar<='$vegsoar') GROUP BY zoldsegek.nev ORDER BY Mennyiseg DESC " );
		while($sor=mysqli_fetch_array($tabla))
		{
			echo $sor['nev']." ".$sor['ar']."<br>";
		}
	}
	
	}
	
	 
	 else if (isset($_POST['t1']))
	 {
		
		 //ar szerint novekvo 
	if($rendezes==1)
	{
		$tabla=mysqli_query($conn," SELECT nev, egysegar FROM zoldsegek WHERE tipus LIKE '%$lehetoseg1%' and  egysegar>='$kezdoar' and egysegar<='$vegsoar' ORDER BY egysegar ASC");
		while($sor=mysqli_fetch_array($tabla))
		{
			echo $sor['nev']." ".$sor['egysegar']."<br>";
		}
	}
	
	//ar szerint csokkeno
	if($rendezes==2)
	{
		$tabla=mysqli_query($conn," SELECT nev, egysegar FROM zoldsegek WHERE tipus LIKE '%$lehetoseg1%' and ( egysegar>='$kezdoar' and egysegar<='$vegsoar') ORDER BY egysegar DESC");
		while($sor=mysqli_fetch_array($tabla))
		{
			echo $sor['nev']." ".$sor['egysegar']."<br>";
		}
	}
	
	//nev szerint novekvo
	if($rendezes==3)
	{
		$tabla=mysqli_query($conn," SELECT nev, egysegar FROM zoldsegek WHERE tipus LIKE '%$lehetoseg1%' and ( egysegar>='$kezdoar' and egysegar<='$vegsoar') ORDER BY nev ASC");
		while($sor=mysqli_fetch_array($tabla))
		{
			echo $sor['nev']." ".$sor['egysegar']."<br>";
		}
	}
	
	//nev szerint csokkeno
	if($rendezes==4)
	{
		$tabla=mysqli_query($conn," SELECT nev, egysegar FROM zoldsegek WHERE tipus LIKE '%$lehetoseg1%' and ( egysegar>='$kezdoar' and egysegar<='$vegsoar') ORDER BY nev DESC");
		while($sor=mysqli_fetch_array($tabla))
		{
			echo $sor['nev']." ".$sor['egysegar']."<br>";
		}
	}
	
	if($rendezes==5)
	{
		$tabla=mysqli_query($conn," SELECT zoldsegek.nev AS nev, zoldsegek.egysegar AS ar, zoldsegek.tipus, SUM(vasarlasok.mennyiseg) AS Mennyiseg FROM zoldsegek, vasarlasok WHERE zoldsegek.zoldsegazon LIKE vasarlasok.aru and tipus LIKE '%$lehetoseg1%' and (egysegar>='$kezdoar' and egysegar<='$vegsoar') GROUP BY zoldsegek.nev ORDER BY Mennyiseg DESC " );
		while($sor=mysqli_fetch_array($tabla))
		{
			echo $sor['nev']." ".$sor['ar']."<br>";
		}
	}
	 }
		  
	 else if (isset($_POST['t2'])) 
	 {
		 
		 //ar szerint novekvo 
	if($rendezes==1)
	{
		$tabla=mysqli_query($conn," SELECT nev, egysegar FROM zoldsegek WHERE tipus LIKE '%$lehetoseg2%' and  egysegar>='$kezdoar' and egysegar<='$vegsoar' ORDER BY egysegar ASC");
		while($sor=mysqli_fetch_array($tabla))
		{
			echo $sor['nev']." ".$sor['egysegar']."<br>";
		}
	}
	
	//ar szerint csokkeno
	if($rendezes==2)
	{
		$tabla=mysqli_query($conn," SELECT nev, egysegar FROM zoldsegek WHERE tipus LIKE '%$lehetoseg2%' and ( egysegar>='$kezdoar' and egysegar<='$vegsoar') ORDER BY egysegar DESC");
		while($sor=mysqli_fetch_array($tabla))
		{
			echo $sor['nev']." ".$sor['egysegar']."<br>";
		}
	}
	
	//nev szerint novekvo
	if($rendezes==3)
	{
		$tabla=mysqli_query($conn," SELECT nev, egysegar FROM zoldsegek WHERE  tipus LIKE '%$lehetoseg2%' and ( egysegar>='$kezdoar' and egysegar<='$vegsoar') ORDER BY nev ASC");
		while($sor=mysqli_fetch_array($tabla))
		{
			echo $sor['nev']." ".$sor['egysegar']."<br>";
		}
	}
	
	//nev szerint csokkeno
	if($rendezes==4)
	{
		$tabla=mysqli_query($conn," SELECT nev, egysegar FROM zoldsegek WHERE tipus LIKE '%$lehetoseg2%' and ( egysegar>='$kezdoar' and egysegar<='$vegsoar') ORDER BY nev DESC");
		while($sor=mysqli_fetch_array($tabla))
		{
			echo $sor['nev']." ".$sor['egysegar']."<br>";
		}
	}
	
	if($rendezes==5)
	{
		$tabla=mysqli_query($conn," SELECT zoldsegek.nev AS nev, zoldsegek.egysegar AS ar, zoldsegek.tipus, SUM(vasarlasok.mennyiseg) AS Mennyiseg FROM zoldsegek, vasarlasok WHERE zoldsegek.zoldsegazon LIKE vasarlasok.aru and  tipus LIKE '%$lehetoseg2%' and (egysegar>='$kezdoar' and egysegar<='$vegsoar') GROUP BY zoldsegek.nev ORDER BY Mennyiseg DESC " );
		while($sor=mysqli_fetch_array($tabla))
		{
			echo $sor['nev']." ".$sor['ar']."<br>";
		}
	}
	 }
 
	 
	 ?>