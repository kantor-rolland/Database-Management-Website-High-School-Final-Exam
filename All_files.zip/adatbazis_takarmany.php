<?php

    session_start();
   $conn=mysqli_connect("localhost","root","","sertes");

   $tablanev="takarmany_".$_SESSION['userid'];
   $tabla=mysqli_query($conn," SELECT Azonosito, Nev, Mennyiseg, Napi_mennyiseg FROM $tablanev ");
   
   echo " <html>
            <head>
                <title>Takarmány adatbázis </title>
            </head>
            <body bgcolor=#f2f2f2>
            <link rel='stylesheet' type='text/css' href='style.css' >";
			
   echo "<table id='table2' align=center border=1 bgcolor=#b3cccc cellpadding=5>
	     <tr>
           <th align=center>  Takarmány azonosító </th> 
           <th align=center>  Megnevezés </th>
           <th align=center>  Mennyiség </th>
           <th align=center>  Napi mennyiség </th>
         </tr>";
        
        $rows=mysqli_affected_rows($conn);
        if($rows!=0)
        {
            while($sor=mysqli_fetch_array($tabla))
            {
                echo "
                    <tr>
                        <td align=center>";
                        echo $sor['Azonosito'];
                echo "
                        </td>
                        <td align=center>";
                        echo $sor['Nev'];
                echo "
                        </td>
                        <td align=center>";
                        echo $sor['Mennyiseg']." KG";
                echo " 
                            </td>
                            <td align=center>";
                            echo $sor['Napi_mennyiseg']." KG";
            
                echo "
                        </td>
                    </tr>";
            }
        }
        else
        {
            echo "<tr>
                    <td colspan=4>
                        Üres tábla - nincs feltöltött adat
                    </td>
                  </tr>";
        }
        
		echo "</table>";
		echo "</body>
		      </html>";

?>