<?php
    
    $conn=mysqli_connect("localhost","root","","szakvizsga_19");

     if(isset($_POST['kiirat']))
     {
       //$leltar_szam=$_POST['leltar']
       
       $tabla = mysqli_query( $conn, " SELECT `konyv_kod`, `szerzo`, `cim`, `kiadasi_ev` FROM `konyvtar` WHERE 1 ORDER BY szerzo, konyv_kod ") ;

       while( $sor=mysqli_fetch_array($tabla) )
      {
          echo $sor['konyv_kod']."<br>";
          echo $sor['szerzo']."<br>";
          echo $sor['cim']."<br>";
          echo $sor['kiadasi_ev']."<br><br><br>";
      }
     }

     if(isset($_POST['kiirat2']))
     {
       //$leltar_szam=$_POST['leltar']
       $szerzo=$_POST['szerzo'];
       $tabla = mysqli_query( $conn, " SELECT `konyv_kod`, `szerzo`, `cim`, `kiadasi_ev` FROM `konyvtar` WHERE szerzo like '$szerzo' ") ;

       while( $sor=mysqli_fetch_array($tabla) )
      {
          echo $sor['konyv_kod']."<br>";
          echo $sor['szerzo']."<br>";
          echo $sor['cim']."<br>";
          echo $sor['kiadasi_ev']."<br><br><br>";
      }
     }
/*
     if(isset($_POST['kiirat2']))
     {
       $szerzo_neve=$_POST['szerzo2']
       
       $tabla = mysqli_query ( $conn, " SELECT `konyv_kod`, `szerzo`, `cim`, `kiadasi_ev` FROM `konyvtar` WHERE szerzo like '$szerzo_neve' ") ;

       while( $sor=mysqli_fetch_array ($tabla) )
      {
          echo $sor['konyv_kod']."<br>";
          echo $sor['szerzo']."<br>";
          echo $sor['cim']."<br>";
          echo $sor['kiadasi_ev']."<br>";
      }
     }*/

     if(isset($_POST['modosit']))
{
  $kod=$_POST['kod'];
  $szerzo2=$_POST['szerzo2'];
  $cim=$_POST['cim'];
  $ev=$_POST['datum'];
  
  $tabla=mysqli_query( $conn, " UPDATE `konyvtar` SET `szerzo`='$szerzo2',`cim`='$cim',`kiadasi_ev`='$ev' WHERE konyv_kod like '$kod' ") ;
}
     

?>