<html>
    <title>

    </title>
    <body>
        <form  method=post action=szakvizsga_13_2.php>

            Adatok kiiratasa
            <input name=kiiratas type=submit value='x'>

            <br><br>

            Uj kod
            <input name=kod type=text value=""> <br><br>

            Uj Keresztnev
            <input name=knev type=text value=""> <br><br>
            
            Uj Vezeteknev
            <input name=vnev type=text value=""> <br><br>
            
            Uj Lakcim
            <input name=cim type=text value=""> <br><br>

            Uj szuletesi datum
            <input name=sz_datum type=date value=""> <br><br>
            
            Uj gyerek szam
            <input name=gyerekszam type=number value=""> <br><br>
            
            Vegzettseg
            <select name=vegzettseg1>
                <option> kiserettseg </option>
                <option> erettsegi </option>
                <option> egyetem </option>
            </select> <br><br>

            Alkalmazas datum
            <input name=alk_datum type=date value=""> <br><br>

            <input name=beszur type=submit value="Beszur"> <br><br>

            Vegzettseg kivalasztasa
            <select name=vegzettseg2>
                <option> kiserettseg </option>
                <option> erettsegi </option>
                <option> egyetem </option>
            </select> <br><br>
            
            Gyerekszam megadasa
            <input name=gyerekszam2 type=number > <br><br>

            <input name=kivalaszt type=submit value="Kivalaszt"> <br><br>


        </form>
    </body>
</html>