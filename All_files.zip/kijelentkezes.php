<?php

    session_start();

    $_SESSION['userid']=0;
    header('Location: adatbazis_fooldal.php');

?>