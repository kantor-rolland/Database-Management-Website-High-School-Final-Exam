﻿<?php
//kapcsolodas
$conn=mysqli_connect("localhost","root","","piac");

echo "<html>
         <body bgcolor=#f2f2f2>";
//1

		 
   if ( isset($_POST['elkuld1']))
   {
	   $termeknev=$_POST['termekek1'];
	   
	    $tabla=mysqli_query($conn, " SELECT DISTINCT(zoldsegesek.nev) FROM zoldsegesek, zoldsegek, vasarlasok WHERE vasarlasok.zoldseges=zoldsegesek.zoldsegesazon and vasarlasok.aru=zoldsegek.zoldsegazon and zoldsegek.nev like '$termeknev' ");
		//$sor=mysqli_fetch_array($tabla)
        echo "<table align=center bgcolor=#b3cccc border=1 cellpadding=5>
		        <tr>
				  <td align=center> Termelők akiknél megtalálható a/az ";
				  echo $termeknev;
		echo"		  </td>
				 </tr>
		 ";
		while ( $sor=mysqli_fetch_array($tabla) )
		{
			echo " <tr>
			         <td align=center>";
					 echo $sor['nev'];
			echo "   </td>
			       </tr>";
			
		}			
			echo "</table>";
	   
   }
   
//2
 if (isset($_POST['elkuld2']))
 {
	 if (isset ($_POST['h1']) and isset($_POST['h2']))
	 
	 {
		 $table=mysqli_query( $conn ," SELECT zoldsegek.nev, zoldsegek.egysegar FROM zoldsegek WHERE zoldsegek.egysegar like (SELECT MAX(zoldsegek.egysegar) FROM zoldsegek) ");
		 echo "
		       <table align=center bgcolor=#b3cccc border=1 cellpadding=5>
			      <tr>
				     <td colspan=2 align=center> Legdrágább </td>
				  </tr>
                  <tr>
				     <td align=center> Termék neve </td>
					 <td align=center> Termék ára </td>
                  </tr>";
		while($sor=mysqli_fetch_array($table))
		 {
			 echo "
                   <tr>
                     <td align=center>";
					 echo $sor['nev'];
             echo "   
                     </td>
                     <td align=center>";
					 echo $sor['egysegar'];
			 echo "
			        </td>
					</tr>";
		  }
		  echo "</table> <br>";
		  
		   $table=mysqli_query( $conn ," SELECT zoldsegek.nev, zoldsegek.egysegar FROM zoldsegek WHERE zoldsegek.egysegar like (SELECT MIN(zoldsegek.egysegar) FROM zoldsegek) " );
		 
		  echo "
		       <table align=center bgcolor=#b3cccc border=1 cellpadding=5>
			      <tr>
				     <td colspan=2 align=center> Legolcsóbb </td>
				  </tr>
                  <tr>
				     <td align=center> Termék neve </td>
					 <td align=center> Termék ára </td>
                  </tr>";
		while($sor=mysqli_fetch_array($table))
		 {
			 echo "
                   <tr>
                     <td align=center>";
					 echo $sor['nev'];
             echo "   
                     </td>
                     <td align=center>";
					 echo $sor['egysegar'];
			 echo "
			        </td>
					</tr>";
		  }
		  echo "</table> <br>";
		  
		  
		 }
     				  
	 
	 else if (isset($_POST['h1']))
	 {
		
		 $table=mysqli_query( $conn ," SELECT zoldsegek.nev, zoldsegek.egysegar FROM zoldsegek WHERE zoldsegek.egysegar like (SELECT MAX(zoldsegek.egysegar) FROM zoldsegek) ") ;
		 
		  echo "
		       <table align=center bgcolor=#b3cccc border=1 cellpadding=5>
			      <tr>
				     <td colspan=2 align=center> Legdrágább </td>
				  </tr>
                  <tr>
				     <td align=center> Termék neve </td>
					 <td align=center> Termék ára </td>
                  </tr>";
				  
		 while($sor=mysqli_fetch_array($table))
		 {
			 echo "
                   <tr>
                     <td align=center>";
					 echo $sor['nev'];
             echo "   
                     </td>
                     <td align=center>";
					 echo $sor['egysegar'];
			 echo "
			        </td>
					</tr>";
		  }
		  echo "</table> <br>";
	 }
		  
	 else if (isset($_POST['h2'])) 
	 {
		 
		 $table=mysqli_query( $conn ," SELECT zoldsegek.nev, zoldsegek.egysegar FROM zoldsegek WHERE zoldsegek.egysegar like (SELECT MIN(zoldsegek.egysegar) FROM zoldsegek) ");
		 
		 
		  echo "
		       <table align=center bgcolor=#b3cccc border=1 cellpadding=5>
			      <tr>
				     <td colspan=2 align=center> Legolcsóbb </td>
				  </tr>
                  <tr>
				     <td align=center> Termék neve </td>
					 <td align=center> Termék ára </td>
                  </tr>";
				  
		 while($sor=mysqli_fetch_array($table))
		 {
			 echo "
                   <tr>
                     <td align=center>";
					 echo $sor['nev'];
             echo "   
                     </td>
                     <td align=center>";
					 echo $sor['egysegar'];
			 echo "
			        </td>
					</tr>";
		  }
		  echo "</table> <br>";
		  
	 }
	 else
		 {
		 $table=mysqli_query( $conn ," SELECT zoldsegek.nev, zoldsegek.egysegar FROM zoldsegek WHERE zoldsegek.egysegar like (SELECT MAX(zoldsegek.egysegar) FROM zoldsegek) ");
		 echo "
		       <table align=center bgcolor=#b3cccc border=1 cellpadding=5>
			      <tr>
				     <td colspan=2 align=center> Legdrágább </td>
				  </tr>
                  <tr>
				     <td align=center> Termék neve </td>
					 <td align=center> Termék ára </td>
                  </tr>";
		while($sor=mysqli_fetch_array($table))
		 {
			 echo "
                   <tr>
                     <td align=center>";
					 echo $sor['nev'];
             echo "   
                     </td>
                     <td align=center>";
					 echo $sor['egysegar'];
			 echo "
			        </td>
					</tr>";
		  }
		  echo "</table> <br>";
		  
		   $table=mysqli_query( $conn ," SELECT zoldsegek.nev, zoldsegek.egysegar FROM zoldsegek WHERE zoldsegek.egysegar like (SELECT MIN(zoldsegek.egysegar) FROM zoldsegek) " );
		 
		  echo "
		       <table align=center bgcolor=#b3cccc border=1 cellpadding=5>
			      <tr>
				     <td colspan=2 align=center> Legolcsóbb </td>
				  </tr>
                  <tr>
				     <td align=center> Termék neve </td>
					 <td align=center> Termék ára </td>
                  </tr>";
		while($sor=mysqli_fetch_array($table))
		 {
			 echo "
                   <tr>
                     <td align=center>";
					 echo $sor['nev'];
             echo "   
                     </td>
                     <td align=center>";
					 echo $sor['egysegar'];
			 echo "
			        </td>
					</tr>";
		  }
		  echo "</table> <br>";
		  
		  
		 }
 }
	 
	
	//5
	
	if (isset($_POST['elkuld5']))
	{
		 $conn=mysqli_connect("localhost","root","","piac");
		 
		// $zoldseges_nev=$_POST['termelok'];
		
		$t1=""; $t2=""; $t3=""; $t4=""; $t5=""; $t6=""; $t7=""; $t8=""; $t9=""; $t10=""; $t11=""; $t12=""; $t13=""; $t14=""; $t15="";
		 echo "
		       <table align=center bgcolor=#b3cccc border=1 cellpadding=5>
                  <tr>
				     <td align=center> Termelő neve </td>
					 <td align=center> Eladás száma </td>
                  </tr>";
		if (isset($_POST['l1']))
		{
			$t1=$_POST['l1'];
			$tabla=mysqli_query($conn, " SELECT zoldsegesek.nev AS Nev, COUNT(vasarlasok.vasarlasazon) AS Eladas FROM vasarlasok,zoldsegesek WHERE vasarlasok.zoldseges=zoldsegesek.zoldsegesazon and zoldsegesek.nev like '$t1' " );
			$sor=mysqli_fetch_array($tabla);
			
			
			echo " <tr>
                     <td align=center>"	;
                      echo $sor['Nev'];
			echo "   
			         </td>
					 <td align=center>";
                      echo $sor['Eladas'];	
            echo " </tr>";				  
					 
			
		}			//echo "</table>";
	    if (isset($_POST['l2']))
		{
			$t2=$_POST['l2'];
			$tabla=mysqli_query($conn, " SELECT zoldsegesek.nev AS Nev, COUNT(vasarlasok.vasarlasazon) AS Eladas FROM vasarlasok,zoldsegesek WHERE vasarlasok.zoldseges=zoldsegesek.zoldsegesazon and zoldsegesek.nev like '$t2' " );
			$sor=mysqli_fetch_array($tabla);
			echo " <tr>
                     <td align=center>"	;
                      echo $sor['Nev'];
			echo "   
			         </td>
					 <td align=center>";
                      echo $sor['Eladas'];	
            echo " </tr>";		
		}			
	    if (isset($_POST['l3']))
		{
			$t3=$_POST['l3'];
			$tabla=mysqli_query($conn, " SELECT zoldsegesek.nev AS Nev, COUNT(vasarlasok.vasarlasazon) AS Eladas FROM vasarlasok,zoldsegesek WHERE vasarlasok.zoldseges=zoldsegesek.zoldsegesazon and zoldsegesek.nev like '$t3' " );
			$sor=mysqli_fetch_array($tabla);
			echo " <tr>
                     <td align=center>"	;
                      echo $sor['Nev'];
			echo "   
			         </td>
					 <td align=center>";
                      echo $sor['Eladas'];	
            echo " </tr>";		
		}			
	    if (isset($_POST['l4']))
		{
			$t4=$_POST['l4'];
			$tabla=mysqli_query($conn, " SELECT zoldsegesek.nev AS Nev, COUNT(vasarlasok.vasarlasazon) AS Eladas FROM vasarlasok,zoldsegesek WHERE vasarlasok.zoldseges=zoldsegesek.zoldsegesazon and zoldsegesek.nev like '$t4' " );
			$sor=mysqli_fetch_array($tabla);
			echo " <tr>
                     <td align=center>"	;
                      echo $sor['Nev'];
			echo "   
			         </td>
					 <td align=center>";
                      echo $sor['Eladas'];	
            echo " </tr>";		
		}			
		if (isset($_POST['l5']))
		{
			$t5=$_POST['l5'];
			$tabla=mysqli_query($conn, " SELECT zoldsegesek.nev AS Nev, COUNT(vasarlasok.vasarlasazon) AS Eladas FROM vasarlasok,zoldsegesek WHERE vasarlasok.zoldseges=zoldsegesek.zoldsegesazon and zoldsegesek.nev like '$t5' " );
			$sor=mysqli_fetch_array($tabla);
			echo " <tr>
                     <td align=center>"	;
                      echo $sor['Nev'];
			echo "   
			         </td>
					 <td align=center>";
                      echo $sor['Eladas'];	
            echo " </tr>";		
		}
		if (isset($_POST['l6']))
		{
			$t6=$_POST['l6'];
			$tabla=mysqli_query($conn, " SELECT zoldsegesek.nev AS Nev, COUNT(vasarlasok.vasarlasazon) AS Eladas FROM vasarlasok,zoldsegesek WHERE vasarlasok.zoldseges=zoldsegesek.zoldsegesazon and zoldsegesek.nev like '$t6' " );
			$sor=mysqli_fetch_array($tabla);
			echo " <tr>
                     <td align=center>"	;
                      echo $sor['Nev'];
			echo "   
			         </td>
					 <td align=center>";
                      echo $sor['Eladas'];	
            echo " </tr>";		
		}
		if (isset($_POST['l7']))
		{
			$t7=$_POST['l7'];
			$tabla=mysqli_query($conn, " SELECT zoldsegesek.nev AS Nev, COUNT(vasarlasok.vasarlasazon) AS Eladas FROM vasarlasok,zoldsegesek WHERE vasarlasok.zoldseges=zoldsegesek.zoldsegesazon and zoldsegesek.nev like '$t7' " );
			$sor=mysqli_fetch_array($tabla);
			echo " <tr>
                     <td align=center>"	;
                      echo $sor['Nev'];
			echo "   
			         </td>
					 <td align=center>";
                      echo $sor['Eladas'];	
            echo " </tr>";		
		}
		if (isset($_POST['l8']))
		{
			$t8=$_POST['l8'];
			$tabla=mysqli_query($conn, " SELECT zoldsegesek.nev AS Nev, COUNT(vasarlasok.vasarlasazon) AS Eladas FROM vasarlasok,zoldsegesek WHERE vasarlasok.zoldseges=zoldsegesek.zoldsegesazon and zoldsegesek.nev like '$t8' " );
			$sor=mysqli_fetch_array($tabla);
			echo " <tr>
                     <td align=center>"	;
                      echo $sor['Nev'];
			echo "   
			         </td>
					 <td align=center>";
                      echo $sor['Eladas'];	
            echo " </tr>";		
		}
		if (isset($_POST['l9']))
		{
			$t9=$_POST['l9'];	
			$tabla=mysqli_query($conn, " SELECT zoldsegesek.nev AS Nev, COUNT(vasarlasok.vasarlasazon) AS Eladas FROM vasarlasok,zoldsegesek WHERE vasarlasok.zoldseges=zoldsegesek.zoldsegesazon and zoldsegesek.nev like '$t9' " );
			$sor=mysqli_fetch_array($tabla);
			echo " <tr>
                     <td align=center>"	;
                      echo $sor['Nev'];
			echo "   
			         </td>
					 <td align=center>";
                      echo $sor['Eladas'];	
            echo " </tr>";		
		}
		if (isset($_POST['l10']))
		{
			$t10=$_POST['l10'];
			$tabla=mysqli_query($conn, " SELECT zoldsegesek.nev AS Nev, COUNT(vasarlasok.vasarlasazon) AS Eladas FROM vasarlasok,zoldsegesek WHERE vasarlasok.zoldseges=zoldsegesek.zoldsegesazon and zoldsegesek.nev like '$t10' " );
			$sor=mysqli_fetch_array($tabla);
			echo " <tr>
                     <td align=center>"	;
                      echo $sor['Nev'];
			echo "   
			         </td>
					 <td align=center>";
                      echo $sor['Eladas'];	
            echo " </tr>";		
		}
		if (isset($_POST['l11']))
		{
			$t11=$_POST['l11'];
			$tabla=mysqli_query($conn, " SELECT zoldsegesek.nev AS Nev, COUNT(vasarlasok.vasarlasazon) AS Eladas FROM vasarlasok,zoldsegesek WHERE vasarlasok.zoldseges=zoldsegesek.zoldsegesazon and zoldsegesek.nev like '$t11' " );
			$sor=mysqli_fetch_array($tabla);
			echo " <tr>
                     <td align=center>"	;
                      echo $sor['Nev'];
			echo "   
			         </td>
					 <td align=center>";
                      echo $sor['Eladas'];	
            echo " </tr>";		
		}
		if (isset($_POST['l12']))
		{
			$t12=$_POST['l12'];
			$tabla=mysqli_query($conn, " SELECT zoldsegesek.nev AS Nev, COUNT(vasarlasok.vasarlasazon) AS Eladas FROM vasarlasok,zoldsegesek WHERE vasarlasok.zoldseges=zoldsegesek.zoldsegesazon and zoldsegesek.nev like '$t12' " );
			$sor=mysqli_fetch_array($tabla);
			echo " <tr>
                     <td align=center>"	;
                      echo $sor['Nev'];
			echo "   
			         </td>
					 <td align=center>";
                      echo $sor['Eladas'];	
            echo " </tr>";		
		}
		if (isset($_POST['l13']))
		{
			$t13=$_POST['l13'];
			$tabla=mysqli_query($conn, " SELECT zoldsegesek.nev AS Nev, COUNT(vasarlasok.vasarlasazon) AS Eladas FROM vasarlasok,zoldsegesek WHERE vasarlasok.zoldseges=zoldsegesek.zoldsegesazon and zoldsegesek.nev like '$t13' " );
			$sor=mysqli_fetch_array($tabla);
			echo " <tr>
                     <td align=center>"	;
                      echo $sor['Nev'];
			echo "   
			         </td>
					 <td align=center>";
                      echo $sor['Eladas'];	
            echo " </tr>";		
		}
		if (isset($_POST['l14']))
		{
			$t14=$_POST['l14'];
			$tabla=mysqli_query($conn, " SELECT zoldsegesek.nev AS Nev, COUNT(vasarlasok.vasarlasazon) AS Eladas FROM vasarlasok,zoldsegesek WHERE vasarlasok.zoldseges=zoldsegesek.zoldsegesazon and zoldsegesek.nev like '$t14' " );
			$sor=mysqli_fetch_array($tabla);
			echo " <tr>
                     <td align=center>"	;
                      echo $sor['Nev'];
			echo "   
			         </td>
					 <td align=center>";
                      echo $sor['Eladas'];	
            echo " </tr>";		
		}
		if (isset($_POST['l15']))
		{
			$t15=$_POST['l15'];
			$tabla=mysqli_query($conn, " SELECT zoldsegesek.nev AS Nev, COUNT(vasarlasok.vasarlasazon) AS Eladas FROM vasarlasok,zoldsegesek WHERE vasarlasok.zoldseges=zoldsegesek.zoldsegesazon and zoldsegesek.nev like '$t15' " );
			$sor=mysqli_fetch_array($tabla);
			echo " <tr>
                     <td align=center>"	;
                      echo $sor['Nev'];
			echo "   
			         </td>
					 <td align=center>";
                      echo $sor['Eladas'];	
            echo " </tr>";		
		}
		echo "</table>";

		/* $tabla=mysqli_query($conn," SELECT zoldsegesek.nev AS  Nev,COUNT(vasarlasok.vasarlasazon) AS Eladas 
		 FROM vasarlasok,zoldsegesek 
		 WHERE  vasarlasok.zoldseges=zoldsegesek.zoldsegesazon 
		 GROUP BY zoldsegesek.nev  
		 HAVING zoldsegesek.nev like '%$t1%' or zoldsegesek.nev like '%$t2%' or zoldsegesek.nev like '%$t3%' or zoldsegesek.nev like '%$t4%' or zoldsegesek.nev like '%$t5%' or zoldsegesek.nev like '%$t6%' or zoldsegesek.nev like '%$t7%' or zoldsegesek.nev like '%$t8%' or zoldsegesek.nev like '%$t9%' or zoldsegesek.nev like '%$t10%' or zoldsegesek.nev like '%$t11%' or zoldsegesek.nev like '%$t12%' or zoldsegesek.nev like '%$t13%' or zoldsegesek.nev like '%$t14%' or zoldsegesek.nev like '%$t15%' " );
        while($sor=mysqli_fetch_array($tabla))
		{
			echo $sor['Nev']." ".$sor['Eladas']."<br>";
		}
		*/
	}
 
	
	//6
	if ( isset($_POST['elkuld6']))
   {
	   $datum_1=$_POST['datum1'];
	   
	    $tabla=mysqli_query($conn, " SELECT vasarlasok.vevo AS Azonosito, vevok.nev AS Nev, vasarlasok.datum, vasarlasok.mennyiseg,COUNT(vasarlasok.vasarlasazon) AS Vasarlasok FROM vasarlasok,vevok WHERE vasarlasok.vevo=vevok.vevoazon and vasarlasok.datum NOT LIKE '%$datum_1%' GROUP BY vasarlasok.vevo");
		
		echo "
		       <table align=center bgcolor=#b3cccc border=1 cellpadding=5>
                  <tr>
				     <td align=center> Vásarló azonositó </td>
					 <td align=center> Vásárló neve </td>
					 <td align=center> Dátum </td>
					 <td align=center> Mennyiség </td>
					 <td align=center> Vásárlások száma </td>
                  </tr>";
        
		/*while ( $sor=mysqli_fetch_array($tabla) ) 
   echo $sor['Azonosito']." ".$sor['Nev']." ".$sor['datum']." ".$sor['mennyiseg']." ".$sor['Vasarlasok']."<br>";*/
       while($sor=mysqli_fetch_array($tabla))
		 {
			 echo "
                   <tr>
                     <td align=center>";
					 echo $sor['Azonosito'];
             echo "   
                     </td>
                     <td align=center>";
					 echo $sor['Nev'];
			echo "   
                     </td>
                     <td align=center>";
					 echo $sor['datum'];
			echo "   
                     </td>
                     <td align=center>";
					 echo $sor['mennyiseg'];
			echo "   
                     </td>
                     <td align=center>";
					 echo $sor['Vasarlasok'];
			 echo "
			        </td>
					</tr>";
		  }
		  echo "</table> <br>";
		  
		  
		 }
	   
   
	
	//7
	if ( isset($_POST['elkuld7']))
   {
	   $datum_2=$_POST['datum2'];
	   $darabszam=$_POST['darab'];
	   
	    $tabla=mysqli_query($conn, " SELECT vasarlasok.vevo AS Azonosito, vasarlasok.datum, vasarlasok.mennyiseg, vevok.nev AS Nev,COUNT(vasarlasok.vasarlasazon) AS Vasarlasok FROM vasarlasok,vevok WHERE vasarlasok.vevo=vevok.vevoazon and vasarlasok.datum NOT LIKE '%$datum_2%' GROUP BY vasarlasok.vevo HAVING COUNT(vasarlasok.vasarlasazon) >='$darabszam' ");
        
		/*while ( $sor=mysqli_fetch_array($tabla) ) 
			echo $sor['Azonosito']." ".$sor['Nev']." ".$sor['Vasarlasok']."<br>"; */
		echo "
		       <table align=center bgcolor=#b3cccc border=1 cellpadding=5>
                  <tr>
				     <td align=center> Vásarló azonositó </td>
					 <td align=center> Vásárló neve </td>
					 <td align=center> Dátum </td>
					 <td align=center> Mennyiség </td>
					 <td align=center> Vásárlások száma </td>
                  </tr>";
        
       while($sor=mysqli_fetch_array($tabla))
		 {
			 echo "
                   <tr>
                     <td align=center>";
					 echo $sor['Azonosito'];
             echo "   
                     </td>
                     <td align=center>";
					 echo $sor['Nev'];
			echo "   
                     </td>
                     <td align=center>";
					 echo $sor['datum'];
			echo "   
                     </td>
                     <td align=center>";
					 echo $sor['mennyiseg'];
			echo "   
                     </td>
                     <td align=center>";
					 echo $sor['Vasarlasok'];
			 echo "
			        </td>
					</tr>";
		  }
		  echo "</table> <br>";
	   
   }
	
	//8
	if (isset ($_POST['elkuld8']))
	{
		$conn=mysqli_connect("localhost","root","","piac");
		
		$termekazon_uj=$_POST['ujtermekazon'];
		$termeknev_uj=$_POST['ujtermeknev'];
		$termekar_uj=$_POST['ujtermekar'];
		$termektipus_uj=$_POST['ujtermektipus'];
		
		$tabla=mysqli_query($conn," INSERT INTO zoldsegek(zoldsegazon, nev, egysegar, tipus) VALUES ('$termekazon_uj','$termeknev_uj','$termekar_uj','$termektipus_uj') ");
		echo "Sikeresen hozzáadott egy terméket";
		
	}
	
	//9
	if (isset ($_POST['elkuld9']))
	{
		$conn=mysqli_connect("localhost","root","","piac");
		
		$termeknev3=$_POST['termekek2'];
		$termekar=$_POST['ujar'];
		
		$tabla=mysqli_query($conn," UPDATE zoldsegek SET egysegar='$termekar' WHERE nev like '$termeknev3' ");
		echo "Sikeresen módositotta a/az ".$termeknev3." árát";
		
	}
	
	//10

	if (isset ($_POST['elkuld10']))
	{
		$conn=mysqli_connect("localhost","root","","piac");
		
		$mennyiseg_torol=$_POST['mennyiseg_s'];
		$termeknev4=$_POST['termekek3'];
		
		
		
		$tabla=mysqli_query($conn," SELECT zoldsegazon FROM zoldsegek WHERE nev like '$termeknev4' ");
		$sor=mysqli_fetch_array($tabla);
		$azonosito_torles=$sor['zoldsegazon'];
		
		//echo $mennyiseg." ".$termeknev4." ".$azonosito_torles;
		
		$tabla=mysqli_query($conn," DELETE FROM vasarlasok WHERE (mennyiseg<='$mennyiseg_torol' and aru like '$azonosito_torles') ");
		echo "Sikeresen törölte a vásárlásokat";
		
		
	}
	
	echo "</body bgcolor=#f2f2f2>
	     </html>";

?>