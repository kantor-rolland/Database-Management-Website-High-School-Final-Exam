﻿<?php

session_start(); 

  $conn=mysqli_connect("localhost","root","","sertes");
  
  if(isset($_POST['veglegesit']))
  {
	 
	   $tablanev="fialasok_".$_SESSION['userid'];
	   
	   $fialas_sorszam=$_POST['fialas_sorsz'];
       $koca_azon=$_POST['sertesazon2'];
	   $kan_azon=$_POST['sertesazon3'];
	   $bugatas=$_POST['bugatas_sorszam'];
	   $datum1=$_POST['szul_datum'];
	   $szam1=$_POST['fialt_malacok'];
	   $szam2=$_POST['felnevelt_malacok'];
	   $szam_fiu=$_POST['fiu_malacok'];
	   $szam_lany=$_POST['lany_malacok']; 
	   $datum2=$_POST['elv_datum'];
       //$szam1  $szam2 $szam_fiu $szam_lany
	   
	   //echo  $fialas_sorszam." ".$koca_azon." ".$kan_azon." ".$datum1." ". $szam1." ".$szam2." ".$szam_fiu." ".$szam_lany." ".$datum2." ";
	  
	   
		  /* INSERT INTO fialasok(Azonosito, Koca_azonosito, Kan_azonosito, Bugatas_sorszam, Idopont, Fialt_malacok, Felnevelt_malacok, Fiu, Lany, Elvalasztasi_idopont, Alom_tomeg, 21napos_tomeg) VALUES ('$fialas_sorszam','$koca_azon','$kan_azon',0,'$datum1','$szam1','$szam2','$szam_fiu','$szam_lany','$datum2','$tomeg1','$tomeg1')*/
	      /*
	       //koca_azon
		   $ok2=0;
		    if(strlen($koca_azon)!=12)
		   {
			   $ok2=1;
			   if(strlen($koca_azon)==0)
				   echo "A koca azonositó mező üres!"."<br>";
			   else echo "Hibás koca azonositó, nem megfelelő az azonositó hosszúsága!"."<br>";
		   }
		   else if(strcmp( substr($koca_azon, 0, 2),"RO")!=0)
		   {
			   $ok2=1;
			   echo "Hibás koca azonositó, az azonositó kötelezően RO - val kell kezdődjön!"."<br>";
		   }
		   else 
		   {
			   
			   for( $i=2; $i<12; $i++)
			   {
				  if( strchr("0123456789",$koca_azon[$i])==NULL )
				   {
					   $ok2=1;
				   }
			   }
			   if( $ok2==1)
			   {
				   echo "Hibás koca azonositó, a 3-12. helyeken kötelezően szám kell szerepeljen!"."<br>";
			   }
		   }

           //kan_azon
		   $ok3=0;
		    if(strlen($kan_azon)!=12)
		   {
			   $ok3=1;
			   if(strlen($kan_azon)==0)
				   echo "A kan azonositó mező üres!"."<br>";
			   else echo "Hibás kan azonositó, nem megfelelő az azonositó hosszúsága!"."<br>";
		   }
		   else if(strcmp( substr($kan_azon, 0, 2),"RO")!=0)
		   {
			   $ok3=1;
			   echo "Hibás kan azonositó, az azonositó kötelezően RO - val kell kezdődjön!"."<br>";
		   }
		   else 
		   {
			   
			   for( $i=2; $i<12; $i++)
			   {
				  if( strchr("0123456789",$kan_azon[$i])==NULL )
				   {
					   $ok3=1;
				   }
			   }
			   if( $ok3==1)
			   {
				   echo "Hibás kan azonositó, a 3-12. helyeken kötelezően szám kell szerepeljen!";
			   }
		   }
		   */
		   //$szam1  $szam2 $szam_fiu $szam_lany
		  /* 
		   $ok=0;
		   
		   if($szam1>=$szam2)
		   {
			   
			   if ($szam2==$szam_fiu+$szam_lany)
				   $ok1=0;
			   else $ok1=1;
			   {
				   $ok=1;
				   echo "A fiú illetve a lány malacok száma nem haladhatja meg a felnevelt malacok számát!"."<br>";
			   }
				   
		   }
		   else $ok1=1;
		   {
			   $ok1=1;
			   echo "A fialt malacok száma nagyobb vagy egyenlő kell legyen a felnevelt malacok számával"."<br>";
		   }
		   */
		   
		   //osszesit
		  // if($ok1==0 and $ok2==0 and $ok3==0)
		   {
		   //echo substr($sertes_azon, 0, 2);
		    $conn=mysqli_connect("localhost","root","","sertes");
		    $tabla=mysqli_query( $conn, " INSERT INTO $tablanev (Sorszam, Koca_azonosito, Kan_azonosito, Megtermekenyites_sorszam, Idopont, Fialt_malacok, Felnevelt_malacok, Fiu, Lany, Elvalasztasi_idopont) VALUES ('$fialas_sorszam','$koca_azon','$kan_azon','$bugatas','$datum1','$szam1','$szam2','$szam_fiu','$szam_lany','$datum2') " );
		   
		  /* 
		  INSERT INTO `fialasok_1`(`Sorszam`, `Koca_azonosito`, `Kan_azonosito`, `Bugatas_sorszam`, `Idopont`, `Fialt_malacok`, `Felnevelt_malacok`, `Fiu`, `Lany`, `Elvalasztasi_idopont`) VALUES ([value-1],[value-2],[value-3],[value-4],[value-5],[value-6],[value-7],[value-8],[value-9],[value-10])
	      */
	   
	   
			}
			header('Location: fialas.php');	
  }
?>
