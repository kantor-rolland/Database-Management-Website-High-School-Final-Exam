﻿<html>
  <head>
    <title> Piac </title>
  </head>
  
  <body bgcolor=#f2f2f2 background=hatter2.png>
     
     	 <form method=post action=urlap2.php>	 
   
     <table width=95% align=center border=1 cellpadding=5 cellspacing=0 bgcolor=#f2f2f2>
	    <tr align=center>
		  <td width=25%> <a href=piac.html> Főoldal
		  </td>
		  <td width=25%> <a href=termekek.php > Termékek
		  </td>
		  <td width=25%> <a href=termelok.html > Termelők
		  </td>
		  <td width=25%>  Lekérdezések
		  </td>
		</tr>
	 </table>
	 
	  <br>
	  
	  <hr style="width:50%;height:5;background-color:#737373">
	  
	  <br>
	  
	  <table width=95% align=center border=0 cellpadding=5 cellspacing=0 >
	    <tr>
		  <td colspan=4> <p align=center> <font size=30px> Táblák </font> </p>
		  </td>
		</tr>
	    <tr align=center>
		  <td width=25%> <a href=vasarlasok.php target=_blank > Vásárlások
		  </td>
		  <td width=25%> <a href=vevok.php target=_blank > Vevők
		  </td>
		  <td width=25%> <a href=zoldsegek.php target=_blank > Zöldségek
		  </td>
		  <td width=25%> <a href=zoldsegesek.php target=_blank > Zöldségesek
		  </td>
		</tr>
	 </table>
	 
	 <br><br>
	 
	 1. Válasszon ki egy adott terméket, hogy megtudja kinél megtalálható
	 
	 <br>
	 <select name=termekek1>
	 <option disabled selected>Termék neve</option>
	    <option>
		<?php
		
		   $conn=mysqli_connect("localhost","root","","piac");
		   $tabla=mysqli_query($conn," SELECT DISTINCT(nev) FROM zoldsegek ");
        while($sor=mysqli_fetch_array($tabla))
        {
	        echo "<option>";	
            echo $sor['nev'];
            echo "</option>"; 
        }
		?>
		</option>
	 </select>
	 <input name=elkuld1 type=submit value=Elküld>
	 
	 <br><br>
	 
	 2.Válassza ki azt, hogy a legdrágább vagy a legolcsóbb terméket kivánja megtudni
	<br>
	
   <input name=h1 type=checkbox value=1> Legdragabb
   <input name=h2 type=checkbox value=2> Legolcsobb
  
   <input name=elkuld2 type=submit value=Elküld> <br>
   <br>
   

   3.Válasszon ki egy termelőt, akinek megszeretné tudni az eladásai számát
   <br>
 <table>
   <tr>
     <td> <input name=l1 type=checkbox value="Kiss József">Kiss József </td>
	 <td> <input name=l2 type=checkbox value="Danai Lajosné">Danai Lajosné </td>
	 <td> <input name=l3 type=checkbox value="Würtz István">Würtz István</td>
	 <td> <input name=l4 type=checkbox value="Nagy Alpár">Nagy Alpár</td>
	 <td> <input name=l5 type=checkbox value="Székhelyi Aladárné">Székhelyi Aladárné</td>
   </tr>
   <tr>
     <td> <input name=l6 type=checkbox value="Szabó Attila">Szabó Attila</td>
	 <td> <input name=l7 type=checkbox value="Hollner Gyula">Hollner Gyula</td>
	 <td> <input name=l8 type=checkbox value="Arnót Lipótné">Arnót Lipótné</td>
	 <td> <input name=l9 type=checkbox value="Becskei Zoltán">Becskei Zoltán</td>
	 <td> <input name=l10 type=checkbox value="Guttman Kristóf">Guttman Kristóf</td>
   </tr>
   <tr>
     <td> <input name=l11 type=checkbox value="Szederkényi Izidor">Szederkényi Izidor</td>
	 <td> <input name=l12 type=checkbox value="Raschl Norbert">Raschl Norbert</td>
	 <td> <input name=l13 type=checkbox value="Verőcki Géza">Verőcki Géza</td>
	 <td> <input name=l14 type=checkbox value="Sarkadi Huba">Sarkadi Huba</td>
	 <td> <input name=l15 type=checkbox value="Edelényi Pálné">Edelényi Pálné</td>
   </tr>
 </table>
	 <!--<input name=l1 type=checkbox value="Kiss József">Kiss József
     <input name=l2 type=checkbox value="Danai Lajosné">Danai Lajosné
	 <input name=l3 type=checkbox value="Würtz István">Würtz István
	 <input name=l4 type=checkbox value="Nagy Alpár">Nagy Alpár
	 <input name=l5 type=checkbox value="Székhelyi Aladárné">Székhelyi Aladárné
	 <input name=l6 type=checkbox value="Szabó Attila">Szabó Attila
	 <input name=l7 type=checkbox value="Hollner Gyula">Hollner Gyula
	 <input name=l8 type=checkbox value="Arnót Lipótné">Arnót Lipótné
	 <input name=l9 type=checkbox value="Becskei Zoltán">Becskei Zoltán
	 <input name=l10 type=checkbox value="Guttman Kristóf">Guttman Kristóf
	 <input name=l11 type=checkbox value="Szederkényi Izidor">Szederkényi Izidor
	 <input name=l12 type=checkbox value="Raschl Norbert">Raschl Norbert
	 <input name=l13 type=checkbox value="Verőcki Géza">Verőcki Géza
	 <input name=l14 type=checkbox value="Sarkadi Huba">Sarkadi Huba
	 <input name=l15 type=checkbox value="Edelényi Pálné">Edelényi Pálné		
	 -->
	 <input name=elkuld5 type=submit value=Elküld> 
	 <br><br>
	 
	 
	 4.Vásárlások száma dátum szerint csoportositva egy adott dátumon kivül
     <br><br>
	 
	 <select name=datum1 >
	 <option disabled selected>Dátum </option>
	    <option>
		<?php
		
		   $conn=mysqli_connect("localhost","root","","piac");
		   $tabla=mysqli_query($conn," SELECT DISTINCT(datum) FROM vasarlasok ");
        while($sor=mysqli_fetch_array($tabla))
        {
	        echo "<option>";	
            echo $sor['datum'];
            echo "</option>"; 
        }
		?>
		</option>
	 </select>
	 <input name=elkuld6 type=submit value=Elküld>
	 <br><br>
	 
	 
	 5.Csoportositsa a vevők vásárlásainak számát, egy adott dátumon kivül, amelyek egy adott számnál nagyobbak
	 <br>
	 <select name=datum2 >
	 <option disabled selected>Dátum </option>
	    <option>
		<?php
		
		   $conn=mysqli_connect("localhost","root","","piac");
		   $tabla=mysqli_query($conn," SELECT DISTINCT(datum) FROM vasarlasok ");
        while($sor=mysqli_fetch_array($tabla))
        {
	        echo "<option>";	
            echo $sor['datum'];
            echo "</option>"; 
        }
		?>
		</option>
	 </select>
	 <input name=darab type=number value='' min=0 placeholder="Érték">
	 <input name=elkuld7 type=submit value=Elküld>
	 <br><br>
	 
	 6.Adjon a tablahoz egy uj termeket
	 <br>
	
	 
	 <?php
         // $conn=mysqli_connect("localhost","root","","piac");
          $tabla=mysqli_query($conn," SELECT MAX(zoldsegazon) AS maxi FROM zoldsegek ");
          $sor=mysqli_fetch_array($tabla);
          $azonertek=$sor['maxi']+1;
     ?>

     <input name=ujtermekazon type=number value='<?php echo $azonertek; ?>' min='<?php echo $azonertek; ?>' max='<?php echo $azonertek; ?>'>
	 <input name=ujtermeknev type=text placeholder="Termek neve">
	 <input name=ujtermekar type=number min=0>
	 <input name=ujtermektipus type=radio value="zöldség" checked
	 >zöldség
	 <input name=ujtermektipus type=radio value="gyümölcs">gyümölcs
	 
	 <input name=elkuld8 type=submit value=Elküld>
	 <br><br>
	 
	 7. Változtak az árak, módositja meg egy adott gyümölcs árát az új árra
	 <br>
	 <select name=termekek2>
	 <option disabled selected>Termék neve</option>
	    <option>
		<?php
		
		   $conn=mysqli_connect("localhost","root","","piac");
		   $tabla=mysqli_query($conn," SELECT DISTINCT(nev) FROM zoldsegek ");
        while($sor=mysqli_fetch_array($tabla))
        {
	        echo "<option>";	
            echo $sor['nev'];
            echo "</option>"; 
        }
		?>
		</option>
	 </select>
	 <input name=ujar type=number min=0>
	 <input name=elkuld9 type=submit value=Elküld> 
	 <br><br>
	 
	 8.Válasszon ki egy terméket és egy mennyiséget majd törölje az ennél kisebb vásárlásokat
	 <br>
	 
	  <select name=mennyiseg_s>
	  <option disabled selected>Mennyiség</option>
	    <option>
		<?php
		
		   $conn=mysqli_connect("localhost","root","","piac");
		   $tabla=mysqli_query($conn," SELECT DISTINCT(mennyiseg) FROM vasarlasok ORDER BY mennyiseg ASC ");
        while($sor=mysqli_fetch_array($tabla))
        {
	        echo "<option>";	
            echo $sor['mennyiseg'];
            echo "</option>"; 
        }
		?>
		</option>
	 </select>
	  <select name=termekek3>
	    <option>
		<?php
		
		   $conn=mysqli_connect("localhost","root","","piac");
		   $tabla=mysqli_query($conn," SELECT DISTINCT(nev) FROM zoldsegek ");
        while($sor=mysqli_fetch_array($tabla))
        {
	        echo "<option>";	
            echo $sor['nev'];
            echo "</option>"; 
        }
		?>
		</option>
	 </select>
	 <input name=elkuld10 type=submit value=Elküld>
	 <br>
	 <br>
	  
	  <hr style="width:50%;height:5;background-color:#737373">
	  
	 <br>
	 
	     </form>
  </body>
</html>