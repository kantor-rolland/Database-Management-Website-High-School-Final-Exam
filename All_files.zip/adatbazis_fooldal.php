<html>
    <title>
         Kezdőlap
	</title>
	<link rel="stylesheet" type="text/css" href="style.css">
    <body>	  
			<?php 
				session_start();
					if($_SESSION['userid'] == 0){
			    ?>
					<!--<a href=bejelentkezes.php> Bejelentkezés-->
						<form action="bejelentkezes.php" method="get">
								<button class="btn2" type="submit">Bejelentkezés</button>
						</form>
						
						<!--<a href=regisztracio.php> regisztrálá1s -->
						<form action="regisztracio.php" method="get">
								<button class="btn2" type="submit">Regisztrálás</button>
						</form>
					
		
	   <table width=95% align=center border=1 cellpadding=5 cellspacing=0 id='menu_1'> 	
			<tr>
				<!-- amit a vendeg lat -->
				<td width=30%> Főoldal 
				</td>
				<td width=30%>
				<a href=sertes_fajtak.php> A sertés fajtákról
				</td>
				<td width=30%>
				<a href=tenyesztok.php> Tenyésztők
				</td>
		   </tr>
		</table>   
		<br>
		<img src="sertes_logo.png" alt="logo" valign=center id='image'>
			 <?php		
				}
				else{
					header('Location: felhasznalo_fooldal.php');
					
			 ?>
			    <!-- amit az lat aki be van jelentkezve -->
                <!--
				<td width=25%> <a href=sertes.php> Sertés
				</td>
				<td width=25%> <a href=fialas.php> Fialás
				</td>
				<td width=25%> <a href=megtermekenyites.php> Megtermékenyítés
				</td>
				<td width=25%> <a href=gabona.php> Takarmány
				</td>
				</tr>
				<tr>
					<td width=25%> <a href=probaa.php> VENDEG
			 		</td>
			 		<td>
				 		A sertes fajtakrol
			 		</td>
			 		<td>
				 		Tenyesztok
			 		</td>
				</tr>
				<form action="kijelentkezes.php" method="post">
					<input name=kijelentkezes type=submit value="Exit">
				</form> -->
				
			<?php 
				}
			?>
		  
    </body>
</html>