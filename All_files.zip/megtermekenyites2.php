﻿<?php

session_start();

 $conn=mysqli_connect("localhost","root","","sertes");
 if(isset($_POST['veglegesit']))
  {
	 $tablanev="megtermekenyites_".$_SESSION['userid'];
	   $megtermekenyites_sorszam=$_POST['megterm_sorsz'];
       $koca_azon=$_POST['sertesazon1'];
	   $kan_azon=$_POST['sertesazon2'];
	   //$bugatas_azon
	   $datum=$_POST['mt_datum']; 
	   
       $tabla=mysqli_query( $conn, "INSERT INTO $tablanev (Sorszam, Koca_azonosito, Kan_azonosito, Datum) VALUES ('$megtermekenyites_sorszam', '$koca_azon', '$kan_azon', '$datum')" ) ;			   echo "Sikeres hozzaadas"."<br>";
	   echo $megtermekenyites_sorszam." "."$koca_azon"." "."$kan_azon"." ".$datum."<br>";
	   header('Location: megtermekenyites.php');
	  /* 
	   //koca_azon
		   $ok2=0;
		    if(strlen($koca_azon)!=12)
		   {
			   $ok2=1;
			   if(strlen($koca_azon)==0)
				   echo "A koca azonositó mező üres!"."<br>";
			   else echo "Hibás koca azonositó, nem megfelelő az azonositó hosszúsága!"."<br>";
		   }
		   else if(strcmp( substr($koca_azon, 0, 2),"RO")!=0)
		   {
			   $ok2=1;
			   echo "Hibás koca azonositó, az azonositó kötelezően RO - val kell kezdődjön!"."<br>";
		   }
		   else 
		   {
			   
			   for( $i=2; $i<12; $i++)
			   {
				  if( strchr("0123456789",$koca_azon[$i])==NULL )
				   {
					   $ok2=1;
				   }
			   }
			   if( $ok2==1)
			   {
				   echo "Hibás koca azonositó, a 3-12. helyeken kötelezően szám kell szerepeljen!"."<br>";
			   }
		   }

           //kan_azon
		   $ok3=0;
		    if(strlen($kan_azon)!=12)
		   {
			   $ok3=1;
			   if(strlen($kan_azon)==0)
				   echo "A kan azonositó mező üres!"."<br>";
			   else echo "Hibás kan azonositó, nem megfelelő az azonositó hosszúsága!"."<br>";
		   }
		   else if(strcmp( substr($kan_azon, 0, 2),"RO")!=0)
		   {
			   $ok3=1;
			   echo "Hibás kan azonositó, az azonositó kötelezően RO - val kell kezdődjön!"."<br>";
		   }
		   else 
		   {
			   
			   for( $i=2; $i<12; $i++)
			   {
				  if( strchr("0123456789",$kan_azon[$i])==NULL )
				   {
					   $ok3=1;
				   }
			   }
			   if( $ok3==1)
			   {
				   echo "Hibás kan azonositó, a 3-12. helyeken kötelezően szám kell szerepeljen!";
			   }
		   }
		   */
		  // if($ok2==0 and $ok3==0)
		  
  }
?>