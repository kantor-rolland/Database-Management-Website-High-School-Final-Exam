<html>
    <head>
        <title>
            Főoldal 
        </title>
        <link rel="stylesheet" type="text/css" href="style.css">
    </head>
    <body>

	     
             
                   <!-- <form action="bejelentkezes.php" method="get">
						<button class="btn2" type="submit">Bejelentkezés</button>
                    </form>-->
                    <form action="kijelentkezes.php" method="get">
					    <button class="btn2" name=kijelentkezes type=submit> Kijelentkezés </button>
                    </form>
           
		
	   
			    <!-- amit az lat aki be van jelentkezve -->

    
     <table width=95% align=center border=1 cellpadding=5 cellspacing=0 id='menu_1' >
				<tr>
					<td width=30%> Főoldal
			 		</td>
			 		<td width=30%>
                     <a href=sertes_fajtak.php>A sertés fajtákról
			 		</td>
			 		<td width=30%>
                     <a href=tenyesztok.php> Tenyésztők
			 		</td>
                </tr>
                    <?php
                        session_start();
                        if($_SESSION['userid'] != 0){
                    ?>
				
                    <?php
                        }
                    ?>	
       </table> <br><br>
       <table  class="table" width=95% align=center border=1 cellpadding=5 cellspacing=0 id='menu_2'>
            <tr id="elso sor">
                 <td width=20%> <a href=sertes.php> Sertés
				</td>
				<td width=20%> <a href=fialas.php> Fialás
				</td>
				<td width=20%> <a href=megtermekenyites.php> Megtermékenyítés
				</td>
				<td width=20%> <a href=gabona.php> Takarmány
                </td>
                <td width=20%> <a href=sertes_szuro.php> Szűrés
		     </td>
			</tr>
       </table >
       <br><br><br><br>
       <table class="table_adatbazis" align=center>
           <tr>
               <td colspan=4> Adatbázisok </td>
           </tr>
           <tr>
               <td>
                    <!--<a href=adatbazis_sertes.php target=_blank > Sertés adatbázis -->
                    <form action="adatbazis_sertes.php" method="get" target="_blank">
                        <button class="btn" type="submit">Sertés adatbázis</button>
                    </form>
               </td>
               <td>
                    <!--<a href=adatbazis_fialas.php target=_blank > Fialás adatbázis -->
                    <form action="adatbazis_fialas.php" method="get" target="_blank">
                        <button class="btn" type="submit">Fialás adatbázis</button>
                    </form>
               </td>
               <td>
                    <!--<a href=adatbazis_megtermekenyites.php target=_blank > Megtermékenyítés adatbázis-->
                    <form action="adatbazis_megtermekenyites.php" method="get" target="_blank">
                        <button class="btn" type="submit">Megtermékenyítés adatbázis</button>
                    </form>
               </td>
               <td>
                    <!--<a href=adatbazis_megtermekenyites.php target=_blank > Megtermékenyítés adatbázis-->
                    <form action="adatbazis_takarmany.php" method="get" target="_blank">
                        <button class="btn" type="submit">Takarmány adatbázis</button>
                    </form>
               </td>
           </tr>
       </table> <br><br><br>
	   <table id="table2" class="table">
		  <!-- <tr>
			   <td colspan=5>
			   Aktualis adatok  
               </td>-->
           </tr>
           <tr> 
               <th> Sertésállomány </th>
               <th> Kocák száma</th>
               <th> Hízok száma</th>
               <th> Fiatal egyedek száma</th>
               <th> Fajták száma</th>
           </tr>
           <tr>
               <td>
                    <?php 
                        $conn=mysqli_connect("localhost","root","","sertes");

                        $tablanev1="sertesek_".$_SESSION['userid'];

                        $tabla=mysqli_query($conn," SELECT COUNT(Sorszam) AS Darab FROM $tablanev1 ");
                        $sor=mysqli_fetch_array($tabla);
                        echo $sor['Darab'];
                    ?>
               </td>
               <td>
                    <?php 
                        $conn=mysqli_connect("localhost","root","","sertes");

                       // $tablanev1="sertesek_".$_SESSION['userid'];

                        $tabla=mysqli_query($conn," SELECT COUNT(Sorszam) AS Koca FROM $tablanev1 WHERE Tipus like 'Koca' ");
                        $sor=mysqli_fetch_array($tabla);
                        echo $sor['Koca'];
                    ?>
               </td>
               <td>
                    <?php 
                        $conn=mysqli_connect("localhost","root","","sertes");

                       // $tablanev1="sertesek_".$_SESSION['userid'];

                        $tabla=mysqli_query($conn," SELECT COUNT(Sorszam) AS Hizo FROM $tablanev1 WHERE Tipus like 'Hízó' ");
                        $sor=mysqli_fetch_array($tabla);
                        echo $sor['Hizo'];
                    ?>

               </td>
               <td>
                    <?php 
                        $conn=mysqli_connect("localhost","root","","sertes");

                       // $tablanev1="sertesek_".$_SESSION['userid'];

                        $tabla=mysqli_query($conn," SELECT COUNT(Sorszam) AS Fiatal FROM $tablanev1 WHERE Tipus like 'Malac' OR Tipus like 'Süldő' ");
                        $sor=mysqli_fetch_array($tabla);
                        echo $sor['Fiatal'];
                    ?>

               </td>
                <td>
                    <?php 
                        $conn=mysqli_connect("localhost","root","","sertes");

                       // $tablanev1="sertesek_".$_SESSION['userid'];

                        $tabla=mysqli_query($conn," SELECT COUNT(DISTINCT(Fajta)) AS Fajtak  FROM $tablanev1 ");
                        $sor=mysqli_fetch_array($tabla);
                        echo $sor['Fajtak'];
                    ?>

               </td>
           </tr>
       </table>
       <br><br><br>
     
    </body>
</html>